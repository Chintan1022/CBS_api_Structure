var en = require('./../languages/en.json');
// var hi = require('./../languages/hi.json');
// var enhi = require('./../languages/enhi.json');

var LANG = {
    'en' : en,
    // 'hi' : hi,
    // 'enhi' : enhi
}

module.exports = LANG;