const mysql = require('mysql');

const con = mysql.createPool({
    connectionLimit : 10,
    host : 'greenjom-dev.chninyq4x4rc.ap-southeast-2.rds.amazonaws.com',
    user : 'admin',
    password : 'LJWvAUaSeBsQy6RF',
    database : 'greenjomdb',
    waitForConnections: true,
    dateStrings: 'date'
});

con.getConnection((err, connection) => {
    if (err) {
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            console.error('Database connection was closed.')
        }
        if (err.code === 'ER_CON_COUNT_ERROR') {
            console.error('Database has too many connections.')
        }
        if (err.code === 'ECONNREFUSED') {
            console.error('Database connection was refused.')
        }
    }   
    if (connection) {
        connection.release()    
    }
    return;
});

module.exports = con;