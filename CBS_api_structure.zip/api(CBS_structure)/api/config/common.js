const con = require('./database');
const GLOBALS = require('./constants');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
const lang = require("./language");
const moment = require('moment');

const common = {
    async validate_token(req, res, callback) {
        try {
            req.language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
            var path_data = req.path.split("/");
            var byPassMethod = new Array('check_unique','send_otp','verify_otp','signup','signin','contact_us','reset_password','green_list','green_detail');
            if(req.headers['api-key'] != undefined && req.headers['api-key'] != "") {
                var api_key = cryptoLib.decrypt(req.headers['api-key'], shaKey, GLOBALS.ENC_IV);
                if (api_key == GLOBALS.API_KEY) {
                    if (byPassMethod.indexOf(path_data[path_data.length - 1]) === -1) {
                        if(req.headers['token'] != undefined && req.headers['token'] != null && req.headers['token'] != '') {
                            con.query(`SELECT user_id FROM tbl_user_device WHERE token = '${cryptoLib.decrypt(req.headers['token'], shaKey, GLOBALS.ENC_IV)}' LIMIT 1`, function(err, result) {
                                if (result.length != 0) {
                                    req.login_user_id = result[0].user_id;
                                    common.decryption(req.body).then((params)=>{
                                        req.body = params;
                                        callback();
                                    });
                                } else {
                                    common.sendResponse(res, "-1", lang[req.language]['text_rest_tokeninvalid'], null, '401');
                                }
                            });
                        } else {
                            common.sendResponse(res, "-1", lang[req.language]['text_rest_required_token'], null, '401');
                        }
                    } else {
                        common.decryption(req.body).then((params)=>{
                            req.body = params;
                            if(req.headers['token']){
                                con.query(`SELECT user_id FROM tbl_user_device WHERE token = '${cryptoLib.decrypt(req.headers['token'], shaKey, GLOBALS.ENC_IV)}' LIMIT 1`, function(err, result) {
                                    if (result.length != 0) {
                                        req.login_user_id = result[0].user_id;
                                        callback();
                                    } else {
                                        common.sendResponse(res, "-1", lang[req.language]['text_rest_tokeninvalid'], null, '401');
                                    }
                                });
                            }else{
                                callback();
                            }
                        });
                    }
                } else {
                    common.sendResponse(res, "-1", lang[req.language]['text_rest_invalid_api_key'], null, '401');
                }
            } else {
                common.sendResponse(res, "-1", lang[req.language]['text_rest_required_api_key'], null, '401');
            }
        } catch (err) {
            common.sendResponse(res, "-1", lang[req.language]['text_rest_invalid_api_key'], null, '401');
        }
    },

    async checkValidation(params, rules, res, language = 'en') {
        const messages = {
            "required" : lang[language]['required'],
            "email" : lang[language]['email'],
            "integer" : lang[language]['integer'],
            "in" : lang[language]['in']
        }
        const v = require('Validator').make(params, rules, messages);
        if(v.fails()) {
            const errors = v.getErrors();
            common.sendResponse(res, "0", Object.values(errors)[0][0], null);
        }
        else {
            return true;
        }
    },

    async check_unique(params, callback) {
        if(params.email){
            common.unique_fields('email', params.email).then((resEmail) => {
                callback(false);
            }).catch((err)=>{
                callback(true, params.email, 'email');
            });
        }else if(params.mobile_number){
            common.unique_fields('mobile_number', params.mobile_number).then((resMobile) => {
                callback(false);
            }).catch((err)=>{
                callback(true, params.mobile_number, 'mobile_number');
            });
        }else{
            common.unique_fields('email', params.email).then((resEmail) => {
                if(params.mobile_number){
                    common.unique_fields('mobile_number', params.mobile_number).then((resMobile) => {
                        callback(false);
                    }).catch((err)=>{
                        callback(true, params.mobile_number, 'mobile_number');
                    })
                }else{
                    callback(false);
                }
            }).catch((err)=>{
                callback(true, params.email, 'email');
            });
        }
    },

    async check_unique_username(params, callback) {
        common.unique_fields('username', params.username).then((resEmail) => {
            callback(false);
        }).catch((err)=>{
            callback(true, params.username, 'username');
        });
    },

    async unique_fields(field, value) {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id FROM tbl_user WHERE ${field} = '${value}' AND is_active != 'Delete' LIMIT 1`, (err, result) => {
                if(result.length > 0) {
                    reject();
                }
                else {
                    resolve();
                }
            });
        });
    },

    async checkDeviceInfo(id, params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id FROM tbl_user_device WHERE user_id = '${id}' LIMIT 1`,(err,result)=>{
                var token = (new Date()).getTime() + common.stringGen(12) + common.numberGen(16);
                var device = {
                    token : token,
                    device_token : params.device_token,
                    device_type : params.device_type,
                    ...(params.device_model) && {device_model:params.device_model},
                    ...(params.uuid) && {uuid:params.uuid},
                    ...(params.ip) && {ip:params.ip}
                }
                if(result.length != 0) {
                    device.update_datetime = moment().format("X");
                    con.query(`UPDATE tbl_user_device SET ? WHERE user_id = '${id}'`, device,(err,result)=>{
                        if(result.affectedRows != 0) {
                            resolve(device);
                        }
                        else {
                            reject();
                        }
                    });
                }
                else {
                    device.user_id = id;
                    device.insert_datetime = moment().format("X");
                    con.query(`INSERT INTO tbl_user_device SET ?`, device,(err,result)=>{
                        if(result != undefined) {
                            resolve(device);
                        }
                        else {
                            reject();
                        }
                    });
                }
            });
        });
    },

    sendResponse : async (res, resCode, resMessage, resData, resStatus = '200') =>
    {
        var response =
        {
            "code" : resCode,
            "message" : resMessage 
        }
        if(resData != null)
        {
            response["data"] = resData;
        }
        common.encryption(response).then((result)=>{
            res.status(resStatus);
            res.json(result);
            res.end();
        });
    },

    decryption: async (req)=>{
        return new Promise((resolve,reject)=>{
            if(req != undefined && Object.keys(req).length !== 0) {
                try {
                    var request = JSON.parse(cryptoLib.decrypt(req, shaKey, GLOBALS.ENC_IV));
                }
                catch (e) {
                    var request = cryptoLib.decrypt(req, shaKey, GLOBALS.ENC_IV);
                }
                resolve(request);
            }
            else {
                resolve({});
            }
        })
    },

    encryption: async (req) => {
        return new Promise((resolve,reject)=>{
            var response = cryptoLib.encrypt(JSON.stringify(req), shaKey, GLOBALS.ENC_IV);
            resolve(response);
        })
    },

    //add data to table
    add_data(table, params, callback) {
        con.query(`INSERT INTO ${table} SET ?`, params, (err) => {
            callback(true);
        });
    },

    //Update data to table
    async update_data(table, where, params) {
        con.query(`UPDATE ${table} SET ? WHERE ${where}`, params); //end select query;
    },

    // send sms
    async send_sms(phone, otp, template) {
        return new Promise((resolve,reject)=>{
            resolve();
        })
    },

    //send mail
    async send_email(subject, to_email, message) {
        return new Promise((resolve,reject)=>{
            let nodemailer = require('nodemailer');
            let transporter = nodemailer.createTransport({
                host: 'smtp.gmail.com',
                port: 465,
                secure: true, // true for 465, false for other ports
                auth: {
                    user: GLOBALS.EMAIL_ID, // generated ethereal user
                    pass: GLOBALS.EMAIL_PASSWORD // generated ethereal password
                }
            });

            // setup email data with unicode symbols
            let mailOptions = {
                from: GLOBALS.APP_NAME + " <"+GLOBALS.EMAIL_ID+">", // sender address
                to: to_email, // list of receivers 'sonalih@hyperlinkinfosystem.net.in'
                subject: subject, // Subject line
                html: message
            };

            // send mail with defined transport object
            transporter.sendMail(mailOptions, (error, info) => {
                if(error) {
                    reject();
                }
                else {
                    resolve();
                }
            });
        });
    },
    
    // Prepare data for push notification
    prepare_notification(user_id,push_params)
    {
        con.query(`SELECT u.id,d.device_token,d.device_type FROM tbl_user AS u JOIN tbl_user_device AS d ON d.user_id = u.id WHERE u.is_active != 'Delete' AND u.id = ${user_id} LIMIT 1`,(err,result)=>{
            if(!err && result[0]){
                var push_data = {
                    title: push_params.title,
                    body: push_params.body,
                    topic: GLOBALS.BUNDLEID,
                    priority: 'high',
                    notification: {
                        title: push_params.title,
                        body: push_params.body,
                    },
                    alert: {
                        title: push_params.title,
                        body: push_params.body,
                    },
                    custom: push_params.custom
                };
                if(result[0].device_type == "I") {
                    push_data['sound'] = "default";
                }
                const registrationIds = [];
                registrationIds.push(result[0].device_token);
                common.send_push(registrationIds,push_data);
            }
        });
    },

    //send push
    send_push: function(registrationIds, data)
    {
        const settings =  {
            gcm:  {
                id: GLOBALS.GCM_PUSH_KEY,
            },
            apn:  {
                token:  {
                    key: GLOBALS.APN_PUSH_KEY,
                    keyId: GLOBALS.KEYID,
                    teamId: GLOBALS.TEAMID,
                },
            },
            isAlwaysUseFCM: false
        };
        const PushNotifications = require('node-pushnotifications');
        const push = new PushNotifications(settings);
        // console.log("========================")
        // console.log(data);
        push.send(registrationIds, data, (err, result) => {
            // if (err) {
            //     console.log('error');
            //     console.log(err);
            // } else {
            //     console.log('succ');
            //     console.log(result);
            //     console.log(result[0].message);
            // }
        });
    },

    //number random generate
    numberGen(len) {
        common.timestamp = +new Date;
        var _getRandomInt = function(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
        var ts = common.timestamp.toString();
        var parts = ts.split("").reverse();
        var id = "";
        for (var i = 0; i < len; ++i) {
            var index = _getRandomInt(0, parts.length - 1);
            parts[index] = parts[index] == "0" ? 4 : parts[index];
            id += parts[index];
        }
        return id;
    },

    //string random generate
    stringGen(len) {
        var result = [];
        var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var charactersLength = characters.length;
        for (var i = 0; i < len; i++ ) {
            result.push(characters.charAt(Math.floor(Math.random() * charactersLength)));
        }
        return result.join('');
    },

    //get all time slot a day
    get_all_time_slot(pstart_time = '00:00',pend_time = '23:00',pinterval = 60){
        let start_time = moment(pstart_time,'HH:mm');
        let end_time = moment(pend_time,'HH:mm');
        let interval = pinterval;
        let timeslot = [];
        while(start_time <= end_time){
            timeslot.push(new moment(start_time).format('HH:mm:ss'));
            start_time.add(interval,'minutes');
        }
        return timeslot;
    },

    // get all date slot between start & end date
    get_all_month_date_slot(start_date,end_date){
        let monthslot = [];
        let date = new Date(start_date);
        let end = new Date(end_date);
        while(date <= end){
            monthslot.push(moment(date).format('YYYY-MM-DD'));
            date.setDate(date.getDate()+1)
        }
        return monthslot;
    },

    async get_old_image_name_and_delete(table,field,where,dirname,callback) {
        con.query(`SELECT ${field} AS image FROM ${table} WHERE ${where}`,(err,result)=>{
            if(!err && result[0] != undefined){
                if(result[0].image){
                    common.deleteSingleFileS3(dirname,result[0].image);
                    callback();
                } else {
                    callback();
                }
            } else {
                callback();
            }
        })
    },

    // Function to delete single image from the s3 bucket
    async deleteSingleFileS3(dirName,fileName) {

        if(fileName == 'default-user.png') {
            // callback(1);
            return;
        }
        const AWS = require('aws-sdk');
        const s3 = new AWS.S3({
            accessKeyId: GLOBALS.S3_ACCESS_KEY,
            secretAccessKey: GLOBALS.S3_SECRET_KEY,
            region: GLOBALS.S3_REGION
        });

        let params = {
            Bucket: GLOBALS.S3_BUCKET_NAME, // pass your bucket name
            Key: dirName + fileName,  // file will be saved as user/xyz.png
        }

        s3.deleteObject(params,(err, data) => {
            if (err) {
                console.log(err, err.stack); // error
                // callback("0");
            } else {
                // callback("1");
            }
        });
    },

    // Function to delete multiple image from the s3 bucket
    deleteMultipleFileS3: function(dirName, filesName, keyname, callback) {
        const AWS = require('aws-sdk');
        const s3 = new AWS.S3({
            accessKeyId: GLOBALS.S3_ACCESS_KEY,
            secretAccessKey: GLOBALS.S3_SECRET_KEY,
            region: GLOBALS.S3_REGION
        });

        var deleteObjects = [];
        asyncLoop(filesName, function(item, next) {
            if(item.image == 'default.png') {
                next();
            } else {
                deleteObjects.push({Key: dirName + item.image});  // file will be saved as user/xyz.png
                next();    
            }
        },function() {             
            var options = {
                Bucket: GLOBALS.BUCKET_NAME, // pass your bucket names
                Delete: {
                    Objects: deleteObjects
                }
            };      
            s3.deleteObjects(options, function(err, data) {
                if (err) {
                    callback("0");
                } else {
                    callback("1");
                }
            });
        });
    },
}
module.exports = common;