const dotenv = require('dotenv');
dotenv.config();
module.exports = {
    // ======================================================================================
    //                                      APP
    // ======================================================================================
    'APP_NAME'              : "GreenJom",
    'BASE_URL'              : 'http://52.63.169.227/',
    'PORT_BASE_URL'         : 'http://52.63.169.227:9999/',
    'PORT'                  : process.env.PORT,
    'LOGO'                  : "http://52.63.169.227/api/public/images/icons/logo.jpg",
    'FAVICON'               : "http://52.63.169.227/api/public/images/icons/favicon.jpg",
    'API_KEY'               : process.env.API_KEY,
    'ENC_KEY'               : process.env.ENC_KEY,
    'ENC_IV'                : process.env.ENC_IV,
    'STATIC_DOC_PASSWORD'   : process.env.STATIC_DOC_PASSWORD,
    'EMAIL_REGEX'           : /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/,

    // ======================================================================================
    //                                 EMAIL & PASSWORD
    // ======================================================================================
    'EMAIL_ID'              : process.env.EMAIL_ID,
    'EMAIL_PASSWORD'        : process.env.EMAIL_PASSWORD,

    // ======================================================================================
    //                                SMS GATEWAY
    // ======================================================================================
    'SMS_API_KEY'           : "",

    // ======================================================================================
    //                                  AWS S3 BUCKET
    // ======================================================================================
    'S3_BUCKET_NAME'        : process.env.S3_BUCKET_NAME,
    'S3_ACCESS_KEY'         : process.env.S3_ACCESS_KEY,
    'S3_SECRET_KEY'         : process.env.S3_SECRET_KEY,
    'S3_REGION'             : process.env.S3_REGION,
    'S3_FOLDER_NAME'        : process.env.S3_FOLDER_NAME,
    'S3_URL'                : 'https://greenjoms3.s3.eu-central-1.amazonaws.com/',

    // ======================================================================================
    //                                 IMAGE & VIDEO PATH
    // ======================================================================================
    'USER_IMAGE'            : 'user/',
    'TSHEET_IMAGE'          : 'tsheet/',
    'TSHEET_MAP_IMAGE'      : 'tsheet/map/',
    'OFFER_IMAGE'           : 'offer/',
    'CHAT_IMAGE'            : 'chat/',
    'FEED_IMAGE'            : 'feed/',

    // ======================================================================================
    //                                      LIMIT
    // ======================================================================================
    "PER_PAGE"              : 10,
    "HOME_PAGE"             : 5,
    "CHAT_PER_PAGE"         : 10,
    "NOTIFICATION_PER_PAGE" : 20,

    // ======================================================================================
    //                                   NOTIFICATION
    // ======================================================================================
    "GCM_PUSH_KEY"          :  "",
    "APN_PUSH_KEY"          :  "",
    "KEYID"                 :  "",
    "TEAMID"                :  "",
    "BUNDLEID"              :  "",
    "TEAMBUNDLEID"          :  "",
}