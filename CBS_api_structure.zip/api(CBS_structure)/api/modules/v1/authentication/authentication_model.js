const con = require('../../../config/database');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const common = require('../../../config/common');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);

module.exports = {
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              API USER LIST                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    api_user_list: function(callback) 
    {
        con.query("SELECT ud.token, ud.device_token, ud.device_type, u.first_name, u.last_name, u.country_code, u.mobile_number FROM tbl_user as u JOIN tbl_user_device as ud ON ud.user_id = u.id ORDER BY u.id DESC", function(err, result) {
            if (!err && (result[0] != undefined)) {
                callback(result)
            } else {
                callback(null)
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Signup                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async signup(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`INSERT INTO tbl_user SET ?`, params, function(err, result) {
                if(!err && result != undefined) {
                    // if(referal_code){
                    //     // logic for referral code if use
                    //     resolve(result);
                    // } else {
                        resolve(result);
                    // }
                }
                else {
                    reject();
                }
            });
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Update Verify                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async checkVerify(params)
    {
        return new Promise((resolve,reject)=>{
            let where = ``;
            if(params.flag == "email"){
                where = `email = '${params.username}'`;
            }else{
                where = `country_code = '${params.country_code}' AND mobile_number = '${params.username}'`;
            }
            con.query(`SELECT id FROM tbl_verification WHERE ${where} LIMIT 1`, (err, result) => {
                var data = {
                    otp : params.otp,
                    is_active : 'Active',
                    insert_datetime : moment().format("X")
                }
                if(params.flag == "email"){
                    data.email = params.username;
                }else{
                    data.country_code = params.country_code;
                    data.mobile_number = params.mobile_number;
                }
                if(!err & result[0] != undefined) {
                    con.query(`UPDATE tbl_verification SET ? WHERE id = '${result[0].id}'`, data, (uErr, uResult) => {
                        if(!uErr) {
                            params.insert_datetime = data.insert_datetime;
                            this.update_forgot_password_details(params);
                            resolve();
                        }
                        else {
                            reject();
                        }
                    });
                }
                else{
                    con.query(`INSERT INTO tbl_verification SET ?`, data, (iErr, iResult) => {
                        if(!iErr) {
                            params.insert_datetime = data.insert_datetime;
                            this.update_forgot_password_details(params);
                            resolve();
                        }
                        else {
                            reject();
                        }
                    });
                }
            });
        });
    },
    async update_forgot_password_details(params)
    {
        if(params.type == "forgot"){
            let forgot_with = (params.flag == "email") ? 'email' : 'mobile_number';
            let updateData = {
                forgot_with: forgot_with,
                forgot_otp: params.otp,
                forgot_datetime: params.insert_datetime
            }
            common.update_data(`tbl_user`,`id = ${params.user_id}`,updateData)
        }
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Verify OTP                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async verify_otp(params)
    {
        return new Promise((resolve,reject)=>{
            let where = ``;
            let flag = 'email';
            if(GLOBALS.EMAIL_REGEX.test(params.username) == true){
                where = `AND email = '${params.username}'`;
            }else{
                flag = 'mobile';
                where = `AND country_code = '${params.country_code}' AND mobile_number = '${params.username}'`;
            }
            con.query(`SELECT id FROM tbl_verification WHERE otp = '${params.otp}' AND is_active = 'Active' ${where} LIMIT 1`,(err, result) => {
                if(!err && result[0] != undefined) {
                    con.query(`UPDATE tbl_verification SET is_active = 'Inactive' WHERE id = '${result[0].id}'`,(err, update) => {
                        if(flag == "email"){
                            con.query(`UPDATE tbl_user SET is_email_verify = 'Verify' WHERE ${where.slice(3)}`,(uErr,uResult)=>{
                                resolve();
                            })
                        }else{
                            resolve();
                        }
                    });
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Signin                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async signin(params) {
        return new Promise((resolve,reject)=>{
            const star = `id,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',profile_image) AS profile_image,country_code,mobile_number,first_name,last_name,birth_date,username,is_email_verify,social_id,password,email,two_step_verification,wallet_balance`;

            con.query({sql:`SELECT ${star} FROM tbl_user WHERE is_active != 'Delete' AND login_with = '${params.login_with}' AND email = '${params.email}'`
                , typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err, result) => {
                if(!err) {
                    if(result[0] != undefined) {
                        if(result[0].is_active == "Inactive"){
                            resolve({code:3});
                        } else if(params.login_with == "Simple" && result[0].password == (cryptoLib.encrypt(params.password,shaKey,GLOBALS.ENC_KEY))) {
                            resolve({code:1,data:result[0]});
                        } else if (params.login_with != "Simple" && result[0].social_id == (cryptoLib.encrypt(params.social_id,shaKey,GLOBALS.ENC_KEY))) {
                            resolve({code:1,data:result[0]});
                        } else {
                            if(result[0].social_id != ""){
                                resolve({code:4});
                            } else {
                                reject();
                            }
                        }
                    } else if(params.login_with != "Simple" && result[0] == undefined) {
                        resolve({code:11});
                    } else {
                        reject();
                    }
                }
                else {
                    reject();
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Edit Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async edit_check_unique(id, params, callback) {
        if(params.is_email == "false" || params.is_email == false){
            this.edit_unique_fields('mobile_number', id, params.mobile_number).then((mobile_number) => {
                callback(true);
            }).catch((error)=>{
                callback(false, params.mobile_number);
            });
        }else{
            this.edit_unique_fields('email', id, params.email).then((email) => {
                callback(true);
            }).catch((error)=>{
                callback(false, params.email);
            })
        }
    },
    async edit_unique_fields(field, id, params) {
        return new Promise((resolve,reject)=>{
            if(params != '') {
                con.query(`SELECT id FROM tbl_user WHERE ${field} = "${params}" AND is_active != "Delete" LIMIT 1`, (err, result) => {
                    if(result.length == 1 && result[0].id == id){
                        resolve();
                    }
                    else if(result.length == 0){
                        resolve();
                    }
                    else{
                        reject();
                    }
                });
            } else {
                resolve();
            }
        });
    },
    edit_profile: function(user_id, params) {
        return new Promise((resolve,reject)=>{
            con.query(`UPDATE tbl_user SET ? WHERE id = '${user_id}'`, params,(err, result)=>{
                if (!err) {
                    this.user_details({"user_id": user_id}).then((response)=>{
                        delete response.password;
                        resolve(response)
                    }).catch((err)=>{
                        reject()
                    })
                } else {
                    reject()
                }
            });
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Get Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async user_details(params) {
        return new Promise((resolve,reject)=>{
            var where = ``;
            if(params.user_id) {
                where = `AND id = '${params.user_id}'`;
            } else {
                if(params.email) {
                    where = `AND email = '${params.email}'`;
                } else {
                    where = `AND (mobile_number = '${params.mobile_number}' AND country_code = '${params.country_code}')`;
                }
            }
            con.query({sql:`SELECT id,login_with,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',profile_image) AS profile_image,country_code,mobile_number,email,password,first_name,last_name,username,is_email_verify,birth_date,two_step_verification,wallet_balance FROM tbl_user WHERE is_active = 'Active' ${where}`, typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err, result) => {
                if(!err && result[0] != undefined) {
                    result[0].follower = 0;
                    result[0].following = 0;
                    result[0].post = 0;
                    resolve(result[0]);
                }
                else {
                    reject();
                }
            });
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Get Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async enable_disable_two_step_verification(params) {
        return new Promise((resolve,reject)=>{
            con.query(`UPDATE tbl_user SET ? WHERE id = '${params.login_user_id}'`,{two_step_verification:params.is_two_step},(err,result)=>{
                if (!err) {
                    resolve()
                } else {
                    reject()
                }
            });
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Get Profile With Token                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async user_details_with_token(params) {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT user_id FROM tbl_user_device WHERE token = '${cryptoLib.decrypt(params.token, shaKey, GLOBALS.ENC_IV)}' LIMIT 1`, (err, result) => {
                if(!err && result[0] != undefined) {
                    resolve(result[0]);
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Reset Password                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async reset_password(params) {
        return new Promise((resolve,reject)=>{
            let password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV);
            let where = ``;
            if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
                where = `mobile_number = '${params.username}' AND country_code = '${params.country_code}'`;
            }else{
                where = `email = '${params.username}'`;
            }
            con.query(`UPDATE tbl_user SET password = '${password}' WHERE ${where}`,(err,result)=>{
                if(!err) {
                    con.query(`SELECT id FROM tbl_user WHERE ${where}`,(uErr,uResult)=>{
                        this.logout(uResult[0].id,()=>{})
                        resolve()
                    })
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                   Logout                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async logout(id) {
        return new Promise((resolve,reject)=>{
            con.query(`UPDATE tbl_user_device SET token = '',device_token = '' WHERE user_id = '${id}'`,(err)=>
            {
                resolve()
            })
        })
    }
}