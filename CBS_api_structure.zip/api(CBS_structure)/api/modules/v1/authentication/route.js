const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const lang = require("../../../config/language");
const authentication_model = require('./authentication_model');
const common = require('../../../config/common');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32); 

const router = require('express').Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Check Unique                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/check_unique', async (req, res) =>
{
    let params = req.body;
    const rules =  {
        is_email: "required",
        is_signup: "required"
    }
    if(params.is_email == "false" || params.is_email == false){
        rules.country_code = "required";
        rules.mobile_number = "required";
    }else{
        rules.email = "required|email";
    }
    if(common.checkValidation(params, rules, res, req.language))
    {
        if(params.is_signup == "true" || params.is_signup == true) {
            common.check_unique(params,(response, val, field) => {
                if(response) {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
                }
                else {
                    common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
                }
            });
        } else {
            if(req.headers['token']) {
                authentication_model.user_details_with_token({'token':req.headers['token']}).then((resData)=>{
                    authentication_model.edit_check_unique(resData.user_id, params, (response, val) => {
                        if(response) {
                            common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
                        }
                        else {
                            common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
                        }
                    });
                }).catch((error)=>{
                    common.sendResponse(res, "0", lang[req.language]['get_no_profile_data'], null);
                });
            } else {
                common.sendResponse(res, "-1", lang[req.language]['text_rest_tokeninvalid'], null, '401');
            }
        }
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Check Unique Username                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/check_unique_username', async (req, res) =>
{
    let params = req.body;
    const rules =  { username: "required" }
    if(common.checkValidation(params, rules, res, req.language))
    {
        common.check_unique_username(params,(response, val, field) => {
            if(response) {
                common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
            }
            else {
                common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
            }
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Send OTP                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/send_otp", async (req, res) => {
    let params = req.body;
    const rules = {
        username: 'required',
        type: 'required:in:signup,forgot'
    }
    if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
        rules.country_code = "required";
    }
    if(common.checkValidation(params, rules, res, req.language)) {
        let flag = 'email';
        if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
            flag = 'mobile number';
            params.mobile_number = params.username;
        }else{
            params.email = params.username;
        }
        params.flag = flag;
        if(params.type == "signup") {
            common.check_unique(params,(response, val, field) => {
                if(response) {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
                }
                else {
                    if(flag == "email"){
                        //send otp
                        const template = require('../../../config/template');
                        params.otp = Math.floor(1000 + Math.random() * 9000);
                        template.send_otp(params.otp,(html)=>{
                            common.send_email(GLOBALS.APP_NAME,params.username,html).then((resEmail)=>{
                                authentication_model.checkVerify(params).then((response) => {
                                    common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}','email'), null);
                                }).catch((error)=>{
                                    common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                                });
                            }).catch((error)=>{
                                common.sendResponse(res, "0", lang[req.language]['otp_not_send'].replace('{field}',flag), null);
                            });
                        });
                    }else{
                        //send otp
                        params.otp = 1234;
                        common.send_sms(params.country_code+params.mobile_number,params.otp,'').then((resMobile)=>{
                            authentication_model.checkVerify(params).then((response) => {
                                common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}','mobile number'), null);
                            }).catch((error)=>{
                                common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                            });
                        }).catch((error)=>{
                            common.sendResponse(res, "0", lang[req.language]['otp_not_send'], null);
                        });
                    }
                }
            });
        } else {
            if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
                var where = { country_code:params.country_code, mobile_number: params.username }
            }else{
                var where = { email: params.username }
            }
            authentication_model.user_details(where).then((response)=> {
                if(response.login_with == "Simple"){
                    if(flag == "email"){
                        //send otp
                        const template = require('../../../config/template');
                        params.otp = Math.floor(1000 + Math.random() * 9000);
                        template.send_otp(params.otp,(html)=>{
                            common.send_email(GLOBALS.APP_NAME,params.username,html).then((resEmail)=>{
                                authentication_model.checkVerify(params).then((response) => {
                                    common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}','email'), null);
                                }).catch((error)=>{
                                    common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                                });
                            }).catch((error)=>{
                                common.sendResponse(res, "0", lang[req.language]['otp_not_send'].replace('{field}',flag), null);
                            });
                        });
                    }else{
                        //send otp
                        params.otp = 1234;
                        common.send_sms(params.country_code+params.mobile_number,params.otp,'').then((resMobile)=>{
                            authentication_model.checkVerify(params).then((response) => {
                                common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}','mobile number'), null);
                            }).catch((error)=>{
                                common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                            });
                        }).catch((error)=>{
                            common.sendResponse(res, "0", lang[req.language]['otp_not_send'], null);
                        });
                    }
                }else{
                    common.sendResponse(res, "0", lang[req.language]['text_user_email_register_with_social'].replace('{flag}',flag), null);
                }
            }).catch((error)=>{
                common.sendResponse(res, "0", lang[req.language]['text_user_login_new'].replace('{flag}',flag), null);
            });
        }
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Verify OTP                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/verify_otp", async (req, res) => {
    let params = req.body;
    const rules = {
        username: "required",
        otp: "required",
        type: "required:in:signup,forgot"
    }
    if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
        rules.country_code = "required";
    }
    if(common.checkValidation(params, rules, res, req.language)) {
        if(params.type == "signup"){
            if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
                params.mobile_number = params.username;
            }else{
                params.email = params.username;
            }
            common.check_unique(params,(response, val) => {
                if(response){
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
                }else{
                    authentication_model.verify_otp(params).then((response) => {
                        common.sendResponse(res, "1", lang[req.language]["text_verify_otp_success"], null);
                    }).catch((error)=>{
                        common.sendResponse(res, "0", lang[req.language]["text_invalid_otp"], null);
                    })
                }
            })
        }else{
            if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
                var where = { country_code:params.country_code, mobile_number: params.username }
            }else{
                var where = { email: params.username }
            }
            authentication_model.user_details(where).then((response)=>{
                authentication_model.verify_otp(params).then((response1) => {
                    if(params.type == "forgot"){
                        common.update_data(`tbl_user`,response.id, {is_forgot_verify: 1});
                    }
                    common.sendResponse(res, "1", lang[req.language]["text_verify_otp_success"], null);
                }).catch((error)=>{
                    common.sendResponse(res, "0", lang[req.language]["text_invalid_otp"], null);
                });
            }).catch((error)=>{
                common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
            });
        }
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signup                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signup', async (req, res) =>
{
    let params = req.body;
    const rules = {
        login_with: "required|in:Simple,Facebook,Google,Apple",
        email: "required|email",
        country_code: "required",
        mobile_number: "required",
        birth_date: "required",
        device_token: "required",
        device_type: "required|in:Android,iOS",
        device_model: "required",
        uuid: "required",
        ip: "required"
    }
    if(params.login_with != "Simple"){
        rules.social_id = "required";
    }else{
        rules.password = "required";
    }
    if(common.checkValidation(params, rules, res, req.language))
    {
        common.check_unique(params,(response, val) => {
            if(response) {
                common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
            }
            else {
                var data =  {
                    "login_with" : params.login_with,
                    "email" : params.email,
                    "country_code" : params.country_code,
                    "mobile_number" : params.mobile_number,
                    "birth_date" : params.birth_date,
                    "insert_datetime" : moment().format("X")
                }
                if(params.login_with != "Simple"){
                    data.social_id = cryptoLib.encrypt(params.social_id, shaKey, GLOBALS.ENC_IV);
                    data.is_email_verify = 'Verify';
                }else{
                    data.password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV);
                }
                authentication_model.signup(data).then((result)=>{
                    common.checkDeviceInfo(result.insertId, params).then((resToken) => {
                        authentication_model.user_details({"user_id":result.insertId}).then((response)=>{
                            delete response.password;
                            response.token = resToken.token;
                            common.sendResponse(res, "1", lang[req.language]['text_user_signup_success'], response);
                        }).catch((err)=>{
                            common.sendResponse(res, "0", lang[req.language]['signup_unsuccess'], null);
                        })
                    }).catch((error)=>{
                        common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                    })
                }).catch((error)=>{
                    common.sendResponse(res, "0", lang[req.language]['signup_unsuccess'], null);
                })
            }
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signin                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signin',async (req,res)=>
{
    let params = req.body;
    const rules = {
        login_with: "required|in:Simple,Facebook,Google,Apple",
        email: "required",
        device_token: "required",
        device_type: "required|in:Android,iOS",
        device_model: "required",
        uuid: "required",
        ip: "required"
    }
    if(params.login_with != "Simple"){
        rules.social_id = "required";
    }else{
        rules.password = "required";
    }
    if(common.checkValidation(params, rules, res, req.language))
    {
        authentication_model.signin(params).then((response)=>{
            if(response.code == 3){
                common.sendResponse(res, 3, lang[req.language]["text_user_login_inactive"], null);
            }else if(response.code == 4){
                common.sendResponse(res, 0, lang[req.language]["signup_with_social"], null);
            }else if(response.code == 1){
                common.checkDeviceInfo(response.data.id, params).then((resToken)=>{
                    delete response.data.password;
                    response.data.token = resToken.token;
                    common.sendResponse(res, 1, lang[req.language]["signin_success"], response.data);
                }).catch((error)=>{
                    common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                });
            }else{
                common.sendResponse(res, 11, lang[req.language]["text_user_social_id_not_registered_yet"], response.data);
            }
        }).catch((err)=>{
            common.sendResponse(res, 0, lang[req.language]["text_user_login_fail"], null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Edit Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/edit_profile', async (req, res) =>
{
    let params = req.body;
    const rules =  {
        email: "required",
        country_code: "required",
        mobile_number: "required",
        birth_date: "required"
    }
    if(common.checkValidation(params, rules, res, req.language)) {
        authentication_model.edit_check_unique(req.login_user_id,params,(response,val)=>
        {
            if(response) {
                var data = {
                    "first_name" : (params.first_name) ? params.first_name : ``,
                    "last_name" : (params.last_name) ? params.last_name : ``,
                    "username" : (params.username) ? params.username : ``,
                    "birth_date" : params.birth_date,
                    "email" : params.email,
                    "country_code" : params.country_code,
                    "mobile_number" : params.mobile_number,
                    "update_datetime" : moment().format("X")
                }
                if(params.profile_image){
                    common.get_old_image_name_and_delete(`tbl_user`,`profile_image`,`id = ${req.login_user_id}`,GLOBALS.USER_IMAGE,()=>{});
                    data.profile_image = params.profile_image;
                }
                authentication_model.edit_profile(req.login_user_id, data).then((resData)=>{
                    common.sendResponse(res,'1',lang[req.language]['text_user_edit_profile_success'],resData);
                }).catch((err)=>{
                    common.sendResponse(res,'0',lang[req.language]['text_user_edit_profile_fail'],null);
                })
            }
            else {
                common.sendResponse(res,'0',lang[req.language]['unique_unsuccess'].replace('{val}',val),null);
            }
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Get Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_profile", async (req, res) => {
    let params = req.body;
    const rules = { user_id: "required" }
    if(common.checkValidation(params, rules, res, req.language))
    {
        authentication_model.user_details(params).then((response)=>{
            delete response.password;
            common.sendResponse(res,"1",lang[req.language]['get_profile_data'],response);
        }).catch((err)=>{
            common.sendResponse(res,"2",lang[req.language]['get_no_profile_data'],null);
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                          Two Step Verification                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/enable_disable_two_step_verification", async (req, res) => {
    let params = req.body;
    const rules = { is_two_step: "required|in:Yes,No" }
    if(common.checkValidation(params, rules, res, req.language))
    {
        params.login_user_id = req.login_user_id;
        authentication_model.enable_disable_two_step_verification(params).then((response)=>{
            common.sendResponse(res,"1",lang[req.language]['two_step_verification_su'].replace('{status}',(params.is_two_step == "Yes") ? `on` : `off`),null);
        }).catch((err)=>{
            common.sendResponse(res,"0",lang[req.language]['two_step_verification_un'].replace('{status}',(params.is_two_step == "Yes") ? `on` : `off`),null);
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Contact Us                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/contact_us", async (req, res) => {
    let params = req.body;
    const rules = {
        issue: "required",
        name: "required",
        country_code: "required",
        mobile_number: "required",
        email: "required|email",
        description: "required"
    }
    if(common.checkValidation(params, rules, res, req.language))
    {
        params.insert_datetime = moment().format("X");
        common.add_data('tbl_contact_us', params,()=>{
            common.sendResponse(res, "1", lang[req.language]["text_user_contactus_success"], null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Reset Password                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/reset_password", async (req, res) => {
    let params = req.body;
    var rules =  {
        username: 'required',
        password: 'required'
    }
    if(GLOBALS.EMAIL_REGEX.test(params.username) == false){
        rules.country_code = "required";
    }
    if(common.checkValidation(params, rules, res, req.language)) {
        authentication_model.reset_password(params).then((response)=>{
            common.sendResponse(res,'1',lang[req.language]['text_user_change_password_success'],null)
        }).catch((err)=>{
            console.log(err)
            common.sendResponse(res,'0',lang[req.language]['something_wrong'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Change Password                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/change_password', async (req, res) =>
{
    let params = req.body;
    const rules = {
        old_password : "required",
        new_password : "required",
        confirm_password : "required"
    }
    if(common.checkValidation(params, rules, res, req.language))
    {
        authentication_model.user_details({'user_id':req.login_user_id}).then((response)=>{
            if(cryptoLib.encrypt(params.old_password, shaKey, GLOBALS.ENC_IV) == response.password){
                if(params.new_password != params.old_password) {
                    if(params.new_password == params.confirm_password){
                        common.update_data(`tbl_user`,`id = ${req.login_user_id}`,{"password":cryptoLib.encrypt(params.new_password,shaKey,GLOBALS.ENC_IV)});
                        common.sendResponse(res, "1", lang[req.language]["text_user_change_password_success"], null);
                    }
                    else{
                        common.sendResponse(res, "0", lang[req.language]["text_new_confirm_password_not_match"], null);
                    }
                } else {
                    common.sendResponse(res, "0", lang[req.language]["text_old_new_password_same"], null);
                }
            }
            else{
                common.sendResponse(res, "0", lang[req.language]["text_user_change_password_fail"], null);
            }
        }).catch((err)=>{
            common.sendResponse(res, "0", lang[req.language]["get_no_profile_data"], null);
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                   Logout                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/logout", async (req, res) => {
    authentication_model.logout(req.login_user_id).then((resCode)=>{
        common.sendResponse(res, "1", lang[req.language]['text_user_logout'], null)
    }).catch((err)=>{
        common.sendResponse(res, "0", lang[req.language]['something_wrong'], null)
    })
});

module.exports = router;