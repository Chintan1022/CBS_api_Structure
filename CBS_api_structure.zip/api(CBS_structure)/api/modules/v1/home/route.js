const lang = require('../../../config/language');
const home_model = require('./home_model');
const {sendResponse,checkValidation} = require('../../../config/common');
const router = require('express').Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Club List                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/club_list",async(req,res)=>{
    let params = req.body;
    params.login_user_id = req.login_user_id
    home_model.club_list(params).then((resData)=>{
        sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
    }).catch((err)=>{
        sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Add Membership                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_membership",async(req,res)=>{
    let params = req.body;
    var rules =  {
        club_id: 'required',
        membership_id: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.add_membership(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_membership_added'],null)
        }).catch((err)=>{
            if(err.code == 3){
                sendResponse(res,"0",lang[req.language]['text_membership_already'],null);
            }else{
                sendResponse(res,"0",lang[req.language]['text_membership_not_added'],null);
            }
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Membership List                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/membership_list",async(req,res)=>{
    let params = req.body;
    var rules =  { page_token: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.membership_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Green List                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_list",async(req,res)=>{
    let params = req.body;
    var rules =  {
        is_favorite: 'required',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.green_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                        Green Favorite|Unfavorite                               /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_favorite_unfavorite",async(req,res)=>{
    let params = req.body;
    var rules =  { tsheet_id: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.green_favorite_unfavorite(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_tsheet_fav_unfav_su'].replace('{status}',resData.type),null)
        }).catch((err)=>{
            if(err.type != undefined){
                sendResponse(res,"0",lang[req.language]['text_tsheet_fav_unfav_un'].replace('{status}',err.type),null)
            }else{
                sendResponse(res,"0",lang[req.language]['something_wrong'],null)
            }
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Green Detail                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_detail",async(req,res)=>{
    let params = req.body;
    var rules =  { id: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = (req.login_user_id) ? req.login_user_id : '';
        home_model.green_detail(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Green Detail                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_extra_detail",async(req,res)=>{
    let params = req.body;
    var rules =  {
        id: 'required',
        date: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = (req.login_user_id) ? req.login_user_id : '';
        home_model.green_extra_detail(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Green Slot                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_slot",async(req,res)=>{
    let params = req.body;
    var rules = {
        id: 'required',
        ground_id: 'required',
        session: 'required|in:M,A',
        holes: 'required|in:18,9',
        buggy: 'required|in:Yes,No',
        caddie: 'required|in:Yes,No',
        date: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        home_model.green_slot(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Green Book                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_book",async(req,res)=>{
    let params = req.body;
    var rules = {
        id: 'required',
        ground_id: 'required',
        session: 'required|in:M,A',
        golfer: 'required',
        holes: 'required|in:18,9',
        buggy: 'required',
        caddie: 'required',
        trolly: 'required',
        date: 'required',
        timeslot: 'required',
        sst: 'required',
        online_pay_off: 'required',
        sub_total: 'required',
        discount: 'required',
        total: 'required',
        is_member: 'required|in:Yes,No',
        payment_at: 'required|in:Green,Online',
        payment_status: 'required|in:Unpaid,Paid'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.green_book(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_sql_err'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Booking Edit                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/booking_edit",async(req,res)=>{
    let params = req.body;
    var rules = {
        id: 'required',
        booking_id: 'required',
        ground_id: 'required',
        session: 'required|in:M,A',
        golfer: 'required',
        holes: 'required|in:18,9',
        buggy: 'required',
        caddie: 'required',
        trolly: 'required',
        date: 'required',
        timeslot: 'required',
        sst: 'required',
        online_pay_off: 'required',
        sub_total: 'required',
        discount: 'required',
        total: 'required',
        is_member: 'required|in:Yes,No',
        payment_at: 'required|in:Green,Online',
        payment_status: 'required|in:Unpaid,Paid'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.booking_edit(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_sql_err'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                My Booking                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/my_booking",async(req,res)=>{
    let params = req.body;
    var rules = {
        status: 'required|in:upcoming,past',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.my_booking(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Booking Detail                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/booking_detail",async(req,res)=>{
    let params = req.body;
    var rules = { id: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.booking_detail(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Activity                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/activity",async(req,res)=>{
    let params = req.body;
    var rules = {
        status: 'required|in:my,invitations,event',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.activity(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Select Time Slot                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/select_time_slot",async(req,res)=>{
    let params = req.body;
    var rules = { booking_id: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.select_time_slot(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Update Invitations Number                            /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/update_invitations_number",async(req,res)=>{
    let params = req.body;
    var rules = {
        slot_id: 'required',
        number_of_invite: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.update_invitations_number(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],null)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_sql_err'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Global User                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/global_user",async(req,res)=>{
    let params = req.body;
    var rules = {
        booking_id: 'required',
        slot_id: 'required',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.global_user(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Invitations Sent                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/invitations_sent",async(req,res)=>{
    let params = req.body;
    var rules = {
        booking_id: 'required',
        slot_id: 'required',
        user_id: 'required',
        status: 'required|in:pending,accept,reject,cancel_by_host'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.invitations_sent(params).then((resData)=>{
            if(resData == 3){
                sendResponse(res,"3",lang[req.language]['text_invitation_max_su'],{status:params.status})
            }else{
                let status = params.status
                params.status = (params.status == "pending") ? 'sent' : params.status;
                sendResponse(res,"1",lang[req.language]['text_invitation_su'].replace('{status}',params.status),{status:status})
            }
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_sql_err'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Attendance Sent                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/attendance_action",async(req,res)=>{
    let params = req.body;
    var rules = {
        booking_id: 'required',
        slot_id: 'required',
        status: 'required|in:accept,reject'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.attendance_action(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_attendance_su'].replace('{status}',params.status),null)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_sql_err'],null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Review Club                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/review_club",async(req,res)=>{
    let params = req.body;
    var rules = {
        tsheet_id: 'required',
        rating: 'required',
        review: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id
        home_model.review_club(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_tsheet_review_su'].replace('{status}',resData.type),null)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_tsheet_review_un'].replace('{status}',err.type),null)
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Review Club List                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/review_club_list",async(req,res)=>{
    let params = req.body;
    var rules =  {
        tsheet_id: 'required',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.review_club_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Follow & Unfollow Request                              /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/follow_unfollow",async(req,res)=>{
    let params = req.body;
    var rules =  { user_id: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.follow_unfollow(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_sql_err'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Green Deal List                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_deal_list",async(req,res)=>{
    let params = req.body;
    var rules =  {
        page_token: 'required',
        type: 'required|in:hot,booster'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.green_deal_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Green Deal Detail                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/green_deal_detail",async(req,res)=>{
    let params = req.body;
    var rules =  {
        type: 'required|in:hot,booster',
        id: 'required',
        date: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.green_deal_detail(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Available Promocode                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/available_promocode",(req,res)=>{
    let params = req.body;
    var rules = {
        tsheet_id: 'required',
        booking_date: 'required',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language))
    {
        params.login_user_id = req.login_user_id
        home_model.get_available_offer(params).then((resData)=>{
            sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
        }).catch((err)=>{
            sendResponse(res, "2", lang[req.language]['text_offer_no_available'], null)
        })
    }
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Verify Promocode                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/verify_promocode",(req,res)=>{
    let params = req.body;
    var rules = {
        promocode: 'required',
        booking_date: 'required'
    }
    if(checkValidation(params,rules,res,req.language))
    {
        params.login_user_id = req.login_user_id
        home_model.verify_promocode(params).then((resData)=>{
            if(resData.code == 1){
                sendResponse(res, "1", lang[req.language]['text_offer_verify_su'], resData.data)
            }else if(resData.code == 3){
                sendResponse(res, "3", lang[req.language]['text_offer_used_max_limit'], null)
            }else{
                sendResponse(res, "0", lang[req.language]['text_offer_verify_su'], null)
            }
        }).catch((err)=>{
            sendResponse(res, "0", lang[req.language]['text_offer_verify_un'], null)
        })
    }
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Rewards List                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/rewards_list",async(req,res)=>{
    let params = req.body;
    var rules =  { page_token: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        home_model.rewards_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_details_are'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_empty_list'],null)
        })
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Notification List                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/notification_list", function(req, res) {
    let params = req.body;
    var rules = { page_token : "required" }
    if(checkValidation(params, rules, res, req.language))
    {
        params.login_user_id = req.login_user_id
        params.language = req.language
        home_model.notification_list(params).then((resData)=>{
            sendResponse(res, "1", lang[req.language]['notification_list'], resData)
        }).catch((err)=>{
            sendResponse(res, "2", lang[req.language]['notification_list_not_found'], null)
        })
    }
})

module.exports = router;