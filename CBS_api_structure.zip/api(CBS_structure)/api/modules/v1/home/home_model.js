const con = require('../../../config/database');
const lang = require('../../../config/language');
const {S3_URL,TSHEET_IMAGE,PER_PAGE,TSHEET_MAP_IMAGE,USER_IMAGE,OFFER_IMAGE,NOTIFICATION_PER_PAGE} = require('../../../config/constants');
const {get_all_time_slot,add_data,prepare_notification} = require('../../../config/common');
const moment = require('moment');
const asyncLoop = require('node-async-loop');

module.exports = {

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Club List                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    club_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,name FROM tbl_t_sheet WHERE is_active = 'Active' AND id NOT IN (SELECT club_id FROM tbl_user_membership WHERE user_id = ${params.login_user_id}) ORDER BY name`,(err,result)=>{
                if(!err && result[0] != undefined) {
                    resolve(result);
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Add Membership                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_membership(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id FROM tbl_user_membership WHERE user_id = ${params.login_user_id} AND club_id = ${params.club_id} AND status != 'Rejected' LIMIT 1`,(mErr,mResult)=>{
                if(!mErr && mResult[0] != undefined){
                    reject({code:3});
                }else{
                    let insertData = {
                        user_id: params.login_user_id,
                        club_id: params.club_id,
                        membership_id: params.membership_id,
                        insert_datetime: moment().format('X')
                    }
                    con.query(`INSERT INTO tbl_user_membership SET ?`,insertData,(err,result)=>{
                        if(!err) {
                            resolve();
                        }
                        else {
                            reject({code:2});
                        }
                    });
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Membership List                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    membership_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT m.id,m.club_id,t.name,m.status,CONCAT('${S3_URL+TSHEET_IMAGE}',profile_image) AS profile_image,m.expiry_date FROM tbl_user_membership AS m JOIN tbl_t_sheet AS t ON t.id = m.club_id WHERE m.is_active = 'Active' AND m.user_id = ${params.login_user_id} ORDER BY m.id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result});
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Green List                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_list(params)
    {
        return new Promise((resolve,reject)=>{
            let select = ``;
            let join = ``;
            let where = ``;
            let order_by = ``;
            let group_by = ``;
            if(params.alphabetical){
                order_by = `ORDER BY t.name ${params.alphabetical}`;
            }
            if(params.rating){
                order_by = `ORDER BY t.rating ${params.rating}`;
            }
            if(params.price){
                order_by = `ORDER BY t.average_price ${params.price}`;
            }
            if(params.distance && params.latitude && params.longitude){
                order_by = `ORDER BY distance ${params.distance}`;
            }
            if(params.latitude && params.longitude){
                select = `,ROUND((6371 * acos( cos( radians(${params.latitude}) ) * cos( radians( t.latitude ) ) * cos( radians( t.longitude ) - radians(${params.longitude}) ) + sin( radians(${params.latitude}) ) * sin( radians( t.latitude ) ) ) ), 2) AS distance`;
            }
            if(params.search){
                where = `AND LOWER(t.name) LIKE ('%${params.search.toLowerCase()}%')`;
            }
            if(params.is_favorite){
                join = `JOIN tbl_user_favorite_tsheet AS ft ON ft.tsheet_id = t.id`;
                where += `AND ft.user_id = ${params.login_user_id} AND ft.type = 'Favorite'`
            }
            if(params.date){
                join = `JOIN tbl_schedule AS s ON s.tsheet_id = t.id`;
                where += `AND s.date = '${params.date}'`;
                group_by = `GROUP BY t.id`;
            }
            con.query(`SELECT t.id,t.rating,t.profile_image,t.name,t.location,t.average_price AS price${select} FROM tbl_t_sheet AS t ${join} WHERE t.is_active = 'Active' ${where} ${group_by} ${order_by} LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        var images = [];
                        asyncLoop(item.profile_image.split(','),(item_image,next_image)=>{
                            images.push(S3_URL+TSHEET_IMAGE+item_image);
                            next_image();
                        },()=>{
                            item.profile_image = images[0];
                            item.images = images
                            this.check_green_favorite_unfavorite(params.login_user_id,item.id).then((res)=>{
                                item.is_favorite = true;
                                next();
                            }).catch((err)=>{
                                item.is_favorite = false;
                                next();
                            });
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result});
                    });
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Green Favorite|Unfavorite                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_favorite_unfavorite(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,type FROM tbl_user_favorite_tsheet WHERE user_id = ${params.login_user_id} AND tsheet_id = ${params.tsheet_id} AND is_active = 'Active' LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined) {
                    let data = {
                        type: (result[0].type == 'Favorite') ? `Unfavorite` : `Favorite`,
                        update_datetime: moment().format("X")
                    }
                    con.query(`UPDATE tbl_user_favorite_tsheet SET ? WHERE id = ${result[0].id}`,data,(uErr,uResult)=>{
                        if(!uErr){
                            resolve({type:data.type});
                        }else{
                            reject({type:data.type});
                        }
                    });
                }
                else {
                    let data = {
                        user_id: params.login_user_id,
                        tsheet_id: params.tsheet_id,
                        type: 'Favorite',
                        insert_datetime: moment().format("X")
                    }
                    con.query(`INSERT INTO tbl_user_favorite_tsheet SET ?`,data,(iErr,iResult)=>{
                        if(!iErr){
                            resolve({type:data.type});
                        }else{
                            reject({type:data.type});
                        }
                    });
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Green Detail                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_detail(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,rating,profile_image,CONCAT('${S3_URL+TSHEET_MAP_IMAGE}',map_image) AS map_image,name,location,latitude,longitude,total_rating,description,average_price AS price,length,par,holes,buggy_is_mandatory,caddie_is_mandatory,how_many_buggy,how_many_caddie,total_buggy,total_caddie,sst,online FROM tbl_t_sheet WHERE id = ${params.id} AND is_active = 'Active' LIMIT 1`,async (err,result)=>{
                if(!err && result[0] != undefined) {
                    let images = [];
                    asyncLoop(result[0].profile_image.split(','),(item,next)=>{
                        images.push(S3_URL+TSHEET_IMAGE+item);
                        next();
                    },()=>{
                        result[0].profile_image = images[0];
                        result[0].images = images;
                        this.get_course(params.id).then((resGround)=>{
                            if(params.login_user_id){
                                this.check_green_favorite_unfavorite(params.login_user_id,result[0].id).then((res)=>{
                                    result[0].is_favorite = true;
                                    resolve({green:result[0],ground:resGround,golfer:4});
                                }).catch((err)=>{
                                    result[0].is_favorite = false;
                                    resolve({green:result[0],ground:resGround,golfer:4});
                                });
                            }else{
                                result[0].is_favorite = false;
                                resolve({green:result[0],ground:resGround,golfer:4});
                            }
                        });
                    });
                }
                else {
                    reject();
                }
            });
        });
    },
    check_green_favorite_unfavorite(user_id,tsheet_id){
        return new Promise((resolve,reject)=>{
            con.query(`SELECT type FROM tbl_user_favorite_tsheet WHERE user_id = ${user_id} AND tsheet_id = ${tsheet_id} AND type = 'Favorite' LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve();
                }else{
                    reject();
                }
            });
        });
    },
    get_course(id){
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,name,holes FROM tbl_ground WHERE tsheet_id = ${id} AND is_active = 'Active'`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve(result);
                }else{
                    resolve([]);
                }
            });
        });
    },
    green_extra_detail(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT ground_id,first_tee_off_time,last_tee_off_time,tbox10_first_tee_off_time,tbox10_last_tee_off_time,tee_off_interval,is_break,start_break_time,end_break_time FROM tbl_schedule WHERE is_active = 'Active' AND tsheet_id = ${params.id} AND date = '${params.date}'`,(err,result)=>{
                if(!err && result[0] != undefined){
                    con.query(`SELECT IFNULL(SUM(buggy),0) AS buggy,IFNULL(SUM(caddie),0) AS caddie FROM tbl_booking WHERE tsheet_id = ${params.id} AND date = '${params.date}' LIMIT 1`,(tErr,tResult)=>{
                        let response = {
                            result:result,
                            total_use_buggy:tResult[0].buggy,
                            total_use_caddie:tResult[0].caddie
                        }
                        resolve(response);
                    });
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Green Slot                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_slot(params)
    {
        return new Promise((resolve,reject)=>{
            let first_tee_off_time = (params.session == "M") ? `AND first_tee_off_time < '12:00:00'` : `AND first_tee_off_time >= '12:00:00'`;
            con.query(`SELECT id,tsheet_id,first_tee_off_time,last_tee_off_time,tbox10_first_tee_off_time,tbox10_last_tee_off_time,tee_off_interval,is_break,start_break_time,end_break_time,weekend_dates,booster_slot_tbox01,booster_slot_tbox10,barter_slot_tbox01,barter_slot_tbox10,hot_deal_slot_tbox01,hot_deal_slot_tbox10,non_member_slot FROM tbl_schedule WHERE is_active = 'Active' AND tsheet_id = ${params.id} AND date = '${params.date}' ${first_tee_off_time} AND ground_id = ${params.ground_id} AND holes = ${params.holes} LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    // booster slot
                    result[0].booster_slot_tbox01 = (result[0].booster_slot_tbox01 != '') ? JSON.parse(result[0].booster_slot_tbox01) : [];
                    result[0].booster_slot_tbox10 = (result[0].booster_slot_tbox10 != '') ? JSON.parse(result[0].booster_slot_tbox10) : [];
                    // barter slot
                    result[0].barter_slot_tbox01 = (result[0].barter_slot_tbox01 != '') ? JSON.parse(result[0].barter_slot_tbox01) : [];
                    result[0].barter_slot_tbox10 = (result[0].barter_slot_tbox10 != '') ? JSON.parse(result[0].barter_slot_tbox10) : [];
                    // hot deal slot
                    result[0].hot_deal_slot_tbox01 = (result[0].hot_deal_slot_tbox01 != '') ? JSON.parse(result[0].hot_deal_slot_tbox01) : [];
                    result[0].hot_deal_slot_tbox10 = (result[0].hot_deal_slot_tbox10 != '') ? JSON.parse(result[0].hot_deal_slot_tbox10) : [];
                    let is_tbox10 = (result[0].tbox10_first_tee_off_time == "00:00:00" && result[0].tbox10_last_tee_off_time == "00:00:00") ? false : true;
                    let weekend_dates = result[0].weekend_dates.split(',').map(function(item){
                        return item.trim();
                    });
                    let type = (weekend_dates.indexOf(params.date) !== -1) ? `weekend` : `weekday`;
                    result[0].tsheet_id = params.id;
                    result[0].date = params.date;
                    result[0].holes = params.holes;
                    this.green_slot_tbox01(result[0],type).then((tbox01_timeslot)=>{
                        this.green_slot_tbox10(result[0],type).then((tbox10_timeslot)=>{
                            let response = {
                                tbox01:tbox01_timeslot.slot,
                                tbox10:(is_tbox10)?tbox10_timeslot.slot:[],
                                non_member_slot: result[0].non_member_slot,
                                total_non_member_booking: parseInt(tbox01_timeslot.total_non_member_booking)+((is_tbox10)?parseInt(tbox10_timeslot.total_non_member_booking):0)
                            }
                            resolve(response);
                        });
                    });
                }else{
                    reject();
                }
            });
        });
    },
    green_slot_tbox01(params,type)
    {
        return new Promise((resolve,reject)=>{
            let timeslot = get_all_time_slot(params.first_tee_off_time,params.last_tee_off_time,params.tee_off_interval);
            let tbox01_timeslot = [];
            let total_non_member_booking = 0;
            asyncLoop(timeslot,(item,next)=>{
                if((!(item >= params.start_break_time && item <= params.end_break_time)) || (params.start_break_time == "00:00:00" && params.end_break_time == "00:00:00")){
                    let price_type = (params.is_break == "Yes" && item > params.end_break_time) ? `${type}_pm` :  `${type}_am`;
                    this.green_single_pricing(params.tsheet_id,params.holes,price_type).then((resPricing)=>{
                        this.get_booking_detail(params,item,`tbox01`).then((resReserved)=>{
                            this.get_deals(params,`tbox01`,item).then((resDeals)=>{
                                if(resReserved.is_member){
                                    total_non_member_booking++;
                                }
                                tbox01_timeslot.push({
                                    time: item,
                                    is_reserved: resReserved.is_reserved,
                                    pricing: resPricing,
                                    deals: resDeals
                                });
                                next();
                            });
                        });
                    });
                }else{
                    next();
                }
            },()=>{
                resolve({
                    slot: tbox01_timeslot,
                    total_non_member_booking: total_non_member_booking
                });
            });
        });
    },
    green_slot_tbox10(params,type)
    {
        return new Promise((resolve,reject)=>{
            let timeslot = get_all_time_slot(params.tbox10_first_tee_off_time,params.tbox10_last_tee_off_time,params.tee_off_interval);
            let tbox10_timeslot = [];
            let total_non_member_booking = 0;
            asyncLoop(timeslot,(item,next)=>{
                if((!(item >= params.start_break_time && item <= params.end_break_time)) || (params.start_break_time == "00:00:00" && params.end_break_time == "00:00:00")){
                    let price_type = (params.is_break == "Yes" && item > params.end_break_time) ? `${type}_pm` :  `${type}_am`;
                    this.green_single_pricing(params.tsheet_id,params.holes,price_type).then((resPricing)=>{
                        this.get_booking_detail(params,item,`tbox10`).then((resReserved)=>{
                            this.get_deals(params,`tbox10`,item).then((resDeals)=>{
                                if(resReserved.is_member){
                                    total_non_member_booking++;
                                }
                                tbox10_timeslot.push({
                                    time: item,
                                    is_reserved: resReserved.is_reserved,
                                    pricing: resPricing,
                                    deals: resDeals
                                });
                                next();
                            });
                        });
                    });
                }else{
                    next();
                }
            },()=>{
                resolve({
                    slot: tbox10_timeslot,
                    total_non_member_booking: total_non_member_booking
                });
            });
        });
    },
    green_single_pricing(tsheet_id,holes,type)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT green_fee,buggy,caddy,insurance,extra_buggy,trolley,golfer_type FROM tbl_t_sheet_pricing WHERE tsheet_id = ${tsheet_id} AND holes = '${holes}' AND type = '${type}'`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve(result);
                }else{
                    resolve([]);
                }
            });
        });
    },
    get_booking_detail(params,time,type){
        return new Promise((resolve,reject)=>{
            con.query(`SELECT bs.id,bs.booking_id FROM tbl_booking_slot AS bs JOIN tbl_booking AS b ON b.id = bs.booking_id WHERE bs.date = '${params.date}' AND bs.time = '${time}' AND bs.type = '${type}' AND bs.is_active = 'Active' AND b.tsheet_id = ${params.tsheet_id} LIMIT 1`,(err,result)=>{
                con.query(`SELECT is_member FROM tbl_booking WHERE id = ${(!err && result[0]) ? result[0].booking_id : 0} LIMIT 1`,(bErr,bResult)=>{
                    resolve({
                        is_reserved: (!err && result[0]) ? true : false,
                        is_member: (!bErr && bResult[0] && bResult[0].is_member == "No") ? true : false
                    });
                });
            });
        });
    },
    get_deals(params,type,time){
        return new Promise((resolve,reject)=>{
            time = moment(time,'HH:mm');
            time = new moment(time).format('hh:mm A');
            let deals = {
                is_booster: false,
                booster_value: 1.5,
                is_barter: false,
                is_hot_deal: false,
                hot_deal_value: 1.5
            };
            if(type == "tbox01"){
                let booster = (params.booster_slot_tbox01 != null) ? params.booster_slot_tbox01.find(element=>element.time == time) : undefined;
                let barter = (params.barter_slot_tbox01 != null) ? params.barter_slot_tbox01.find(element=>element == time) : undefined;
                let hot_deal = (params.hot_deal_slot_tbox01 != null) ? params.hot_deal_slot_tbox01.find(element=>element.time == time) : undefined;
                if(booster != undefined){
                    deals.is_booster = true;
                    deals.booster_value = parseFloat(booster.value);
                }
                if(barter != undefined){
                    deals.is_barter = true;
                }
                if(hot_deal != undefined){
                    deals.is_hot_deal = true;
                    deals.hot_deal_value = parseFloat(hot_deal.value);
                }
            }else if(type == "tbox10"){
                let booster = (params.booster_slot_tbox10 != null) ? params.booster_slot_tbox10.find(element=>element.time == time) : undefined;
                let barter = (params.barter_slot_tbox10 != null) ? params.barter_slot_tbox10.find(element=>element == time) : undefined;
                let hot_deal = (params.hot_deal_slot_tbox10 != null) ? params.hot_deal_slot_tbox10.find(element=>element.time == time) : undefined;
                if(booster != undefined){
                    deals.is_booster = true;
                    deals.booster_value = parseFloat(booster.value);
                }
                if(barter != undefined){
                    deals.is_barter = true;
                }
                if(hot_deal != undefined){
                    deals.is_hot_deal = true;
                    deals.hot_deal_value = parseFloat(hot_deal.value);
                }
            }
            resolve(deals)
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Green Book                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_book(params)
    {
        return new Promise((resolve,reject)=>{
            let insertData = {
                user_id: params.login_user_id,
                tsheet_id: params.id,
                ground_id: params.ground_id,
                golfer: params.golfer,
                session: (params.session == `M`) ? `Morning` : `Afternoon`,
                holes: params.holes,
                buggy: params.buggy,
                caddie: params.caddie,
                trolly: params.trolly,
                date: params.date,
                sst: params.sst,
                online_pay_off: params.online_pay_off,
                sub_total: params.sub_total,
                discount: params.discount,
                total: params.total,
                is_member: params.is_member,
                payment_at: params.payment_at,
                payment_status: params.payment_status,
                ...(params.remarks) && {remarks: params.remarks},
                insert_datetime: moment().format('X')
            }
            if(params.promocode){
                insertData.promocode = JSON.stringify(params.promocode);
            }
            con.query(`INSERT INTO tbl_booking SET ?`,insertData,(err,result)=>{
                if(!err) {
                    let date = new Date();
                    let order_id = `O${date.getFullYear()}${date.getMonth()+1}${date.getDate()}-${result.insertId}`;
                    con.query(`UPDATE tbl_booking SET order_id = '${order_id}' WHERE id = ${result.insertId}`);
                    // let timeslot = [];
                    asyncLoop(params.timeslot,(item,next)=>{
                        // timeslot.push([result.insertId,params.date,item.time,item.type,params.golfer,JSON.stringify(item.guest),JSON.stringify(item.member),item.is_booster,item.booster_value,item.is_barter,item.is_hot_deal,item.hot_deal_value,moment().format('X')]);
                        let insertSlot = {
                            booking_id: result.insertId,
                            date: params.date,
                            time: item.time,
                            type: item.type,
                            number_of_invite: params.golfer,
                            guest: JSON.stringify(item.guest),
                            member: JSON.stringify(item.member),
                            is_booster: item.is_booster,
                            booster_value: item.booster_value,
                            is_barter: item.is_barter,
                            is_hot_deal: item.is_hot_deal,
                            hot_deal_value: item.hot_deal_value,
                            insert_datetime: moment().format('X')
                        }
                        con.query(`INSERT INTO tbl_booking_slot SET ?`,insertSlot,(sErr,sResult)=>{
                            let booking_member = {
                                booking_id:result.insertId,
                                slot_id: sResult.insertId,
                                user_id:params.login_user_id,
                                role:'Host',
                                status:'accept',
                                insert_datetime:moment().format("X")
                            }
                            con.query(`INSERT INTO tbl_booking_members SET ?`,booking_member);
                            next();
                        });
                    },()=>{
                        // con.query(`INSERT INTO tbl_booking_slot(booking_id,date,time,type,number_of_invite,guest,member,is_booster,booster_value,is_barter,is_hot_deal,hot_deal_value,insert_datetime) VALUES ?`,[timeslot],(sErr,sResult)=>{
                            // let booking_member = {
                            //     booking_id:result.insertId,
                            //     user_id:params.login_user_id,
                            //     role:'Host',
                            //     status:'accept',
                            //     insert_datetime:moment().format("X")
                            // }
                            // con.query(`INSERT INTO tbl_booking_members SET ?`,booking_member);
                            if(params.promocode){
                                this.promocode_used_added(params.promocode,params.login_user_id);
                            }
                            this.user_point_update(params.login_user_id,`booking_host`,`plus`,result.insertId);
                            if(params.payment_at == 'Online'){
                                this.user_point_update(params.login_user_id,`online_payment`,`plus`,result.insertId);
                            }
                            resolve({booking_id:result.insertId,order_id:order_id});
                        // });
                    });
                }
                else {
                    reject();
                }
            });
        });
    },
    user_point_update(user_id,tag,type,booking_id){
        con.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = '${tag}' AND is_active = 'Active' LIMIT 1`,(err,result)=>{
            if(!err && result[0]){
                let insertData = {
                    user_id: user_id,
                    booking_id: booking_id,
                    tag: tag,
                    type: type,
                    point: result[0].attribute_value,
                    insert_datetime: moment().format('X')
                }
                con.query(`INSERT INTO tbl_user_point_transaction SET ?`,insertData,(iErr,iResult)=>{
                    let sign = (type == 'plus') ? '+' : '-';
                    con.query(`UPDATE tbl_user SET wallet_balance = wallet_balance ${sign} ${insertData.point} WHERE id = ${user_id}`);
                })
            }
        })
    },
    promocode_used_added(promocode,user_id){
        con.query(`SELECT id,total_used FROM tbl_offer_used WHERE offer_id = ${promocode.id} AND user_id = ${user_id} LIMIT 1`,(err,result)=>{
            if(!err && result[0]){
                let updateData = {
                    total_used: result[0].total_used+1,
                    update_datetime: moment().format("X")
                }
                con.query(`UPDATE tbl_offer_used SET ? WHERE id = ${result[0].id}`,updateData,(uErr,uResult)=>{});
            }else{
                let insertData = {
                    offer_id: promocode.id,
                    user_id: user_id,
                    total_used: 1,
                    insert_datetime: moment().format("X")
                }
                con.query(`INSERT INTO tbl_offer_used SET ?`,insertData,(iErr,iResult)=>{});
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Booking Edit                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    booking_edit(params)
    {
        return new Promise((resolve,reject)=>{
            let updateData = {
                tsheet_id: params.id,
                ground_id: params.ground_id,
                golfer: params.golfer,
                session: (params.session == `M`) ? `Morning` : `Afternoon`,
                holes: params.holes,
                buggy: params.buggy,
                caddie: params.caddie,
                trolly: params.trolly,
                date: params.date,
                sst: params.sst,
                online_pay_off: params.online_pay_off,
                sub_total: params.sub_total,
                discount: params.discount,
                total: params.total,
                is_member: params.is_member,
                payment_at: params.payment_at,
                payment_status: params.payment_status,
                ...(params.remarks) && {remarks: params.remarks},
                update_datetime: moment().format('X')
            }
            con.query(`UPDATE tbl_booking SET ? WHERE id = ${params.booking_id}`,updateData,(err,result)=>{
                if(!err) {
                    let deleteIds = [];
                    asyncLoop(params.timeslot,(item,next)=>{
                        let updateDataTimeSlot = {
                            booking_id: params.booking_id,
                            date: params.date,
                            time: item.time,
                            type: item.type,
                            number_of_invite: params.golfer,
                            guest: JSON.stringify(item.guest),
                            member: JSON.stringify(item.member),
                            is_booster: item.is_booster,
                            booster_value: item.booster_value,
                            is_barter: item.is_barter,
                            is_hot_deal: item.is_hot_deal,
                            hot_deal_value: item.hot_deal_value
                        }
                        if(item.id){
                            updateDataTimeSlot.update_datetime = moment().format('X');
                            con.query(`UPDATE tbl_booking_slot SET ? WHERE id = ${item.id}`,updateDataTimeSlot,(uErr,uResult)=>{
                                deleteIds.push(item.id);
                                next();
                            });
                        }else{
                            updateDataTimeSlot.insert_datetime = moment().format('X');
                            con.query(`INSERT INTO tbl_booking_slot SET ?`,updateDataTimeSlot,(iErr,iResult)=>{
                                deleteIds.push(iResult.insertId);
                                let booking_member = {
                                    booking_id: params.booking_id,
                                    slot_id: iResult.insertId,
                                    user_id: params.login_user_id,
                                    role: 'Host',
                                    status: 'accept',
                                    insert_datetime: moment().format("X")
                                }
                                con.query(`INSERT INTO tbl_booking_members SET ?`,booking_member);
                                next();
                            });
                        }
                    },()=>{
                        con.query(`DELETE FROM tbl_booking_slot WHERE booking_id = ${params.booking_id} AND id NOT IN (${deleteIds})`,(dErr,dResult)=>{
                            resolve({booking_id:params.booking_id});
                        });
                    });
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                My Booking                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    my_booking(params)
    {
        return new Promise((resolve,reject)=>{
            let where = ``;
            if(params.status == "upcoming"){
                where += `AND b.date >= CURDATE()`;
            }else if(params.status == "past"){
                where += `AND b.date < CURDATE()`;
            }
            con.query(`SELECT b.id,b.user_id,b.date,t.name FROM tbl_booking AS b JOIN tbl_t_sheet AS t ON t.id = b.tsheet_id WHERE b.user_id = ${params.login_user_id} ${where} ORDER BY b.insert_datetime DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        con.query(`SELECT time FROM tbl_booking_slot WHERE booking_id = ${item.id} ORDER BY time LIMIT 1`,(tErr,tResult)=>{
                            con.query(`SELECT first_name,last_name,CONCAT('${S3_URL+USER_IMAGE}',profile_image) AS profile_image FROM tbl_user WHERE id = ${item.user_id}`,(uErr,uResult)=>{
                                item.time = (!tErr && tResult[0] != undefined) ? tResult[0].time : ``;
                                item.first_name = ``;
                                item.last_name = ``;
                                item.profile_image = ``;
                                if(!uErr && uResult[0] != undefined){
                                    item.first_name = uResult[0].first_name;
                                    item.last_name = uResult[0].last_name;
                                    item.profile_image = uResult[0].profile_image;
                                }
                                next();
                            });
                        });
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result});
                    });
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Booking Detail                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    booking_detail(params)
    {
        return new Promise((resolve,reject)=>{
            con.query({sql:`SELECT b.id,b.user_id,b.tsheet_id,b.date,b.order_id,b.buggy,b.session,b.holes AS is_selected_holes,b.ground_id,b.is_member,b.caddie,b.trolly,b.golfer,b.payment_at,b.promocode,b.payment_status,t.name,t.average_price AS price,t.location,t.latitude,t.longitude,t.length,t.par,t.holes,t.buggy_is_mandatory,t.caddie_is_mandatory,t.how_many_buggy,t.how_many_caddie,b.sst,b.online_pay_off,b.sub_total,b.discount,b.total,b.remarks,t.profile_image,CONCAT('${S3_URL+TSHEET_MAP_IMAGE}',t.map_image) AS map_image,t.rating,t.total_rating,t.description,t.total_buggy,t.total_caddie FROM tbl_booking AS b JOIN tbl_t_sheet AS t ON t.id = b.tsheet_id WHERE b.id = ${params.id} AND b.user_id = ${params.login_user_id} LIMIT 1`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err,result)=>{
                if(!err && result[0] != undefined){
                    let images = [];
                    asyncLoop(result[0].profile_image.split(','),(item,next)=>{
                        images.push(S3_URL+TSHEET_IMAGE+item);
                        next();
                    },()=>{
                        result[0].profile_image = images[0];
                        result[0].images = images;
                        result[0].promocode = (result[0].promocode) ? JSON.parse(result[0].promocode) : [];
                        con.query({sql:`SELECT time,type,guest,member,is_booster,booster_value,is_barter,is_hot_deal,hot_deal_value FROM tbl_booking_slot WHERE booking_id = ${result[0].id}`,
                            typeCast: (field,next)=>{
                                if(field.type == "BLOB"){
                                    return field.string();
                                }
                                return next();
                            }
                        },(sErr,sResult)=>{
                            if(!sErr && sResult[0] != undefined){
                                sResult.map(element => {
                                    element.guest = (element.guest != '') ? JSON.parse(element.guest) : null;
                                    element.member = (element.member != '') ?  JSON.parse(element.member) : null;
                                    return element;
                                });
                                result[0].timeslot = sResult;
                            }else{
                                result[0].timeslot = [];
                            }
                            // result[0].payment_status = 'paid';
                            this.get_course(result[0].tsheet_id).then((resGround)=>{
                                this.check_green_favorite_unfavorite(params.login_user_id,result[0].tsheet_id).then((res)=>{
                                    result[0].is_favorite = true;
                                    resolve({booking:result[0],ground:resGround,golfer:4});
                                }).catch((err)=>{
                                    result[0].is_favorite = false;
                                    resolve({booking:result[0],ground:resGround,golfer:4});
                                });
                            });
                        });
                    });
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Activity                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    activity(params)
    {
        return new Promise((resolve,reject)=>{
            if(params.status == "my"){
                con.query(`SELECT b.id,b.user_id,b.date,s.time,b.golfer,b.is_member,b.payment_at,b.insert_datetime,t.name AS tsheet_name,t.location,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,0 AS fees,CONCAT('${S3_URL+TSHEET_IMAGE}',t.profile_image) AS tsheet_image,bm.status,bm.slot_id,bm.role,s.is_booster,s.is_hot_deal,s.is_barter,s.booster_value,s.hot_deal_value FROM tbl_booking_members AS bm JOIN tbl_booking AS b ON b.id = bm.booking_id JOIN tbl_booking_slot AS s ON s.id = bm.slot_id JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_t_sheet AS t ON t.id = b.tsheet_id WHERE b.date >= CURDATE() AND bm.user_id = ${params.login_user_id} AND bm.status = 'accept' AND bm.role = 'Host' GROUP BY b.id ORDER BY b.insert_datetime DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err1,result1)=>{
                    con.query(`SELECT b.id,b.user_id,b.date,s.time,b.golfer,b.is_member,b.payment_at,b.insert_datetime,t.name AS tsheet_name,t.location,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,0 AS fees,CONCAT('${S3_URL+TSHEET_IMAGE}',t.profile_image) AS tsheet_image,bm.status,bm.slot_id,bm.role,s.is_booster,s.is_hot_deal,s.is_barter,s.booster_value,s.hot_deal_value FROM tbl_booking_members AS bm JOIN tbl_booking AS b ON b.id = bm.booking_id JOIN tbl_booking_slot AS s ON s.id = bm.slot_id JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_t_sheet AS t ON t.id = b.tsheet_id WHERE b.date >= CURDATE() AND bm.user_id = ${params.login_user_id} AND bm.status = 'accept' AND bm.role = 'Join' GROUP BY bm.id ORDER BY b.insert_datetime DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err2,result2)=>{
                        if(!err1 && !err2 && (result1[0] || result2[0])){
                            let finalArray = result1.concat(result2);
                            asyncLoop(finalArray,(item,next)=>{
                                var images = [];
                                asyncLoop(item.profile_image.split(','),(item_image,next_image)=>{
                                    images.push(S3_URL+TSHEET_IMAGE+item_image);
                                    next_image();
                                },()=>{
                                    item.profile_image = images[0];
                                    item.images = images;
                                    next();
                                });
                            },()=>{
                                finalArray.sort((a,b)=>{
                                    return a.insert_datetime - b.insert_datetime;
                                });
                                resolve(finalArray);
                            });
                        }else{
                            reject();
                        }
                    });
                });
            }else if(params.status == "invitations"){
                con.query(`SELECT b.id,b.user_id,b.date,s.time,b.golfer,b.is_member,b.payment_at,b.insert_datetime,t.name AS tsheet_name,t.location,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,0 AS fees,CONCAT('${S3_URL+TSHEET_IMAGE}',t.profile_image) AS tsheet_image,bm.status,bm.slot_id,bm.role,s.is_booster,s.is_hot_deal,s.is_barter,s.booster_value,s.hot_deal_value FROM tbl_booking_members AS bm JOIN tbl_booking AS b ON b.id = bm.booking_id JOIN tbl_booking_slot AS s ON s.id = bm.slot_id JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_t_sheet AS t ON t.id = b.tsheet_id WHERE b.date >= CURDATE() AND bm.user_id = ${params.login_user_id} AND bm.role = 'Join' AND bm.status = 'pending' GROUP BY b.id ORDER BY b.insert_datetime DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                    if(!err && result[0]){
                        asyncLoop(result,(item,next)=>{
                            var images = [];
                            asyncLoop(item.profile_image.split(','),(item_image,next_image)=>{
                                images.push(S3_URL+TSHEET_IMAGE+item_image);
                                next_image();
                            },()=>{
                                item.profile_image = images[0];
                                item.images = images;
                                next();
                            });
                        },()=>{
                            resolve(result);
                        });
                    }else{
                        reject();
                    }
                });
            }else{
                reject();
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Select Time Slot                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    select_time_slot(params)
    {
        return new Promise((resolve,reject)=>{
            con.query({sql:`SELECT bs.id,b.buggy,b.caddie,b.trolly,b.sst,b.online_pay_off,bs.time,bs.number_of_invite,COUNT(m.id) AS total_accept,bs.guest,bs.type,bs.member,bs.is_booster,bs.booster_value,bs.is_barter,bs.is_hot_deal,bs.hot_deal_value FROM tbl_booking_slot AS bs JOIN tbl_booking AS b ON b.id = bs.booking_id JOIN tbl_booking_members AS m ON m.booking_id = b.id AND m.slot_id = bs.id AND m.status = 'accept' WHERE bs.booking_id = ${params.booking_id} GROUP BY bs.id`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        item.guest = (item.guest != '') ? JSON.parse(item.guest) : null;
                        item.member = (item.member != '') ? JSON.parse(item.member) : null;
                        next();
                    },()=>{
                        resolve(result);
                    });
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Update Invitations Number                            /////
    //////////////////////////////////////////////////////////////////////////////////////////
    update_invitations_number(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`UPDATE tbl_booking_slot SET ? WHERE id = ${params.slot_id}`,{number_of_invite: params.number_of_invite},(err,result)=>{
                if(!err){
                    resolve();
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Global User                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    global_user(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT u.id,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,IFNULL(m.status,'not_invited') AS status FROM tbl_user AS u LEFT JOIN tbl_booking_members AS m ON m.user_id = u.id AND m.booking_id = ${params.booking_id} AND m.slot_id = ${params.slot_id} WHERE u.is_active = 'Active' AND u.id != ${params.login_user_id} ORDER BY u.id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve({page_token:parseInt(params.page_token)+1,result:result});
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Invitations Sent                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    invitations_sent(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,(SELECT IF(COUNT(m.id) < bs.number_of_invite,'true','false') FROM tbl_booking_members AS m JOIN tbl_booking_slot AS bs ON bs.booking_id = m.booking_id AND bs.id = m.slot_id WHERE m.booking_id = ${params.booking_id} AND m.slot_id = ${params.slot_id} AND m.status = 'accept' LIMIT 1) AS is_accept FROM tbl_booking_members WHERE booking_id = ${params.booking_id} AND slot_id = ${params.slot_id} AND user_id = ${params.user_id} LIMIT 1`,(err,result)=>{
                let data = {
                    booking_id: params.booking_id,
                    slot_id: params.slot_id,
                    user_id: params.user_id,
                    role: 'Join',
                    status: params.status
                }
                if(!err && result[0]){
                    data.update_datetime = moment().format("X");
                    if((result[0].is_accept == 'true' && params.status == "accept") || (["reject","cancel_by_host","pending"].indexOf(params.status) !== -1)){
                        con.query(`UPDATE tbl_booking_members SET ? WHERE id = ${result[0].id}`,data,(uErr,uResult)=>{
                            con.query(`SELECT b.order_id,s.time,b.user_id FROM tbl_booking_members AS m JOIN tbl_booking AS b ON b.id = m.booking_id JOIN tbl_booking_slot AS s ON s.id = m.slot_id WHERE m.id = ${result[0].id} LIMIT 1`,(sErr,sResult)=>{
                                con.query(`SELECT CONCAT(first_name,' ',last_name) AS name FROM tbl_user WHERE id = ${params.login_user_id} LIMIT 1`,(uErr,uResult)=>{
                                    let title = body = tag = ``;
                                    let title_n = body_n = ``;
                                    let push_sent_id = 0;
                                    if(params.status == "accept"){
                                        title = lang['en']['text_invitations_accepted_title'].replace('{order_id}',sResult[0].order_id).replace('{username}',uResult[0].name)
                                        title_n = `text_invitations_accepted_title`
                                        body = lang['en']['text_invitations_accepted_body'].replace('{time}',moment(sResult[0].time,["HH:mm:ss"]).format("hh:mm AA"))
                                        body_n = `text_invitations_accepted_body`
                                        tag = `invitations_accepted`;
                                        push_sent_id = sResult[0].user_id;
                                    }else if(params.status == "reject"){
                                        title = lang['en']['text_invitations_rejected_title'].replace('{order_id}',sResult[0].order_id).replace('{username}',uResult[0].name)
                                        title_n = `text_invitations_rejected_title`
                                        body = lang['en']['text_invitations_rejected_body'].replace('{time}',moment(sResult[0].time,["HH:mm:ss"]).format("hh:mm AA"))
                                        body_n = `text_invitations_rejected_body`
                                        tag = `invitations_rejected`;
                                        push_sent_id = sResult[0].user_id;
                                    }else{
                                        title = lang['en']['text_invitations_canceled_by_host_title'].replace('{order_id}',sResult[0].order_id)
                                        title_n = `text_invitations_canceled_by_host_title`
                                        body = lang['en']['text_invitations_canceled_by_host_body'].replace('{time}',moment(sResult[0].time,["HH:mm:ss"]).format("hh:mm AA"))
                                        body_n = `text_invitations_canceled_by_host_body`
                                        tag = `invitations_canceled_by_host`;
                                        push_sent_id = params.user_id;
                                    }
                                    let push_data = {
                                        title: title,
                                        body: body,
                                        custom: {
                                            tag: tag,
                                            booking_id: params.booking_id,
                                            slot_id: params.slot_id
                                        }
                                    }
                                    let push_notification = {
                                        sender_id: params.login_user_id,
                                        receiver_id: push_sent_id,
                                        action_id: params.booking_id,
                                        message: JSON.stringify({title:title_n,body:body_n,slot_id:params.slot_id,order_id:sResult[0].order_id,time:moment(sResult[0].time,["HH:mm:ss"]).format("hh:mm AA")}),
                                        tag: tag,
                                        insert_datetime: moment().format("X")
                                    }
                                    prepare_notification(push_sent_id,push_data);
                                    add_data('tbl_notification',push_notification,(res)=>{})
                                    resolve();
                                })
                            })
                        })
                    }else{
                        resolve(3);
                    }
                }else{
                    data.insert_datetime = moment().format("X");
                    con.query(`INSERT INTO tbl_booking_members SET ?`,data,(iErr,iResult)=>{
                        con.query(`SELECT b.order_id,s.time FROM tbl_booking_members AS m JOIN tbl_booking AS b ON b.id = m.booking_id JOIN tbl_booking_slot AS s ON s.id = m.slot_id WHERE m.id = ${iResult.insertId} LIMIT 1`,(sErr,sResult)=>{
                            let push_data = {
                                title: lang['en']['text_invitations_sent_title'].replace('{order_id}',sResult[0].order_id),
                                body: lang['en']['text_invitations_sent_body'].replace('{time}',moment(sResult[0].time,["HH:mm:ss"]).format("hh:mm AA")),
                                custom: {
                                    tag: "invitations_sent",
                                    booking_id: params.booking_id,
                                    slot_id: params.slot_id
                                }
                            }
                            let push_notification = {
                                sender_id: params.login_user_id,
                                receiver_id: params.user_id,
                                action_id: params.booking_id,
                                message: JSON.stringify({title:'text_invitations_sent_title',body:'text_invitations_sent_body',booking_id:params.booking_id,slot_id:params.slot_id,order_id:sResult[0].order_id,time:moment(sResult[0].time,["HH:mm:ss"]).format("hh:mm AA")}),
                                tag: 'invitations_sent',
                                insert_datetime: moment().format("X")
                            }
                            prepare_notification(params.user_id,push_data);
                            add_data('tbl_notification',push_notification,(res)=>{})
                            resolve();
                        })
                    })
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Attendance Sent                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    attendance_action(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id FROM tbl_booking_members WHERE booking_id = ${params.booking_id} AND slot_id = ${params.slot_id} AND user_id = ${params.login_user_id} LIMIT 1`,(err,result)=>{
                if(!err && result[0]){
                    let updateData = {
                        is_attendance: params.status,
                        update_datetime: moment().format("X")
                    }
                    con.query(`UPDATE tbl_booking_members SET ? WHERE id = ${result[0].id}`,updateData,(uErr,uResult)=>{
                        resolve();
                    })
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Review Club                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    review_club(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id FROM tbl_t_sheet_review WHERE user_id = ${params.login_user_id} AND tsheet_id = ${params.tsheet_id} LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined) {
                    let data = {
                        rating: params.rating,
                        review: params.review,
                        update_datetime: moment().format("X")
                    }
                    con.query(`UPDATE tbl_t_sheet_review SET ? WHERE id = ${result[0].id}`,data,(uErr,uResult)=>{
                        if(!uErr){
                            con.query(`UPDATE tbl_t_sheet SET rating = (SELECT ROUND((SUM(rating)/COUNT(id)),1) AS rating FROM tbl_t_sheet_review WHERE tsheet_id = ${params.tsheet_id}) WHERE id = ${params.tsheet_id}`,(rErr,rResult)=>{
                                resolve({type:'updated'});
                            });
                        }else{
                            reject({type:'updated'});
                        }
                    });
                }
                else {
                    let data = {
                        user_id: params.login_user_id,
                        tsheet_id: params.tsheet_id,
                        rating: params.rating,
                        review: params.review,
                        insert_datetime: moment().format("X"),
                        update_datetime: moment().format("X")
                    }
                    con.query(`INSERT INTO tbl_t_sheet_review SET ?`,data,(iErr,iResult)=>{
                        if(!iErr){
                            con.query(`UPDATE tbl_t_sheet SET total_rating = (SELECT COUNT(id) FROM tbl_t_sheet_review WHERE tsheet_id = ${params.tsheet_id}),rating = (SELECT ROUND((SUM(rating)/COUNT(id)),1) AS rating FROM tbl_t_sheet_review WHERE tsheet_id = ${params.tsheet_id}) WHERE id = ${params.tsheet_id}`,(rErr,rResult)=>{
                                resolve({type:'added'});
                            });
                        }else{
                            reject({type:'added'});
                        }
                    });
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Review Club List                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    review_club_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query({sql:`SELECT sr.id,u.first_name,u.last_name,CONCAT('${S3_URL}',profile_image) AS profile_image,sr.rating,sr.review,sr.update_datetime FROM tbl_t_sheet_review AS sr JOIN tbl_user AS u ON u.id = sr.user_id WHERE sr.tsheet_id = ${params.tsheet_id} ORDER BY sr.update_datetime DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve({page_token:parseInt(params.page_token)+1,result:result});
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Follow & Unfollow Request                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    follow_unfollow(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,status FROM tbl_user_follow WHERE serder_id = ${params.login_user_id} AND receiver_id = ${params.user_id} AND is_active = 'Active' LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    
                }else{
                    let insertData = {
                        sender_id: params.login_user_id,
                        receiver_id: params.user_id,
                        insert_datetime: moment().format('X')
                    }
                    con.query(`INSERT INTO tbl_user_follow SET ?`,insertData,(iErr,iResult)=>{
                        if(!iErr){
                            resolve();
                        }else{
                            reject();
                        }
                    });
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Green Deal List                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_deal_list(params)
    {
        return new Promise((resolve,reject)=>{
            let select = ``;
            let where = ``;
            let order_by = ``;
            if(params.alphabetical){
                order_by = `ORDER BY t.name ${params.alphabetical}`;
            }
            if(params.rating){
                order_by = `ORDER BY t.rating ${params.rating}`;
            }
            if(params.price){
                order_by = `ORDER BY t.average_price ${params.price}`;
            }
            if(params.distance && params.latitude && params.longitude){
                order_by = `ORDER BY distance ${params.distance}`;
            }
            if(params.latitude && params.longitude){
                select = `,ROUND((6371 * acos( cos( radians(${params.latitude}) ) * cos( radians( t.latitude ) ) * cos( radians( t.longitude ) - radians(${params.longitude}) ) + sin( radians(${params.latitude}) ) * sin( radians( t.latitude ) ) ) ), 2) AS distance`;
            }
            if(params.search){
                where = `AND LOWER(t.name) LIKE ('%${params.search.toLowerCase()}%')`;
            }
            if(params.type == "booster"){
                where = `((s.booster_slot_tbox10 != '' AND s.booster_slot_tbox10 != '[]') OR (s.booster_slot_tbox01 != '' AND s.booster_slot_tbox01 != '[]'))`;
            }else{
                where = `((s.hot_deal_slot_tbox10 != '' AND s.hot_deal_slot_tbox10 != '[]') OR (s.hot_deal_slot_tbox01 != '' AND s.hot_deal_slot_tbox01 != '[]'))`;
            }
            con.query(`SELECT t.id,t.rating,t.profile_image,t.name,t.location,t.average_price AS price FROM tbl_schedule AS s${select} JOIN tbl_t_sheet AS t ON t.id = s.tsheet_id WHERE s.is_active = 'Active' AND t.is_active = 'Active' AND ${where} GROUP BY s.tsheet_id ${order_by} LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        var images = [];
                        asyncLoop(item.profile_image.split(','),(item_image,next_image)=>{
                            images.push(S3_URL+TSHEET_IMAGE+item_image);
                            next_image();
                        },()=>{
                            item.profile_image = images[0];
                            item.images = images
                            this.check_green_favorite_unfavorite(params.login_user_id,item.id).then((res)=>{
                                item.is_favorite = true;
                                next();
                            }).catch((err)=>{
                                item.is_favorite = false;
                                next();
                            });
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result});
                    });
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Green Deal Detail                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    green_deal_detail(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT t.id,t.rating,t.profile_image,t.name,t.average_price AS price,CONCAT('${S3_URL+TSHEET_MAP_IMAGE}',t.map_image) AS map_image,t.location,t.latitude,t.longitude,t.total_rating,t.description,t.length,t.par,t.holes,t.buggy_is_mandatory,t.caddie_is_mandatory,t.how_many_buggy,t.how_many_caddie,t.total_buggy,t.total_caddie,t.sst,t.online FROM tbl_t_sheet AS t WHERE t.is_active = 'Active' AND t.id = ${params.id} LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    let images = [];
                    asyncLoop(result[0].profile_image.split(','),(item_image,next_image)=>{
                        images.push(S3_URL+TSHEET_IMAGE+item_image);
                        next_image();
                    },()=>{
                        result[0].profile_image = images[0];
                        result[0].images = images;
                        this.green_deal_schedule(params).then((resSlot)=>{
                            result[0].tbox01 = resSlot.tbox01;
                            result[0].tbox10 = resSlot.tbox10;
                            this.get_course(params.id).then((resGround)=>{
                                this.check_green_favorite_unfavorite(params.login_user_id,result[0].id).then((res)=>{
                                    result[0].is_favorite = true;
                                    resolve({green:result[0],ground:resGround,golfer:4});
                                }).catch((err)=>{
                                    result[0].is_favorite = false;
                                    resolve({green:result[0],ground:resGround,golfer:4});
                                });
                            });
                        });
                    });
                }else{
                    reject();
                }
            });
        });
    },
    green_deal_schedule(params){
        return new Promise((resolve,reject)=>{
            let select = ``;
            let where = ``;
            if(params.type == "booster"){
                select = `,booster_slot_tbox10,booster_slot_tbox01`;
                where = `AND ((booster_slot_tbox10 != '' AND booster_slot_tbox10 != '[]') OR (booster_slot_tbox01 != '' AND booster_slot_tbox01 != '[]'))`;
            }else{
                select = `,hot_deal_slot_tbox10,hot_deal_slot_tbox01`;
                where = `AND ((hot_deal_slot_tbox10 != '' AND hot_deal_slot_tbox10 != '[]') OR (hot_deal_slot_tbox01 != '' AND hot_deal_slot_tbox01 != '[]'))`;
            }
            con.query(`SELECT ground_id,date,start_break_time,end_break_time,is_break,weekend_dates,holes${select} FROM tbl_schedule WHERE is_active = 'Active' AND date = '${params.date}' AND tsheet_id = ${params.id} ${where}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    params.tsheet_id = params.id;
                    let tbox01 = [];
                    let tbox10 = [];
                    asyncLoop(result,(item,next)=>{
                        if(params.type == "booster"){
                            let slot01 = JSON.parse(item.booster_slot_tbox01);
                            let slot10 = JSON.parse(item.booster_slot_tbox10);
                            let weekend_dates = item.weekend_dates.split(',').map(function(item1){
                                return item1.trim();
                            });
                            let type = (weekend_dates.indexOf(params.date) !== -1) ? `weekend` : `weekday`;
                            asyncLoop(slot01,(element,elnext)=>{
                                let price_type = (item.is_break == "Yes" && element.time > item.end_break_time) ? `${type}_pm` :  `${type}_am`;
                                let is_morning = (item.is_break == "Yes" && element.time > item.end_break_time) ? false : ((moment('12:00 PM','hh:mm AA').isAfter(moment(element.time,'hh:mm AA'))) ? true : false);
                                this.green_single_pricing(params.id,item.holes,price_type).then((resPricing)=>{
                                    this.get_booking_detail(params,moment(element.time,'hh:mm A').format('HH:mm:ss'),`tbox01`).then((resReserved)=>{
                                        tbox01.push({
                                            time: element.time,
                                            value: element.value,
                                            holes: item.holes,
                                            ground_id: item.ground_id,
                                            pricing: resPricing,
                                            is_reserved: resReserved.is_reserved,
                                            is_morning: is_morning
                                        });
                                        elnext();
                                    });
                                });
                            },()=>{
                                if(slot10 != [] && slot10 != ''){
                                    asyncLoop(slot10,(element,elnext)=>{
                                        let price_type = (item.is_break == "Yes" && element.time > item.end_break_time) ? `${type}_pm` :  `${type}_am`;
                                        let is_morning = (item.is_break == "Yes" && element.time > item.end_break_time) ? false : ((moment('12:00 PM','hh:mm AA').isAfter(moment(element.time,'hh:mm AA'))) ? true : false);
                                        this.green_single_pricing(params.id,item.holes,price_type).then((resPricing)=>{
                                            this.get_booking_detail(params,moment(element.time,'hh:mm A').format('HH:mm:ss'),`tbox10`).then((resReserved)=>{
                                                tbox10.push({
                                                    time: element.time,
                                                    value: element.value,
                                                    holes: item.holes,
                                                    ground_id: item.ground_id,
                                                    pricing: resPricing,
                                                    is_reserved: resReserved.is_reserved,
                                                    is_morning: is_morning
                                                });
                                                elnext();
                                            });
                                        });
                                    },()=>{
                                        next();
                                    });
                                }else{
                                    next();
                                }
                            });
                        }else{
                            let slot01 = JSON.parse(item.hot_deal_slot_tbox01);
                            let slot10 = JSON.parse(item.hot_deal_slot_tbox10);
                            let weekend_dates = item.weekend_dates.split(',').map(function(item1){
                                return item1.trim();
                            });
                            let type = (weekend_dates.indexOf(params.date) !== -1) ? `weekend` : `weekday`;
                            asyncLoop(slot01,(element,elnext)=>{
                                let price_type = (item.is_break == "Yes" && element.time > item.end_break_time) ? `${type}_pm` :  `${type}_am`;
                                let is_morning = (item.is_break == "Yes" && element.time > item.end_break_time) ? false : ((moment('12:00 PM','hh:mm AA').isAfter(moment(element.time,'hh:mm AA'))) ? true : false);
                                this.green_single_pricing(params.id,item.holes,price_type).then((resPricing)=>{
                                    this.get_booking_detail(params,moment(element.time,'hh:mm A').format('HH:mm:ss'),`tbox01`).then((resReserved)=>{
                                        tbox01.push({
                                            time: element.time,
                                            value: element.value,
                                            holes: item.holes,
                                            ground_id: item.ground_id,
                                            pricing: resPricing,
                                            is_reserved: resReserved.is_reserved,
                                            is_morning: is_morning
                                        });
                                        elnext();
                                    });
                                });
                            },()=>{
                                if(slot10 != [] && slot10 != ''){
                                    asyncLoop(slot10,(element,elnext)=>{
                                        let price_type = (item.is_break == "Yes" && element.time > item.end_break_time) ? `${type}_pm` :  `${type}_am`;
                                        let is_morning = (item.is_break == "Yes" && element.time > item.end_break_time) ? false : ((moment('12:00 PM','hh:mm AA').isAfter(moment(element.time,'hh:mm AA'))) ? true : false);
                                        this.green_single_pricing(params.id,item.holes,price_type).then((resPricing)=>{
                                            this.get_booking_detail(params,moment(element.time,'hh:mm A').format('HH:mm:ss'),`tbox10`).then((resReserved)=>{
                                                tbox10.push({
                                                    time: element.time,
                                                    value: element.value,
                                                    holes: item.holes,
                                                    ground_id: item.ground_id,
                                                    pricing: resPricing,
                                                    is_reserved: resReserved.is_reserved,
                                                    is_morning: is_morning
                                                });
                                                elnext();
                                            });
                                        });
                                    },()=>{
                                        next();
                                    });
                                }else{
                                    next();
                                }
                            });
                        }
                    },()=>{
                        resolve({
                            tbox01: tbox01,
                            tbox10: tbox10
                        });
                    });
                }else{
                    resolve({
                        tbox01: [],
                        tbox10: []
                    });
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Available Promocode                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_available_offer(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id,added_by,user_id,title,start_date,end_date,discount,description,CONCAT('${S3_URL+OFFER_IMAGE}',image) AS image FROM tbl_offer WHERE is_active = 'Active' AND start_date <= '${params.booking_date}' AND end_date >= '${params.booking_date}' AND (added_by = 'admin' OR (added_by = 'tsheet' AND user_id = ${params.tsheet_id})) ORDER BY id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if (!err && result[0]) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Verify Promocode                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    verify_promocode(params) {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,added_by,user_id,title,start_date,end_date,discount,description,type FROM tbl_offer WHERE title = '${params.promocode}' AND is_active = 'Active' AND start_date <= '${params.booking_date}' AND end_date >= '${params.booking_date}' LIMIT 1`,(err,result)=>{
                if (!err && result[0]) {
                    con.query(`SELECT total_used FROM tbl_offer_used WHERE offer_id = ${result[0].id} AND user_id = ${params.login_user_id} LIMIT 1`,(oErr,oResult)=>{
                        if(!oErr && oResult[0]){
                            if(oResult[0].total_used < result[0].total_used){
                                resolve({code:1,data:result[0]})
                            }else{
                                resolve({code:3})
                            }
                        }else{
                            resolve({code:1,data:result[0]})
                        }
                    })
                } else {
                    reject();
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Rewards List                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    rewards_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT t.id,b.order_id,t.point,t.type,t.tag,t.insert_datetime FROM tbl_user_point_transaction AS t JOIN tbl_booking AS b ON b.id = t.booking_id WHERE t.user_id = ${params.login_user_id} AND t.is_active = 'Active' ORDER BY t.id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        item.message = lang['en'][item.tag];
                        next();
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result});
                    });
                }else{
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Notification List                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    notification_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query({sql:`SELECT n.id,n.action_id,n.receiver_id,n.tag,n.message,n.is_read,n.insert_datetime,u.first_name,u.last_name FROM tbl_notification AS n JOIN tbl_user AS u ON u.id = n.receiver_id WHERE n.is_active = 'Active' AND n.receiver_id = '${params.login_user_id}' ORDER BY n.id DESC LIMIT ${parseInt(params.page_token) * parseInt(NOTIFICATION_PER_PAGE)},${NOTIFICATION_PER_PAGE}`,
                typeCast: (field, next) => {
                    if (field.type == 'BLOB') {
                        return field.string()
                    }
                    return next()
                }
            },(err,result)=>{
                if(!err && result[0]) {
                    asyncLoop(result,(item,next)=>{
                        try{
                            item.message = JSON.parse(item.message)
                        }catch(e){
                            item.message = item.message
                        }
                        if(item.tag == "admin_notification"){
                            item.title = item.message.title
                            item.body = item.message.body
                            delete item.message
                            next()
                        }else{
                            if(["invitations_sent","invitations_accepted","invitations_rejected","invitations_canceled_by_host"].indexOf(item.tag) !== -1){
                                con.query(`SELECT status FROM tbl_booking_members WHERE booking_id = ${item.action_id} AND slot_id = ${item.message.slot_id} AND user_id = ${item.receiver_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang['en'][item.message.title].replace('{order_id}',item.message.order_id).replace('{username}',`${item.first_name} ${item.last_name}`)
                                    item.body = lang['en'][item.message.body].replace('{time}',item.message.time)
                                    item.booking_id = item.action_id
                                    item.slot_id = item.message.slot_id
                                    item.status = bResult[0].status
                                    delete item.message
                                    next()
                                })
                            }else{
                                item.title = lang['en'][item.message.title]
                                item.body = lang['en'][item.message.body]
                                delete item.message
                                next()
                            }
                        }
                    },()=>{
                        resolve({"page_token":parseInt(params.page_token)+1,"result":result})
                    })
                }
                else {
                    reject()
                }
            })
        })
    },
}