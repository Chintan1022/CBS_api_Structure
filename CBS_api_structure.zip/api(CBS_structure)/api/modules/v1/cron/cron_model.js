const con = require('../../../config/database');
const lang = require('../../../config/language');
const {prepare_notification,add_data} = require('../../../config/common');
const moment = require('moment');
const asyncLoop = require('node-async-loop');

const cron = {

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Confirmation Of Attendance                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async confirmation_of_attendance()
    {
        con.query(`SELECT b.id,b.order_id,m.user_id,bs.time FROM tbl_booking AS b JOIN tbl_booking_members AS m ON m.booking_id = b.id JOIN tbl_booking_slot AS bs ON bs.id = m.slot_id WHERE b.date = DATE_ADD(CURRENT_DATE(),INTERVAL 2 DAY) AND m.is_attendance = 'pending'`,(err,result)=>{
            if(!err && result[0]){
                asyncLoop(result,(item,next)=>{
                    let push_data = {
                        title: lang['en']['text_confirmation_of_attendance_title'].replace('{order_id}',item.order_id),
                        body: lang['en']['text_confirmation_of_attendance_body'].replace('{time}',moment(item.time,["HH:mm:ss"]).format("hh:mm AA")),
                        custom: {
                            tag: "confirmation_of_attendance",
                            booking_id: item.id,
                            order_id: item.order_id
                        }
                    }
                    let push_notification = {
                        sender_id: 0,
                        receiver_id: item.user_id,
                        action_id: item.id,
                        message: JSON.stringify({title:'text_confirmation_of_attendance_title',body:'text_confirmation_of_attendance_body',order_id:item.order_id}),
                        tag: 'confirmation_of_attendance',
                        insert_datetime: moment().format("X")
                    }
                    prepare_notification(item.user_id,push_data)
                    add_data('tbl_notification',push_notification,(res)=>{})
                    next();
                })
            }
        })
    }
}

module.exports = cron;