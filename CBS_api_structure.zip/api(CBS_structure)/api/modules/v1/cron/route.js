const express = require('express');
const cron_model = require('../cron/cron_model');
const cron = require('cron');
const moment_timezone = require('moment-timezone');

const router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Cron Set In 24 Hours                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
const one_day = new cron.CronJob({
    cronTime: '0 */23 * * *',
    onTick: function() {
        console.log('24 HOURS CRON CALL : '+moment_timezone().tz("utc").format("DD-MM-YYYY hh:mm A"));
        cron_model.confirmation_of_attendance();
    },
    start: true
});

module.exports = router;