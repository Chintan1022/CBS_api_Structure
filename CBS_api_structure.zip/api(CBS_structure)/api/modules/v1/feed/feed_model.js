const con = require('../../../config/database');
const lang = require('../../../config/language');
const {S3_URL,PER_PAGE,USER_IMAGE,FEED_IMAGE} = require('../../../config/constants');
const {prepare_notification} = require('../../../config/common');
const moment = require('moment');
const asyncLoop = require('node-async-loop');

module.exports = {

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Create Post                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async create_post(params)
    {
        return new Promise((resolve,reject)=>{
            let insertData = {
                user_id: params.login_user_id,
                description: params.description,
                type: params.type,
                insert_datetime: moment().format('X')
            }
            con.query(`INSERT INTO tbl_user_membership SET ?`,insertData,(err,result)=>{
                if(!err) {
                    let media = [];
                    asyncLoop(params.media,(item,next)=>{
                        media.push([result.insertId,item.name,item.type,moment().format("X")]);
                        next();
                    },()=>{
                        con.query(`INSERT INTO tbl_feed_media(feed_id,name,type,insert_datetime) VALUES ?`,[media],(mErr,mResult)=>{
                            resolve();
                        });
                    });
                }
                else {
                    reject();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Post Like                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async post_like(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT id,type FROM tbl_feed_likes WHERE feed_id = ${params.feed_id} AND user_id = ${params.login_user_id} LIMIT 1`,(err,result)=>{
                let data = { 
                    feed_id: params.feed_id,
                    user_id: params.login_user_id
                }
                if(!err && result[0]){
                    data.type = (result[0].type == "Like") ? "" : "Like";
                    data.update_datetime = moment().format("X");
                    con.query(`UPDATE tbl_feed_likes SET ? WHERE id = ${result[0].id}`,(uErr,uResult)=>{
                        if(data.type == "Like"){
                            con.query(`UPDATE tbl_feed SET total_likes = total_likes + 1 WHERE id = ${params.feed_id}`,(lErr,lResult)=>{
                                resolve();
                            })
                        }else{
                            con.query(`UPDATE tbl_feed SET total_likes = total_likes - 1 WHERE id = ${params.feed_id}`,(lErr,lResult)=>{
                                resolve();
                            })
                        }
                    });
                }else{
                    data.type = 'Like';
                    data.insert_datetime = moment().format("X");
                    con.query(`INSERT INTO tbl_feed_likes SET ?`,data,(iErr,iResult)=>{
                        con.query(`UPDATE tbl_feed SET total_likes = total_likes + 1 WHERE id = ${params.feed_id}`,(lErr,lResult)=>{
                            con.query(`SELECT id,first_name,last_name,CONCAT('${S3_URL+USER_IMAGE}',profile_image) AS profile_image FROM tbl_user WHERE id = ${params.login_user_id} LIMIT 1`,(fErr,fResult)=>{
                                let push_data = {
                                    title: lang['en']['text_post_like_title'].replace('{username}',`${fResult[0].first_name} ${fResult[0].last_name}`),
                                    body: lang['en']['text_post_like_body'].replace('{username}',`${fResult[0].first_name} ${fResult[0].last_name}`),
                                    custom: {
                                        tag: "post_like",
                                        feed_id: params.feed_id,
                                        profile_image: fResult[0].profile_image
                                    }
                                }
                                prepare_notification(fResult[0].id,push_data)
                                resolve();
                            })
                        })
                    });
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Post Comment                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async post_comment(params)
    {
        return new Promise((resolve,reject)=>{
            let insertData = {
                feed_id: params.feed_id,
                user_id: params.login_user_id,
                comment: params.comment,
                insert_datetime: moment().format("X")
            }
            con.query(`INSERT INTO tbl_feed_comments SET ?`,insertData,(err,result)=>{
                if(!err){
                    con.query(`UPDATE tbl_feed SET total_comments = total_comments + 1 WHERE id = ${params.feed_id}`,(uErr,uResult)=>{
                        con.query(`SELECT id,first_name,last_name,CONCAT('${S3_URL+USER_IMAGE}',profile_image) AS profile_image FROM tbl_user WHERE id = ${params.login_user_id} LIMIT 1`,(fErr,fResult)=>{
                            let push_data = {
                                title: params.comment,
                                body: lang['en']['text_post_comment_body'].replace('{username}',`${fResult[0].first_name} ${fResult[0].last_name}`),
                                custom: {
                                    tag: "post_comment",
                                    feed_id: params.feed_id,
                                    profile_image: fResult[0].profile_image
                                }
                            }
                            prepare_notification(fResult[0].id,push_data);
                            resolve();
                        });
                    });
                }else{
                    reject();
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Post List                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async post_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query({sql:`SELECT p.id,p.user_id,p.description,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,p.total_likes,p.total_comments,p.insert_datetime FROM tbl_feed AS p JOIN tbl_user AS u ON u.id = p.user_id WHERE p.is_active = 'Active' ORDER BY p.id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err,result)=>{
                if(!err && result[0]){
                    asyncLoop(result,(item,next)=>{
                        con.query(`SELECT CONCAT('${S3_URL+FEED_IMAGE}',name) AS name,type FROM tbl_feed_media WHERE feed_id = ${params.feed_id}`,(mErr,mResult)=>{
                            item.media = (!mErr && mResult[0]) ? mResult : [];
                            next();
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result});
                    })
                }else{
                    reject();
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Post Like List                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async post_like_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query(`SELECT l.id,l.user_id,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image FROM tbl_feed_likes AS l JOIN tbl_user AS u ON u.id = l.user_id WHERE l.is_active = 'Active' AND l.type = 'Like' ORDER BY l.id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,(err,result)=>{
                if(!err && result[0]){
                    resolve({page_token:parseInt(params.page_token)+1,result:result});
                }else{
                    reject();
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Post Comment List                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async post_comment_list(params)
    {
        return new Promise((resolve,reject)=>{
            con.query({sql:`SELECT c.id,c.user_id,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,c.insert_datetime,c.comment FROM tbl_feed_comments AS c JOIN tbl_user AS u ON u.id = c.user_id WHERE c.is_active = 'Active' ORDER BY c.id DESC LIMIT ${(parseInt(params.page_token) * parseInt(PER_PAGE))},${parseInt(PER_PAGE)}`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                }
            },(err,result)=>{
                if(!err && result[0]){
                    resolve({page_token:parseInt(params.page_token)+1,result:result});
                }else{
                    reject();
                }
            })
        })
    },
}