const lang = require('../../../config/language');
const feed_model = require('./feed_model');
const {sendResponse,checkValidation} = require('../../../config/common');
const router = require('express').Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Create Post                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/create_post",(req,res)=>{
    let params = req.body;
    var rules =  {
        description: 'required',
        type: 'required|in:all,friend_group_team',
        media: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        feed_model.create_post(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_feed_create_su'],null)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_feed_create_un'],null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Post Like                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/post_like",(req,res)=>{
    let params = req.body;
    var rules =  { feed_id: 'required' }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        feed_model.post_like(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_feed_like_su'],null)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_feed_like_un'],null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Post Comment                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/post_comment",(req,res)=>{
    let params = req.body;
    var rules =  {
        feed_id: 'required',
        comment: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        feed_model.post_comment(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_feed_comment_su'],null)
        }).catch((err)=>{
            sendResponse(res,"0",lang[req.language]['text_feed_comment_un'],null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Post List                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/post_list",(req,res)=>{
    let params = req.body;
    var rules =  {
        page_token: 'required',
        type: 'required|in:all,friend_group_team'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        feed_model.post_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_feed_list_su'],null)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_feed_list_un'],null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Post Like List                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/post_like_list",(req,res)=>{
    let params = req.body;
    var rules =  {
        feed_id: 'required',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        feed_model.post_like_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_feed_comment_su'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_feed_comment_un'],null);
        });
    }
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Post Comment List                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/post_comment_list",(req,res)=>{
    let params = req.body;
    var rules =  {
        feed_id: 'required',
        page_token: 'required'
    }
    if(checkValidation(params, rules, res, req.language)) {
        params.login_user_id = req.login_user_id;
        feed_model.post_comment_list(params).then((resData)=>{
            sendResponse(res,"1",lang[req.language]['text_feed_comment_su'],resData)
        }).catch((err)=>{
            sendResponse(res,"2",lang[req.language]['text_feed_comment_un'],null);
        });
    }
});

module.exports = router;