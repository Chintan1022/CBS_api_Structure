const lang = require('../../../config/language');
const chat_model = require('./chat_model');
const {decryption,checkValidation,sendResponse} = require('../../../config/common');

const router = require('express').Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Recent Chat List                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/recent_chat_list",(req,res)=>{
    let params = req.body;
    const rules = { page_token: "required" }
    if(checkValidation(params, rules, res, req.language))
    {
        params.login_user_id = req.login_user_id;
        chat_model.recent_chat_list(params).then((resData)=>{
            sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
        }).catch((err)=>{
            sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
        })
    }
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Personal Chat List                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/personal_chat_list",(req,res)=>{
    let params = req.body;
    const rules = {
        user_id: "required",
        page_token: "required"
    }
    if(checkValidation(params, rules, res, req.language))
    {
        params.login_user_id = req.login_user_id;
        chat_model.check_room_already_exists(params).then((resRoom)=>{
            chat_model.chat_message_read(resRoom.chat_id,params.login_user_id)
            chat_model.personal_chat_list(params,resRoom).then((resData)=>{
                sendResponse(res, resData.code, lang[req.language]['text_details_are'], resData.data)
            }).catch((err)=>{
                sendResponse(res, "0", lang[req.language]['text_chat_list_fail'], null)
            })
        }).catch((error)=>{
            console.log(error)
            sendResponse(res, "0", lang[req.language]['text_chat_list_fail'], null)
        })
    }
})

module.exports = router;