const express = require('express');
const app = express();

const aws_v1 = require('./v1/aws/route');
const authentication_v1 = require('./v1/authentication/route');
const home_v1 = require('./v1/home/route');
const chat_v1 = require('./v1/chat/route');
const feed_v1 = require('./v1/feed/route');

app.use('/v1/aws',aws_v1);
app.use('/v1/authentication',authentication_v1);
app.use('/v1/home',home_v1);
app.use('/v1/chat',chat_v1);
app.use('/v1/feed',feed_v1);

app.use((req, res, next)=>{
    res.status(404);
    res.send('This Url Is Not Valid');
});

module.exports = app