var en = require('./../languages/en.json');
var hi = require('./../languages/hi.json');
var mr = require('./../languages/mr.json');
var gu = require('./../languages/gu.json');

// var gu = require('./../languages/gu.json');

// var enhi = require('./../languages/enhi.json');

var LANG = {
    'en': en,
    'hi': hi,
    'gu': gu,
    'mr': mr,
    // 'enhi' : enhi
}

module.exports = LANG;