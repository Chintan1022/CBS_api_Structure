let Globals = {
    // ======================================================================================
    //                                      APP
    // ======================================================================================
    // 'APP_NAME'              : "Eassyserve",
    // 'BASE_URL'              : 'https://www.eassyserve.com/',
    // 'PORT_BASE_URL'         : 'https://www.eassyserve.com/',
    // 'PORT'                  : 5001,
    // 'LOGO'                  : "https://eassyserve-cdn.s3.ap-south-1.amazonaws.com/logo/invoice-logo.png",
    // 'FAVICON'               : "https://3.7.8.99/eassyserve/api/public/images/icons/favicon.png",
    // 'API_KEY'               : 'MDExMDAxMDEwNjVTMTE1MDEwMTEwMDEwODNFMDExMTAwMTB2MTAx',
    // 'ENC_KEY'               : 'eDkEg0eNU3A49R7iMYWASI9dSDh8h9rF',
    // 'ENC_IV'                : 'eDkEg0eNU3A49R7i',
    // 'STATIC_DOC_PASSWORD'   : '123456',
    'APP_NAME': "Eassyserve",
    'BASE_URL': 'http://3.7.8.99/eassyserve/',
    'PORT_BASE_URL': 'http://3.7.8.99:5001/',
    'PORT': 5001,
    'LOGO': "http://3.7.8.99/eassyserve/api/public/images/icons/logo.png",
    'FAVICON': "http://3.7.8.99/eassyserve/api/public/images/icons/favicon.png",
    'API_KEY': 'MDExMDAxMDEwNjVTMTE1MDEwMTEwMDEwODNFMDExMTAwMTB2MTAx',
    'ENC_KEY': 'eDkEg0eNU3A49R7iMYWASI9dSDh8h9rF',
    'ENC_IV': 'eDkEg0eNU3A49R7i',
    'STATIC_DOC_PASSWORD': '123456',
    // ======================================================================================
    //                                 EMAIL & PASSWORD
    // ======================================================================================
    // 'EMAIL_ID': "noreply@eassyserve.in",
    // 'EMAIL_PASSWORD': "vfaebucrivfwjixe",
    'EMAIL_ID': "bhargavtest8@gmail.com",
    'EMAIL_PASSWORD': "tom&jerry",

    // ======================================================================================
    //                                SMS GATEWAY
    // ======================================================================================
    'SMS_API_KEY': "e800a0e2-de51-11eb-8089-0200cd936042",

    // ======================================================================================
    //                                AGORA GATEWAY
    // ======================================================================================
    'AGORA_APP_ID': "bfbfad5343fd4749b236cbca54e95522",
    'AGORA_CERTIFICATE': "d898136e334e4229953f4135923bce31",
    'AGORA_CUSTOMER_ID': "d108cac4d59d440fbbebdc62cd4243be",
    'AGORA_SECRET_ID': "d44ab89cbee146b9933763242646348a",

    // ======================================================================================
    //                              PAYMENT GATEWAY
    // ======================================================================================
    'TEST_KEY_ID': "rzp_test_e92J2hWInQ626w",
    'TEST_KEY_SECRET': "DJ2306pz6Bo7Z2GfAPm42CZX",
    'LIVE_KEY_ID': 'rzp_live_tZHTP4IVhOgcVG',
    'LIVE_KEY_SECRET': 'sMzz8RL3zUqjnkxHZKmZ4WGJ',

    // ======================================================================================
    //                              QUICKBOOK GATEWAY
    // ======================================================================================
    'QB_CLIENT_ID': "ABZPs5FdWxuJAM7IIxtHA0lDenYqgAnHT4rvXHfMJgQQwTmr6O",
    'QB_SECRET': "GtohQGhtKbph1yiwv09imbcbyYzvQ2Fou6Hv2bRs",
    'QB_ENVIRONMENT': false,
    'QB_REALMID': "9130351388037206",

    // ======================================================================================
    //                                  AWS S3 BUCKET
    // ======================================================================================
    'S3_BUCKET_NAME': "eassyserve-cdn",
    'S3_ACCESS_KEY': "AKIAY5E36W5MH5IA4ZXV",
    'S3_SECRET_KEY': "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",
    'S3_REGION': "ap-south-1",
    'S3_FOLDER_NAME': "eassyserve",
    'S3_URL': 'https://eassyserve-cdn.s3.ap-south-1.amazonaws.com/',

    // ======================================================================================
    //                                 IMAGE & VIDEO PATH
    // ======================================================================================
    'USER_IMAGE': 'user/',
    'USER_DOCUMENT_IMAGE': 'document/',
    'CATEGORY_IMAGE': 'category/',
    'BANK_IMAGE': 'bank/',
    'OFFER_IMAGE': 'offer/',
    'COST_IMAGE': 'cost/',
    'CHAT_IMAGE': 'chat/',

    // ======================================================================================
    //                                      LIMIT
    // ======================================================================================
    "PER_PAGE": 10,
    "HOME_PAGE": 5,
    "CHAT_PER_PAGE": 10,
    "NOTIFICATION_PER_PAGE": 20,

    // ======================================================================================
    //                                   NOTIFICATION-DEV
    // ======================================================================================
    "GCM_PUSH_KEY": "AAAAeFWpKA4:APA91bFh9xeyNNe82ZyggiIlRf4iok7hFIVFzesoK3JeKhjb2yrDkn5OQY0HsiIcQ_eHGKydpGU1CR8B9GHcfGQIrx-jwu8ZrHvvhKJ6kx5L2MXK2YVRtNPFvRpg2AHJeZyDqQlhVuKb",
    "APN_PUSH_KEY": "./pem/AuthKey_YBLDPDD8LF.p8",
    "KEYID": "YBLDPDD8LF",
    "TEAMID": "AZ3Z9B5RTD",
    "BUNDLEID": "com.eassyserve",
    "CUSTOMER_VOIP": "com.eassyserve.voip",
    "TEAMBUNDLEID": "com.eassyserve.sp",
    "TEAMBUNDLEIDVOIP": "com.eassyserve.sp.voip",

    // ======================================================================================
    //                                   NOTIFICATION-LIVE
    // ======================================================================================
    /*    "GCM_PUSH_KEY"      :  "AAAAeFWpKA4:APA91bFh9xeyNNe82ZyggiIlRf4iok7hFIVFzesoK3JeKhjb2yrDkn5OQY0HsiIcQ_eHGKydpGU1CR8B9GHcfGQIrx-jwu8ZrHvvhKJ6kx5L2MXK2YVRtNPFvRpg2AHJeZyDqQlhVuKb",
        "APN_PUSH_KEY"      :  "./pem/AuthKey_YBLDPDD8LF.p8",
        "KEYID"             :  "YBLDPDD8LF",
        "TEAMID"            :  "AZ3Z9B5RTD",
        "BUNDLEID"          :  "com.eassyserve",
        "TEAMBUNDLEID"      :  "com.eassyserve.sp",*/
}
module.exports = Globals;