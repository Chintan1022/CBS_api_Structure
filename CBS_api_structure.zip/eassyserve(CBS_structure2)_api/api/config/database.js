var mysql = require('mysql');

// only use to read opration
var read = mysql.createPool({
    connectionLimit: 510,
    host: 'ls-6a16584603101c40a7ec58dd041710d20fc6ff55.ct7youvpvruy.ap-south-1.rds.amazonaws.com',
    user: 'hlisteamUDB',
    password: 'Q8U+jpI!4#vGD',
    database: 'eassyservermain',
    dateStrings: "date"
});

// only use to write opration
var write = mysql.createPool({
    connectionLimit: 510,
    host: 'ls-6a16584603101c40a7ec58dd041710d20fc6ff55.ct7youvpvruy.ap-south-1.rds.amazonaws.com',
    user: 'hlisteamUDB',
    password: 'Q8U+jpI!4#vGD',
    database: 'eassyservermain',
    dateStrings: "date"
});

// var read = mysql.createPool({
//     connectionLimit: 100,
//     host: 'localhost',
//     user: 'root',
//     password: '',
//     database: 'eassyserve_devlopment',
//     dateStrings: 'date',
//     debug: false
// });

// // // only use to write opration
// var write = mysql.createPool({
//     connectionLimit: 100,
//     host: 'localhost',
//     user: 'root',
//     password: '',
//     database: 'eassyserve_devlopment',
//     dateStrings: 'date',
//     debug: false
// });

module.exports = { read, write };