const { read, write } = require('./database');
const GLOBALS = require('./constants');
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
const lang = require("./language");
const moment = require('moment');
const request = require('request');

const common = {
    validate_token: function(req, res, callback) {
        try {
            req.language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9") ? req.headers['accept-language'] : 'en';
            var path_data = req.path.split("/");
            var byPassHeader = new Array('quickbook_auth_callback', 'get_gst_rate');
            var byPassMethod = new Array('send_notification', 'razorpay_contactss', 'check_unique', 'send_otp', 'verify_otp', 'signup', 'signin', 'reset_password', 'category_list', 'check_version', 'taxcode_list', 'refund_from_admin', 'check_mobile_num_exist');
            if (byPassHeader.indexOf(path_data[path_data.length - 1]) === -1) {
                if (req.headers['api-key'] != undefined && req.headers['api-key'] != "") {
                    var api_key = cryptoLib.decrypt(req.headers['api-key'], shaKey, GLOBALS.ENC_IV);

                    if (api_key == GLOBALS.API_KEY) {
                        if (byPassMethod.indexOf(path_data[path_data.length - 1]) === -1) {
                            // console.log(req.headers);
                            if (req.headers['token'] != undefined && req.headers['token'] != null && req.headers['token'] != '') {
                                // console.log(req.headers['token']);
                                console.log("device token", cryptoLib.decrypt(req.headers['token'], shaKey, GLOBALS.ENC_IV));
                                read.query(`SELECT user_id FROM tbl_user_device WHERE token = '${cryptoLib.decrypt(req.headers['token'], shaKey, GLOBALS.ENC_IV)}'`, function(err, result) {
                                    if (result.length != 0) {
                                        req.login_user_id = result[0].user_id;
                                        console.log("login user id ", req.login_user_id);
                                        callback();
                                    } else {
                                        common.sendResponse(res, "-1", lang[req.language]['text_rest_tokeninvalid'], null, '401');
                                    }
                                });
                            } else {
                                common.sendResponse(res, "-1", lang[req.language]['text_rest_required_token'], null, '401');
                            }
                        } else {
                            callback();
                        }
                    } else {
                        common.sendResponse(res, "-1", lang[req.language]['text_rest_invalid_api_key'], null, '401');
                    }
                } else {
                    common.sendResponse(res, "-1", lang[req.language]['text_rest_required_api_key'], null, '401');
                }
            } else {
                callback();
            }
        } catch (err) {
            common.sendResponse(res, "-1", lang[req.language]['text_rest_invalid_api_key'], null, '401');
        }
    },

    checkValidation: function(params, rules, res, language = 'en') {
        var messages = {
            "required": lang[language]['required'],
            "email": lang[language]['email'],
            "integer": lang[language]['integer'],
            "in": lang[language]['in']
        }
        const v = require('Validator').make(params, rules, messages);
        if (v.fails()) {
            const errors = v.getErrors();
            common.sendResponse(res, "0", Object.values(errors)[0][0], null);
        } else {
            return true;
        }
    },

    check_unique: function(params, callback) {
        common.unique_fields('mobile_number', params.mobile_number, params.user_type).then((resMobile) => {
            if (params.email) {
                common.unique_fields('email', params.email, params.user_type).then((resEmail) => {
                    callback(false);
                }).catch((err) => {
                    callback(true, params.email, 'email');
                })
            } else {
                callback(false);
            }
        }).catch((err) => {
            callback(true, params.mobile_number, 'mobile_number');
        })
    },

    unique_fields: function(field, value, role) {
        console.log(field);
        console.log(value);
        console.log(role);
        return new Promise((resolve, reject) => {
            read.query(`SELECT id FROM tbl_user WHERE ${field} = '${value}' AND role = '${role}' AND is_active != '0'`, function(err, result) {
                console.log(this.sql);
                console.log(result);
                if (result.length > 0) {
                    reject(true);
                } else {
                    resolve(false);
                }
            })
        })
    },

    checkDeviceInfo: function(id, params, callback) {
        console.log("check device info", params);
        const moment = require('moment');
        read.query(`SELECT * FROM tbl_user_device WHERE user_id = '${id}'`, function(err, result) {
            var token = Math.round((new Date()).getTime() / 100) + common.stringGen(12) + common.numberGen(16);
            var device = {
                "token": token,
                "device_token": params.device_token,
                "device_type": params.device_type,
                "device_model": (params.device_model != null) ? params.device_model : '',
                "uuid": (params.uuid != null) ? params.uuid : '',
                "ip": (params.ip != null) ? params.ip : '',
                "voip_token": (params.voip_token != null) ? params.voip_token : '',
            }

            if (result.length != 0) {

                device['update_datetime'] = moment().format("X");
                write.query(`UPDATE tbl_user_device SET ? WHERE user_id = '${id}'`, device, function(err, result) {
                    if (result.affectedRows != 0) {
                        callback(device);
                    } else {
                        callback(null);
                    }
                });
            } else {

                device["user_id"] = id;
                device['insert_datetime'] = moment().format("X");
                write.query(`INSERT INTO tbl_user_device SET ?`, device, function(err, result) {

                    if (result != undefined) {
                        callback(device);
                    } else {
                        callback(null);
                    }
                });
            }
        });
    },

    sendResponse: function(res, resCode, resMessage, resData, resStatus = '200') {
        var response = {
            "code": resCode,
            "message": resMessage.toLowerCase()
                // "code": 0,            
                // "message": 'sorry for the inconvenience. application is under maintenance. please try after some time !'
        }
        if (resData != null) {
            response["data"] = resData;
        }
        common.encryption(response, function(result) {
            res.status(resStatus);
            res.json(result);
            res.end();
        })
    },

    decryption: function(req, callback) {
        if (req != undefined && Object.keys(req).length !== 0) {
            try {
                var request = JSON.parse(cryptoLib.decrypt(req, shaKey, GLOBALS.ENC_IV));
            } catch (e) {
                var request = cryptoLib.decrypt(req, shaKey, GLOBALS.ENC_IV);
            }
            callback(request);
        } else {
            callback({});
        }
    },

    encryption: function(req, callback) {
        var response = cryptoLib.encrypt(JSON.stringify(req), shaKey, GLOBALS.ENC_IV);
        callback(response);
    },

    //add data to table
    add_data(table, params, callback) {
        console.log("check params", params);
        write.query(`INSERT INTO ${table} SET ?`, params, function(err) {
            callback(true);
        });
    },

    //Update data to table
    update_data: function(table, id, params) {
        write.query(`UPDATE ${table} SET ? WHERE id="${id}"`, params); //end select query;
    },

    // get provider and staff ids with sub category
    async get_provider_ids(id, sub_category_id) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT id, parent_id FROM tbl_user WHERE id = ${id} AND is_active = '1'`, (err, result) => {
                if (!err && result[0] != undefined && result[0].parent_id == 0) {
                    let join = (sub_category_id != 0) ? `JOIN tbl_category_service AS cs ON cs.user_id = u.id` : ``
                    let where = (sub_category_id != 0) ? `AND cs.sub_category_id IN (${sub_category_id})` : ``
                    read.query(`SELECT u.id FROM tbl_user AS u ${join} WHERE u.parent_id = ${id} AND u.is_active = '1' ${where}`, (sErr, sResult) => {
                        if (!sErr && sResult[0] != undefined) {
                            let ids = sResult.map(element => element.id);
                            resolve({ ids: ids + ',' + id });
                        } else {
                            resolve({ ids: id + '' });
                        }
                    })
                } else {
                    resolve({ ids: id + '' });
                }
            })
        })
    },

    // send sms
    send_sms(phone, otp, template, callback) {
        var request = require('request');
        var options = {
            'method': 'POST',
            'url': `https://2factor.in/API/V1/${GLOBALS.SMS_API_KEY}/SMS/${phone}/${otp}/${template}`,
            'headers': {
                'api-key': '05XJj94siXoRXJtHl8BYoWQnDbazeQ1vooGbgZl1Yfc2Oo7KRnLwpbwkH7mjVUg/',
                'Content-Type': 'text/plain'
            },
            // body: "tHC7yrPR26xJYsz564B7ifymE0YaTlOKG+rug7nPAtQyYRWEEsuVaM8F2TFmV69OIi14ALfkQQMDSZre7u6bYQ=="
        };
        console.log(options)
        request(options, function(error, response) {
            if (error) throw new Error(error);
            let response1 = JSON.parse(response.body);
            console.log(response1)
            if (response1.Status == "Success") {
                callback({ code: true, session_id: response1.Details });
            } else {
                callback({ code: false });
            }
        });
    },

    //send mail
    send_email: function(from, subject, to_email, message, callback) {
        let nodemailer = require('nodemailer');
        let transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true, // true for 465, false for other ports
            auth: {
                user: GLOBALS.EMAIL_ID, // generated ethereal user
                pass: GLOBALS.EMAIL_PASSWORD // generated ethereal password
            }
        });

        // setup email data with unicode symbols
        let mailOptions = {
            from: from, // sender address
            to: to_email, // list of receivers 'sonalih@hyperlinkinfosystem.net.in'
            subject: subject, // Subject line
            html: message
        };
        console.log(from, to_email, subject)

        // send mail with defined transport object
        transporter.sendMail(mailOptions, (error, info) => {
            console.log(error)
            if (error) {
                callback(false);
            } else {
                callback(true);
            }
        });
    },

    // async razorpay_orders(amount) {
    //     return new Promise((resolve, reject) => {
    //         var options = {
    //             method: 'POST',
    //             url: `https://api.razorpay.com/v1/orders`,
    //             headers: {
    //                 'Authorization': 'Basic ' + Buffer.from(GLOBALS.TEST_KEY_ID + ':' + GLOBALS.TEST_KEY_SECRET).toString('base64'),
    //                 'Content-Type': 'application/json'
    //             },
    //             body: JSON.stringify({
    //                 amount: parseFloat(amount) * 100,
    //                 currency: 'INR'
    //             })
    //         }
    //         resolve('1253694');

    //         // request(options, (error, response, body) => {
    //         //     console.log("======================body=====================", body);
    //         //     var response = JSON.parse(response.body);
    //         //     console.log("======================body=====================", response.id);
    //         //     if (error) {
    //         //         reject();
    //         //     } else {
    //         //         resolve(response.id);
    //         //     }

    //         // })
    //     })
    // },

    async razorpay_create_contact(parms, user_id) {
        return new Promise((resolve, reject) => {
            var options = {
                method: 'POST',
                url: `https://api.razorpay.com/v1/contacts`,
                headers: {
                    'Authorization': 'Basic ' + Buffer.from(GLOBALS.TEST_KEY_ID + ':' + GLOBALS.TEST_KEY_SECRET).toString('base64'),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(parms)
            }
            request(options, (error, response, body) => {
                // console.log("====================== Conacts body 1=====================", body);
                let contact = JSON.parse(response.body);
                // console.log("====================== Conacts id =====================", response.id);
                if (error) {
                    reject();
                } else {
                    console.log("====================== Conacts id =====================", contact.id);
                    write.query(`UPDATE tbl_user SET contact_id = '${contact.id}' WHERE id = '${user_id}'`, (err, result) => {
                        resolve(contact.id);
                    });
                }
            })
        })
    },


    async razorpay_create_fundsaccount(parms, user_id) {
        // console.log("======fund_accounts ============", parms);
        // var test = JSON.parse(parms);
        return new Promise((resolve, reject) => {
            var options = {
                    method: 'POST',
                    url: `https://api.razorpay.com/v1/fund_accounts`,
                    headers: {
                        'Authorization': 'Basic ' + Buffer.from(GLOBALS.TEST_KEY_ID + ':' + GLOBALS.TEST_KEY_SECRET).toString('base64'),
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(parms)
                }
                // resolve('hy');
            request(options, (error, response, body) => {
                console.log("====================== fund_accounts body 1=====================", body);
                var response = JSON.parse(response.body);
                console.log("====================== fund_accounts id =====================", response.id);
                if (error) {
                    console.log("=================================");
                    reject();
                } else {
                    // console.log(response.error.code);
                    if (response.id != ' ' && response.id != undefined) {
                        write.query(`UPDATE tbl_user SET verify_bank_details = 'verify', fund_id = '${response.id}' WHERE id = '${user_id}'`, (err, result) => {
                            resolve()
                        });
                    } else {

                        write.query(`UPDATE tbl_user SET verify_bank_details = 'reject',fund_id = '' WHERE id = '${user_id}'`, (err, result) => {
                            resolve()
                        });
                    }

                }

            })
        })
    },


    //payout 
    async razorpay_payout(parms) {
        console.log("======fund_accounts ============", parms);
        // var test = JSON.parse(parms);
        return new Promise((resolve, reject) => {
            var options = {
                method: 'POST',
                url: `https://api.razorpay.com/v1/payouts`,
                headers: {
                    'Authorization': 'Basic ' + Buffer.from(GLOBALS.TEST_KEY_ID + ':' + GLOBALS.TEST_KEY_SECRET).toString('base64'),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(parms)
            }
            request(options, (error, response, body) => {
                console.log("====================== fund_accounts body 1=====================", body);
                var response = JSON.parse(response.body);
                console.log("====================== fund_accounts id =====================", response.id);
                if (error) {
                    reject();
                } else {
                    console.log("payout respoanse", response.error);
                    console.log("payout respoanse sdddd", response);

                    write.query(`UPDATE tbl_payout SET status =  '${response.status}', payout_id = '${response.id}' WHERE order_id = '${parms.reference_id}'`, (err, result) => {
                        resolve(response.status);
                    });
                }

            })
        })
    },

    // JSON.stringify(parms)
    async razorpay_orders(amount) {
        return new Promise((resolve, reject) => {
            var options = {
                method: 'POST',
                url: `https://api.razorpay.com/v1/orders`,
                headers: {
                    'Authorization': 'Basic ' + Buffer.from(GLOBALS.TEST_KEY_ID + ':' + GLOBALS.TEST_KEY_SECRET).toString('base64'),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    amount: parseFloat(amount) * 100,
                    currency: 'INR'
                })
            }
            request(options, (error, response, body) => {
                console.log("======================body=====================", body);
                var response = JSON.parse(response.body);
                console.log("======================body=====================", response.id);
                if (error) {
                    reject();
                } else {
                    resolve(response.id);
                }

            })
        })
    },

    async razorpay_capture(pay_id, amount) {
        return new Promise((resolve, reject) => {
            var options = {
                method: 'POST',
                url: `https://api.razorpay.com/v1/payments/${pay_id}/capture`,
                headers: {
                    'Authorization': 'Basic ' + Buffer.from(GLOBALS.LIVE_KEY_ID + ':' + GLOBALS.LIVE_KEY_SECRET).toString('base64'),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    amount: parseFloat(amount) * 100,
                    currency: 'INR'
                })
            }
            request(options, (error, response, body) => {
                let sql = '';
                if (error) {
                    sql += "INSERT INTO tbl_razorpay_issue (log) VALUES ('" + JSON.stringify(error) + "')";
                }
                if (body) {
                    sql += "INSERT INTO tbl_razorpay_issue (log) VALUES ('" + JSON.stringify(body) + "')";
                }
                write.query(sql, function(err, result) {
                    console.log(this.sql);
                });
                resolve()
            })
        })
    },

    refund_from_admin(id, amount) {
        return new Promise((resolve, reject) => {
            let q = read.query(`SELECT id,transaction_id,order_id FROM tbl_booking WHERE id = ${id} LIMIT 1`, (error, result) => {
                console.log(q.sql)
                console.log(result[0])
                if (!error) {
                    var options = {
                        method: 'POST',
                        url: `https://api.razorpay.com/v1/payments/${result[0].transaction_id}/refund`,
                        headers: {
                            'Authorization': 'Basic ' + Buffer.from(GLOBALS.LIVE_KEY_ID + ':' + GLOBALS.LIVE_KEY_SECRET).toString('base64'),
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            amount: parseFloat(amount) * 100,
                            receipt: `Booking Report Issue Refund ${result[0].order_id}`
                        })
                    }
                    request(options, (error, response, body) => {
                        console.log(error, body)
                        if (error) {
                            reject();
                        } else {
                            try {
                                body = JSON.parse(body)
                            } catch (e) {
                                body = body
                            }
                            console.log(body)
                            console.log(body.id, body.status)
                            write.query(`UPDATE tbl_booking_issue SET status = 'complete',refund_id = '${body["id"]}',refund_status = '${body["status"]}' WHERE transaction_id = '${result[0].transaction_id}'`, (err, result) => {
                                resolve()
                            });
                        }
                    })
                } else {
                    reject();
                }
            })
        })
    },

    async razorpay_refund(pay_id, amount, receipt) {
        return new Promise((resolve, reject) => {
            var options = {
                method: 'POST',
                url: `https://api.razorpay.com/v1/payments/${pay_id}/refund`,
                headers: {
                    'Authorization': 'Basic ' + Buffer.from(GLOBALS.LIVE_KEY_ID + ':' + GLOBALS.LIVE_KEY_SECRET).toString('base64'),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    amount: parseFloat(amount) * 100,
                    receipt: receipt
                })
            }
            request(options, (error, response, body) => {
                if (error) {
                    reject()
                } else {
                    try {
                        body = JSON.parse(body)
                    } catch (e) {
                        body = body
                    }
                    console.log(body)
                    console.log(body.id, body.status)
                    write.query(`UPDATE tbl_booking SET payment_status = 'refund',refund_id = '${body["id"]}',refund_status = '${body["status"]}' WHERE transaction_id = '${pay_id}'`, (err, result) => {
                        resolve()
                    });
                }
            })
        })
    },

    // prepare admin notification for publish [ poll, quiz, story ]
    prepare_admin_notification: function(push_params, callback) {
        try {
            push_params = JSON.parse(push_params);
        } catch (error) {
            push_params = push_params;
        }

        if (push_params.push_params.custom.tag == 'admin_notification') {
            // send notification to android devices
            common.send_device_push(push_params, 'A', function(resCode) {
                // send notification to iOS devices
                common.send_device_push(push_params, 'I', function(resCode) {
                    callback(1);
                });
            });
        } else {
            read.query(`SELECT current_language,CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE id = ${push_params.receiver_id} LIMIT 1`, (err, result) => {
                var push_data = {
                    title: lang[result[0].current_language][push_params.push_params.title].replace('{sp_name}', result[0].sp_name),
                    body: lang[result[0].current_language][push_params.push_params.body],
                    custom: {
                        tag: push_params.push_params.custom.tag
                    }
                }
                var push_notification = {
                    sender_id: push_params.sender_id,
                    receiver_id: push_params.receiver_id,
                    action_id: push_params.push_params.custom.action_id,
                    message: JSON.stringify({ title: push_params.push_params.title, body: push_params.push_params.body }),
                    tag: push_params.push_params.custom.tag,
                    insert_datetime: moment().format("X")
                }
                common.prepare_notification(push_params.receiver_id, push_data)
                common.add_data('tbl_notification', push_notification, (res) => {})
            });
        }
    },

    // common function to send bulk notification using batchTokens
    send_device_push: function(push_data, device_type, callback) {
        // AND d.device_token NOT IN ('','0','fcmToken')
        let where = ``
        if (push_data.receiver_id != 0) {
            where = `AND u.id IN (${push_data.receiver_id})`
        }
        read.query(`SELECT d.device_token, d.voip_token,d.user_id,CONCAT(u.first_name,' ',u.last_name) AS sp_name,u.current_language FROM tbl_user AS u JOIN tbl_user_device AS d ON d.user_id = u.id AND d.device_type = '${device_type}' WHERE u.is_active = '1' AND u.role = '${push_data.role}' ${where}`, function(aErr, aResult) {
            if (!aErr && aResult.length > 0) {
                var results = aResult.map(x => x.device_token);
                var user = aResult.map(x => x.user_id);
                // split a device token in batches
                common.split_tokens(results, function(tokenBatches) {
                    // split a user in batches
                    common.split_tokens(user, function(userBatches) {
                        var asyncLoop = require('node-async-loop');
                        let body = (push_data.push_params.body.length >= 100) ? push_data.push_params.body.substring(0, 100) + '...' : push_data.push_params.body;
                        let push_params = {
                            title: push_data.push_params.title.toLowerCase(),
                            body: body.toLowerCase(),
                            topic: (push_data.role == "customer") ? GLOBALS.BUNDLEID : GLOBALS.TEAMBUNDLEID,
                            priority: 'high',
                            notification: {
                                title: push_data.push_params.title.toLowerCase(),
                                body: body.toLowerCase(),
                            },
                            alert: {
                                title: push_data.push_params.title.toLowerCase(),
                                body: body.toLowerCase(),
                            },
                            custom: push_data.push_params.custom
                        }
                        if (device_type == "I") {
                            push_params.sound = "default";
                        }
                        let push_notification = {
                            sender_id: 0,
                            action_id: push_data.push_params.custom.action_id,
                            message: JSON.stringify({ title: push_data.push_params.title, body: push_data.push_params.body }),
                            tag: push_data.push_params.custom.tag,
                            insert_datetime: moment().format("X")
                        }
                        let i = 0;
                        // send to batch wise notification
                        asyncLoop(tokenBatches, (registrationIds, next) => {
                            common.send_push(registrationIds, push_params);
                            common.add_notification_bulk(userBatches[i], push_notification);
                            i++;
                            next();
                        }, function() {
                            callback(1);
                        });
                    });
                });
            } else {
                callback(1);
            }
        });
    },

    add_notification_bulk: function(result, push_notification) {
        let asyncLoop = require('node-async-loop');
        asyncLoop(result, (item, next) => {
            let notification = {
                sender_id: push_notification.sender_id,
                receiver_id: item,
                action_id: push_notification.action_id,
                message: push_notification.message,
                tag: push_notification.tag,
                insert_datetime: push_notification.insert_datetime
            }
            common.add_data('tbl_notification', notification, (res) => {});
            next();
        });
    },

    // split a device token in batch limit
    split_tokens: function(results, callback) {
        var batchLimit = 1000;
        var tokenBatches = [];

        for (var start = 0; start < results.length; start += batchLimit) {
            var slicedTokens = results.slice(start, start + batchLimit);
            tokenBatches.push(slicedTokens);
        }

        callback(tokenBatches);
    },

    // Prepare data for push notification
    prepare_notification: function(user_id, push_params) {
        read.query(`SELECT u.id,u.role,d.device_token,d.voip_token,d.device_type FROM tbl_user AS u JOIN tbl_user_device AS d ON d.user_id = u.id WHERE u.is_active != '0' AND d.device_token NOT IN ('','0') AND u.id = '${user_id}' LIMIT 1`, (err, result) => {
            if (!err && result[0] != undefined) {
                // console.log(result[0].device_token);
                push_params.title = (push_params.title.length < 65) ? push_params.title : push_params.title.substring(0, 65) + '...'
                push_params.body = (push_params.body.length < 100) ? push_params.body : push_params.body.substring(0, 100) + '...'
                push_params.custom.title = push_params.title
                push_params.custom.date = moment().format("X")
                push_params.custom.body = push_params.body

                var push_data = {
                    // title: push_params.title.toLowerCase(),
                    // body: push_params.body.toLowerCase(),
                    // tag: `new_message`,
                    topic: (result[0].role == "customer") ? GLOBALS.BUNDLEID : GLOBALS.TEAMBUNDLEID,
                    notification: {
                        title: push_params.title.toLowerCase(),
                        body: push_params.body.toLowerCase(),
                        tag: push_params.custom.tag
                    },
                    silent: false,
                    alert: {
                        title: push_params.title.toLowerCase(),
                        body: push_params.body.toLowerCase(),
                        tag: push_params.custom.tag
                    },
                    custom: push_params.custom,
                    data: push_params.custom
                };
                console.log("normal notiffication ");
                console.log(push_data);
                if (result[0].device_type == "I") {
                    push_data['sound'] = "default";
                }
                const registrationIds = [];
                console.log("devicd token ", result[0].device_token);
                registrationIds.push(result[0].device_token);
                common.send_push(registrationIds, push_data);
            }

        });
    },

    // Prepare data for voip push notification
    voip_prepare_notification: function(params, push_params) {
        read.query(`SELECT u.id,u.role,d.device_token,d.voip_token,d.device_type FROM tbl_user AS u JOIN tbl_user_device AS d ON d.user_id = u.id WHERE u.is_active != '0' AND d.device_token NOT IN ('','0') AND u.id = '${params.user_id}' LIMIT 1`, (err, result) => {
            if (!err && result[0] != undefined) {
                console.log(params);
                read.query(`SELECT CONCAT('${GLOBALS.S3_URL + GLOBALS.USER_IMAGE}',profile_image) AS profile_image, current_language,first_name,last_name FROM tbl_user WHERE id = ${params.caller_id} LIMIT 1`, (err, result3) => {
                    console.log(result3[0]);
                    // console.log(result[0].device_token);

                    push_params.title = (push_params.title.length < 65) ? push_params.title : push_params.title.substring(0, 65) + '...'
                    push_params.body = (push_params.body.length < 100) ? push_params.body : push_params.body.substring(0, 100) + '...'
                    push_params.custom.first_name = result3[0].first_name
                    push_params.custom.last_name = result3[0].last_name
                    push_params.custom.profile_image = result3[0].profile_image

                    push_params.custom.title = push_params.title

                    push_params.custom.body = push_params.body
                    push_params.custom.date = moment().format("X")

                    var push_data = {
                        // title: push_params.title.toLowerCase(),
                        // body: push_params.body.toLowerCase(),
                        // tag: `new_message`,
                        topic: (result[0].role == "customer") ? GLOBALS.CUSTOMER_VOIP : GLOBALS.TEAMBUNDLEIDVOIP,
                        notification: {
                            title: push_params.title.toLowerCase(),
                            body: push_params.body.toLowerCase(),
                            tag: push_params.custom.tag
                        },
                        silent: false,

                        alert: {
                            title: push_params.title.toLowerCase(),
                            body: push_params.body.toLowerCase(),
                            tag: push_params.custom.tag,

                        },
                        custom: push_params.custom,

                        data: push_params.custom
                    };
                    console.log(push_data);
                    if (result[0].device_type == "I") {
                        push_data['sound'] = "default";
                        push_data['apns-expiration'] = moment().seconds() + 60;
                    }
                    const registrationIds = [];

                    registrationIds.push(result[0].voip_token);
                    common.send_push(registrationIds, push_data);
                })
            }

        });
    },

    //send push
    send_push: function(registrationIds, data) {
        const settings = {
            gcm: {
                id: GLOBALS.GCM_PUSH_KEY,
            },
            apn: {
                token: {
                    key: GLOBALS.APN_PUSH_KEY,
                    keyId: GLOBALS.KEYID,
                    teamId: GLOBALS.TEAMID,
                },
                production: false
            },
            isAlwaysUseFCM: false
        };
        const PushNotifications = require('node-pushnotifications');
        const push = new PushNotifications(settings);
        // console.log("========================")
        // console.log(data);
        push.send(registrationIds, data, (err, result) => {
            if (err) {
                console.log('error');
                console.log(err);
            } else {
                console.log('succ');
                console.log(result);
                console.log(result[0].message);
            }
        });
    },

    //number random generate
    numberGen(len) {
        this.timestamp = +new Date;
        var _getRandomInt = function(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
        var ts = this.timestamp.toString();
        var parts = ts.split("").reverse();
        var id = "";
        for (var i = 0; i < len; ++i) {
            var index = _getRandomInt(0, parts.length - 1);
            parts[index] = parts[index] == "0" ? 4 : parts[index];
            id += parts[index];
        }
        return id;
    },

    //string random generate
    stringGen(len) {
        var result = [];
        var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        var charactersLength = characters.length;
        for (var i = 0; i < len; i++) {
            result.push(characters.charAt(Math.floor(Math.random() * charactersLength)));
        }
        return result.join('');
    },

    // number to words
    in_word(num) {
        var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
        var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

        if ((num = num.toString()).length > 9) return 'overflow';
        n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) return;
        var str = '';
        str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
        str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
        str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
        str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
        str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';
        return str + 'only';
    },

    //get all time slot a day
    get_all_time_slot(pstart_time = '00:00', pend_time = '23:00') {
        let start_time = moment(pstart_time, 'HH:mm');
        let end_time = moment(pend_time, 'HH:mm');
        let interval = 60;
        let timeslot = [];
        while (start_time <= end_time) {
            timeslot.push(new moment(start_time).format('HH:mm'));
            start_time.add(interval, 'minutes');
        }
        return timeslot;
    },

    get_all_month_date_slot(start_date, end_date) {
        let monthslot = [];
        let date = new Date(start_date);
        let end = new Date(end_date);
        while (date <= end) {
            monthslot.push(moment(date).format('YYYY-MM-DD'));
            date.setDate(date.getDate() + 1)
        }
        return monthslot;
    },

    get_old_image_name_and_delete: function(table, field, where, dirname, callback) {
        read.query(`SELECT ${field} AS image FROM ${table} WHERE ${where}`, (err, result) => {
            if (!err && result[0] != undefined) {
                if (result[0].image) {
                    common.deleteSingleFileS3(dirname, result[0].image);
                    callback();
                } else {
                    callback();
                }
            } else {
                callback();
            }
        })
    },

    // Function to delete single image from the s3 bucket
    deleteSingleFileS3: function(dirName, fileName) {

        if (fileName == 'default-user.png') {
            // callback(1);
            return;
        }
        const AWS = require('aws-sdk');
        const s3 = new AWS.S3({
            accessKeyId: GLOBALS.S3_ACCESS_KEY,
            secretAccessKey: GLOBALS.S3_SECRET_KEY,
            region: GLOBALS.S3_REGION
        });

        let params = {
            Bucket: GLOBALS.S3_BUCKET_NAME, // pass your bucket name
            Key: dirName + fileName, // file will be saved as user/xyz.png
        }

        s3.deleteObject(params, function(err, data) {
            if (err) {
                console.log(err, err.stack); // error
                // callback("0");
            } else {
                // callback("1");
            }
        });
    },

    // Function to delete multiple image from the s3 bucket
    deleteMultipleFileS3: function(dirName, filesName, keyname, callback) {
        const AWS = require('aws-sdk');
        const s3 = new AWS.S3({
            accessKeyId: GLOBALS.S3_ACCESS_KEY,
            secretAccessKey: GLOBALS.S3_SECRET_KEY,
            region: GLOBALS.S3_REGION
        });

        var deleteObjects = [];
        asyncLoop(filesName, function(item, next) {
            if (item.image == 'default.png') {
                next();
            } else {
                deleteObjects.push({ Key: dirName + item.image }); // file will be saved as user/xyz.png
                next();
            }
        }, function() {
            var options = {
                Bucket: GLOBALS.BUCKET_NAME, // pass your bucket names
                Delete: {
                    Objects: deleteObjects
                }
            };
            s3.deleteObjects(options, function(err, data) {
                if (err) {
                    callback("0");
                } else {
                    callback("1");
                }
            });
        });
    },
}
module.exports = common;