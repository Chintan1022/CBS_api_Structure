const GLOBALS = require('../config/constants');
const { read, write } = require('./database');
const OAuthClient = require('intuit-oauth');
const oauthClient = new OAuthClient({
    clientId: GLOBALS.QB_CLIENT_ID,
    clientSecret: GLOBALS.QB_SECRET,
    environment: GLOBALS.QB_ENVIRONMENT,
    redirectUri: 'https://www.eassyserve.com/api/quickbook_auth_callback'
});
const node_quickbooks = require('node-quickbooks');
const asyncLoop = require('node-async-loop');
const moment_timezone = require('moment-timezone');

const quickbook = {

    async generate_token() {
        return new Promise((resolve, reject) => {
            const authUri = oauthClient.authorizeUri({
                scope: [OAuthClient.scopes.Accounting, OAuthClient.scopes.OpenId],
                state: 'testState'
            });
            console.log(authUri);
            resolve(authUri)
        })
    },

    async create_token(url) {
        console.log("fdfdfdfdfdf");
        return new Promise((resolve, reject) => {
            oauthClient.createToken(url).then((authResponse) => {
                console.log("................", authResponse.getJson())
            }).catch((error) => {
                console.log(error)
            })
        })
    },

    async refresh_token() {
        console.log("ddsdsdsdsdsdsdsd");
        read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                console.log("==========================", rResult);

                let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                qbo.refreshAccessToken((err, accessToken) => {
                    if (!err) {
                        console.log(accessToken);
                        let updated_datetime = moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss");
                        write.query(`UPDATE tbl_setting_details SET attribute_value = '${accessToken.access_token}',updatedate = '${updated_datetime}' WHERE attribute_name = 'quickbook_oauth_token'`, (auErr, auResult) => {
                            write.query(`UPDATE tbl_setting_details SET attribute_value = '${accessToken.refresh_token}',updatedate = '${updated_datetime}' WHERE attribute_name = 'quickbook_oauth_refresh_token'`, (ruErr, ruResult) => {});
                        });
                    } else {
                        console.log(err)
                    }
                });
            });
        });
    },

    async create_customer(params) {
        read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                let customer = {
                    DisplayName: params.name,
                    PrimaryPhone: {
                        FreeFormNumber: params.mobile_number
                    },
                    PrimaryEmailAddr: {
                        Address: params.email
                    }
                }
                qbo.createCustomer(customer, (err, result) => {
                    if (!err) {
                        write.query(`UPDATE tbl_user SET quickbook_customer_id = '${result.Id}' WHERE id = ${params.user_id}`, (uErr, uResult) => {});
                    } else {
                        console.log(err)
                        console.log(err.Fault)
                    }
                });
            });
        });
    },
    // auth token
    // vizkr4DtB8aXpB9CH6aFis6l0haXlJbw.ZQ5LAiC_23XbKtUFIaUcsg
    //    refresh token
    // AB116554195015POpIoUVQsq7BCAE3Vq78RrxDM4blIgW4YbgK
    async edit_customer(params) {
        read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                qbo.getCustomer(params.quickbook_customer_id, (e, c) => {
                    if (!e) {
                        // console.log(c.SyncToken)
                        let customer = {
                            Id: params.quickbook_customer_id,
                            SyncToken: c.SyncToken,
                            DisplayName: params.name,
                            PrimaryPhone: {
                                FreeFormNumber: params.mobile_number
                            },
                            PrimaryEmailAddr: {
                                Address: params.email
                            }
                        }
                        qbo.updateCustomer(customer, (err, result) => {
                            if (!err) {
                                console.log(`DONE ${params.quickbook_customer_id}`)
                                    // write.query(`UPDATE tbl_user SET quickbook_customer_id = '${result.Id}' WHERE id = ${params.user_id}`,(uErr,uResult)=>{});
                            } else {
                                console.log(err)
                                console.log(err.Fault)
                            }
                        });
                    } else {
                        console.log(e)
                        console.log(e.Fault)
                    }
                });
            });
        });
    },

    async taxcode() {
        return new Promise((resolve, reject) => {
            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
                read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                    let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                    qbo.findTaxCodes('', (err, result) => {
                        if (err) {
                            console.log(err);
                            reject()
                        } else {
                            console.log("taxcode function");
                            console.log(result);
                            resolve(result.QueryResponse.TaxCode);
                        }
                    });
                });
            });
        });
    },

    async get_taxcode(id, sub_total, is_local) {
        return new Promise((resolve, reject) => {
            if (id) {
                console.log("log3", id);
                read.query(`SELECT taxcode_id,igst_taxcode_id FROM tbl_category WHERE id = ${id} LIMIT 1`, (err, result) => {
                    if (!err && result[0] != undefined) {
                        console.log("get_taxcode result");
                        console.log(result);
                        read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
                            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                                let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                                let code_id = (is_local == "true" || is_local == true) ? result[0].taxcode_id : result[0].igst_taxcode_id;
                                console.log("code id result ", code_id);

                                qbo.getTaxCode(code_id, (err, result) => {
                                    console.log("getTaxCode result.......");

                                    if (err) {
                                        console.log("error from quick book error ", err);
                                        reject();
                                    } else {
                                        let total = sgst = cgst = igst = sgst_amount = cgst_amount = igst_amount = 0
                                        asyncLoop(result.SalesTaxRateList.TaxRateDetail, (item, next) => {
                                            this.get_taxrate(item.TaxRateRef.value).then((resTaxRate) => {
                                                if (resTaxRate.description == "SGST") {
                                                    sgst = resTaxRate.rate
                                                        // total += (parseFloat(sub_total) * resTaxRate.rate) / 100;
                                                        // sgst_amount += (parseFloat(sub_total) * resTaxRate.rate) / 100;
                                                } else if (resTaxRate.description == "CGST") {
                                                    cgst = resTaxRate.rate
                                                        // total += (parseFloat(sub_total) * resTaxRate.rate) / 100;
                                                        // cgst_amount += (parseFloat(sub_total) * resTaxRate.rate) / 100;
                                                } else if (resTaxRate.description == "IGST") {
                                                    igst = resTaxRate.rate
                                                        // total += (parseFloat(sub_total) * resTaxRate.rate) / 100;
                                                        // igst_amount += (parseFloat(sub_total) * resTaxRate.rate) / 100;
                                                }
                                                next();
                                            });
                                        }, () => {
                                            sub_total = ((sub_total * 100) / (100 + (parseFloat(sgst) + parseFloat(cgst) + parseFloat(igst))))
                                            if (sgst) {
                                                sgst_amount = ((parseFloat(sub_total) * sgst) / 100);
                                                sgst_amount = parseFloat(sgst_amount)
                                            }
                                            if (cgst) {
                                                cgst_amount = ((parseFloat(sub_total) * cgst) / 100);
                                                cgst_amount = parseFloat(cgst_amount)
                                            }
                                            if (igst) {
                                                igst_amount = ((parseFloat(sub_total) * igst) / 100);
                                                igst_amount = parseFloat(igst_amount)
                                            }
                                            console.log("gst calculation");
                                            console.log("sgst_amount calculation", sgst_amount);
                                            console.log("cgst_amount calculation", cgst_amount);
                                            console.log("igst_amount calculation", igst_amount);
                                            total = sgst_amount + cgst_amount + igst_amount
                                            console.log("total", total);
                                            resolve({ sub_total: sub_total, total: total, sgst: sgst, cgst: cgst, igst: igst, sgst_amount: sgst_amount, cgst_amount: cgst_amount, igst_amount: igst_amount });
                                        });
                                    }
                                });
                            });
                        });
                    } else {
                        reject();
                    }
                });
            } else {
                reject();
            }
        });
    },

    // ************** Get GST value *******************
    async get_taxcode_gst(sub_category_id) {
        return new Promise((resolve, reject) => {
            if (sub_category_id) {
                read.query(`SELECT taxcode_id,igst_taxcode_id FROM tbl_category WHERE id = ${sub_category_id} LIMIT 1`, (err, result) => {
                    if (!err && result[0] != undefined) {
                        console.log("get_taxcode result");
                        console.log("get_taxcode_gst", result);
                        let taxcode_id = result[0].taxcode_id;
                        let igst_taxcode_id = result[0].igst_taxcode_id;
                        read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
                            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                                let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                                console.log("get_taxcode_gst_taxcodde id", taxcode_id);

                                qbo.getTaxCode(taxcode_id, (err, result) => {
                                    if (err) {
                                        console.log(err);
                                        reject();
                                    } else {
                                        let sgst = cgst = igst = 0
                                        asyncLoop(result.SalesTaxRateList.TaxRateDetail, (item, next) => {
                                            this.get_taxrate(item.TaxRateRef.value).then((resTaxRate) => {
                                                if (resTaxRate.description == "SGST") {
                                                    sgst = resTaxRate.rate
                                                } else if (resTaxRate.description == "CGST") {
                                                    cgst = resTaxRate.rate
                                                }
                                                next();
                                            });
                                        }, () => {
                                            qbo.getTaxCode(igst_taxcode_id, (err, result) => {
                                                if (err) {
                                                    console.log(err);
                                                    resolve({ sgst: sgst, cgst: cgst, igst: igst });
                                                } else {
                                                    asyncLoop(result.SalesTaxRateList.TaxRateDetail, (item, next) => {
                                                        this.get_taxrate(item.TaxRateRef.value).then((resTaxRate) => {
                                                            if (resTaxRate.description == "IGST") {
                                                                igst = resTaxRate.rate
                                                            }
                                                            next();
                                                        });
                                                    }, () => {
                                                        console.log({ sgst: sgst, cgst: cgst, igst: igst });
                                                        resolve({ sgst: sgst, cgst: cgst, igst: igst });
                                                    });
                                                }
                                            });
                                        });
                                    }
                                });
                            });
                        });
                    } else {
                        reject();
                    }
                });
            } else {
                reject();
            }
        });
    },

    async get_taxrate(id) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
                read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                    let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                    qbo.getTaxRate(id, (err, result) => {
                        if (err) {
                            reject()
                        } else {
                            console.log("get_taxrate result");
                            console.log(result);
                            resolve({ rate: result.RateValue, description: result.Description });
                        }
                    });
                });
            });
        });
    },

    async create_invoice(user_id, lines, booking_id, order_id) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_token' LIMIT 1`, (aErr, aResult) => {
                read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'quickbook_oauth_refresh_token' LIMIT 1`, (rErr, rResult) => {
                    let qbo = new node_quickbooks(GLOBALS.QB_CLIENT_ID, GLOBALS.QB_SECRET, aResult[0].attribute_value, false, GLOBALS.QB_REALMID, GLOBALS.QB_ENVIRONMENT, false, null, '2.0', rResult[0].attribute_value);
                    read.query(`SELECT quickbook_customer_id,email FROM tbl_user WHERE id = ${user_id} LIMIT 1`, (uErr, uResult) => {
                        let invoice = {
                            DocNumber: order_id,
                            Line: lines,
                            CustomerRef: {
                                value: uResult[0].quickbook_customer_id
                            }
                        }
                        console.log(invoice)
                        console.log("======================")
                        qbo.createInvoice(invoice, (err, result) => {
                            if (err) {
                                console.log(err)
                                console.log("=========================")
                                console.log(err.Fault)
                                reject()
                            } else {
                                write.query(`UPDATE tbl_booking SET quickbook_invoice_id = '${result.Id}' WHERE id = ${booking_id}`, (iErr, iResult) => {
                                    qbo.sendInvoicePdf(result.Id, uResult[0].email, (sErr, sResult) => {
                                        resolve();
                                    });
                                });
                            }
                        });
                    });
                });
            });
        });
    }
}

module.exports = quickbook;