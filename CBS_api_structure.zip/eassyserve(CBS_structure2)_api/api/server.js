const express = require('express');
const GLOBALS = require('./config/constants')
const app = express();
const cluster = require('cluster');
const common = require('./config/common');
const session = require('express-session');
const compression = require('compression');
const path = require('path');
const socket = require('./modules/v2/chat/socket');


require('events').EventEmitter.defaultMaxListeners = 0;

if (cluster.isMaster) {
    console.log("Master is running");
    var cpuCores = require("os").cpus().length;
    for (var i = 0; i < cpuCores; i++) {
        let worker = cluster.fork();
        console.log(`Worker ${worker.id} is running`)
    }

    // Listen for dying workers
    cluster.on('exit', function(worker) {
        // Replace the dead worker
        console.log(`Worker %d died :(`, worker.id);
        worker = cluster.fork();
        console.log(`New worker ${worker.id} is running`)
    });

    require('./modules/v5/cron/route');
} else {
    const api = require('./modules/route');
    const routes = require('./modules/v1/api_document/routes');
    const user = require('./modules/v1/api_document/routes/user');

    app.use(
        session({
            secret: 'keyboard cat',
            resave: false,
            saveUninitialized: true,
            cookie: { maxAge: 1800000 }
        })
    )

    app.use(compression()); //use compression
    app.use(express.static(path.join(__dirname, 'public')));
    app.use(express.text());
    app.use(express.urlencoded({ extended: false }));

    app.get('/', routes.index);
    app.get('/login', routes.index);
    app.post('/login', user.login);
    app.get('/home/dashboard', user.dashboard);
    app.get('/home/user_list', user.user_list);
    app.get('/home/code', user.code);
    app.get('/home/enc_dec', user.enc_dec);
    app.get('/home/logout', user.logout);

    app.use(common.validate_token);
    app.use('/api', api);

    try {
        // set the template engine ejs
        app.set("view engine", "ejs");

        //middlewares
        app.use(express.static('public'));

        var server = app.listen(GLOBALS.PORT, () => console.log(`${GLOBALS.APP_NAME} server is starting on ${GLOBALS.PORT} port`));

        // socket io connect
        //var io = require('socket.io')(server);
        socket.connectSocket();
    } catch (error) {
        console.log("Failed to start server.");
    }
}