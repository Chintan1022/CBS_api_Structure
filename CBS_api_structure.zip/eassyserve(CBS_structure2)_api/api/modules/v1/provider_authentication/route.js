const express = require('express');
var authentication_model = require('./authentication_model');
var common = require('../../../config/common');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const lang = require("../../../config/language");
const asyncLoop = require("node-async-loop");

var router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signup                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signup', function(req, res)
{
    common.decryption(req.body, function(params) {
        var rules =  {
            "first_name" : "required",
            "last_name" : "required",
            "country_code" : "required",
            "mobile_number" : "required",
            "gender" : "required|in:male,female",
            "role" : "required|in:provider,learner",
            "password" : "required",
            "device_token" : "required",
            "device_type" : "required",
            "device_model" : "required",
            "uuid" : "required",
            "ip" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.language = req.language
            params.user_type = params.role;            
            common.check_unique(params, function(response, val) {
                if(response) {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null)
                }
                else {
                    var data =  {
                        "first_name" : params.first_name,
                        "last_name" : params.last_name,
                        ...(params.email) && {email:params.email},
                        "country_code" : params.country_code,
                        "mobile_number" : params.mobile_number,
                        "gender" : params.gender,
                        "referal_code" : common.stringGen(10),
                        ...(params.referal_code) && {friend_refer_code: params.referal_code},
                        "role" : params.role,
                        "insert_datetime" : moment().format("X")
                    }
                    const cryptoLib = require('cryptlib');
                    const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
                    data.password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV)
                    authentication_model.signup(data, params.referal_code, function(result)
                    {
                        if(result != null) {
                            common.checkDeviceInfo(result.insertId, params, function(response) {
                                if(response) {
                                    authentication_model.user_details({"user_id":result.insertId, 'language': req.language}, function(resCode, resMsg, resData){
                                        delete resData.password
                                        // delete resData.login_type
                                        resData['token'] = response.token
                                        common.sendResponse(res, "1", lang[req.language]['text_user_signup_success'], resData)
                                    })
                                }
                                else {
                                    common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null)
                                }
                            })
                        }
                        else {
                            common.sendResponse(res, "0", lang[req.language]['signup_unsuccess'], null)
                        }
                    });
                }
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Other Details                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/other_detail', function(req, res)
{
    common.decryption(req.body, function(params) {
        var rules =  {
            "total_experience" : "required",
            "location" : "required",
            "latitude" : "required",
            "longitude" : "required",
            "main_category" : "required",
            "sub_category" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            let updateData = {
                ...(params.profile_image) && {profile_image: params.profile_image},
                ...(params.bio) && {bio: params.bio},
                ...(params.kyc) && {bio: params.kyc},
                total_experience: params.total_experience,
                main_category: params.main_category,
                sub_category: params.sub_category,
                location: params.location,
                latitude: params.latitude,
                longitude: params.longitude,
                update_datetime: moment().format("X")
            }
            authentication_model.other_details(updateData,req.login_user_id)
            .then((resCode) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_other_detail_success'], null);
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_other_detail_fails'], null);
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Upload Document                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/upload_document', function(req, res)
{
    common.decryption(req.body, function(params) {
        var rules =  {
            "aadhar_number" : "required",
            "pan_number" : "required",
            "aadhar_number_file" : "required",
            "pan_number_file" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            if(params.gst){
                authentication_model.other_details({gst:params.gst},req.login_user_id).then((resCode)=>{}).catch((err)=>{})
            }
            let updateData = []
            updateData.push([
                req.login_user_id, params.aadhar_number, 'aadhar_number', moment().format("X")
            ])
            updateData.push([
                req.login_user_id, params.pan_number, 'pan_number', moment().format("X")
            ])
            asyncLoop(params.aadhar_number_file.split(','), (item,next) => {
                updateData.push([
                    req.login_user_id, item, 'aadhar_number_file', moment().format("X")
                ])
                next()
            }, () => {
                asyncLoop(params.pan_number_file.split(','), (item,next) => {
                    updateData.push([
                        req.login_user_id, item, 'pan_number_file', moment().format("X")
                    ])
                    next()
                }, () => {
                    if(params.certificate_file){
                        let fileExtension = ['jpg','png','jpeg','JPG','JPEG','PNG']
                        asyncLoop(params.certificate_file.split(','), (item,next) => {
                            updateData.push([
                                req.login_user_id, item, (fileExtension.indexOf(item.split('.').pop()) !== -1) ? 'certificate_image' : 'certificate_pdf', moment().format("X")
                            ])
                            next()
                        }, () => {
                            authentication_model.document_update(updateData,req.login_user_id).then((resCode) => {
                                authentication_model.get_document(req.login_user_id).then((resDocumentDetail)=>{
                                    resDocumentDetail.gst = (params.gst) ? params.gst : '';
                                    common.sendResponse(res, "1", lang[req.language]['text_user_document_success'], resDocumentDetail)
                                })
                            }).catch((err) => {
                                common.sendResponse(res, "0", lang[req.language]['text_user_document_fails'], null)
                            })
                        })
                    }else{
                        authentication_model.document_update(updateData,req.login_user_id).then((resCode) => {
                            authentication_model.get_document(req.login_user_id).then((resDocumentDetail)=>{
                                resDocumentDetail.gst = (params.gst) ? params.gst : '';
                                common.sendResponse(res, "1", lang[req.language]['text_user_document_success'], resDocumentDetail)
                            })
                        }).catch((err) => {
                            common.sendResponse(res, "0", lang[req.language]['text_user_document_fails'], null)
                        })
                    }
                })
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Bank List                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/bank_list", function(req, res) {
    authentication_model.bank_list().then((resData)=>{
        common.sendResponse(res, "1", lang[req.language]['text_user_bank_list_found'], resData)
    }).catch((err)=>{
        common.sendResponse(res, "2", lang[req.language]['text_user_bank_list_not_found'], null)
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Bank Details                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/bank_detail', function(req, res)
{
    common.decryption(req.body, function(params) {
        var rules =  {
            "bank_name" : "required",
            "account_number" : "required",
            "holder_name" : "required",
            "ifsc_code" : "required",
            "passbook_image" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            let data = {
                user_id: req.login_user_id,
                bank_name: params.bank_name,
                account_number: params.account_number,
                holder_name: params.holder_name,
                ifsc_code: params.ifsc_code,
                passbook_image: params.passbook_image
            }
            authentication_model.bank_details(data,req.login_user_id)
            .then((resCode) => {
                authentication_model.get_bank_details(req.login_user_id).then((resBankDetail)=>{
                    let message = (resCode == 1) ? lang[req.language]['text_user_bank_add_success'] : lang[req.language]['text_user_bank_update_success']
                    common.sendResponse(res, "1", message, resBankDetail);
                })
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_bank_fails'], null);
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signin                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signin', function(req, res)
{
    common.decryption(req.body, function(params)
    {
        var rules = {
            "country_code" : "required",
            "mobile_number" : "required",
            "password" : "required",
            "device_token" : "required",
            "device_type" : "required",
            "device_model" : "required",
            "uuid" : "required",
            "ip" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.language = req.language
            authentication_model.signin(params, function(resCode, resMsg, resData) {
                if(resData != null) {
                    common.checkDeviceInfo(resData.id, params, function(response){
                        if(response != null) {
                            delete resData.password;
                            resData['token'] = response.token;
                            common.sendResponse(res, resCode, resMsg, resData);
                        }
                        else {
                            common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                        }
                    });
                }
                else {
                    common.sendResponse(res, resCode, resMsg, resData);
                }
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Get Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_profile", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "user_id" : "required" }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.language = req.language
            authentication_model.user_details(params, function(resCode, resMsg, resData) {
                if(resCode == "1" && resData.parent_id == 0) {
                    delete resData.password;
                    // delete resData.login_type;
                }
                common.sendResponse(res, resCode, resMsg, resData);
            });
        }
    });
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Set Region                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/set_region', function(req, res)
{
    common.decryption(req.body, function(params) {
        var rules =  {
            "region_location" : "required",
            "region_building" : "required",
            "region_zipcode" : "required",
            "region_raduis" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            let updateData = {
                region_location: params.region_location,
                region_building: params.region_building,
                region_zipcode: params.region_zipcode,
                region_raduis: params.region_raduis,
                ...(params.region_latitute) && {region_latitute: params.region_latitute},
                ...(params.region_longitude) && {region_longitude: params.region_longitude},
                update_datetime: moment().format("X")
            }
            common.update_data('tbl_user',req.login_user_id,updateData)
            common.sendResponse(res, "1", lang[req.language]['text_user_region_success'], updateData)
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Edit Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/edit_profile', function(req, res)
{
    common.decryption(req.body, function(params) {
        var rules =  {
            "first_name" : "required",
            "last_name" : "required",
            "country_code" : "required",
            "mobile_number" : "required",
            "gender" : "required|in:male,female",
            "main_category" : "required",
            "sub_category" : "required",
            "total_experience" : "required",
            "location" : "required",
            "latitude" : "required",
            "longitude" : "required"
        }
        if(common.checkValidation(params, rules, res, req.language)) {
            authentication_model.edit_check_unique(req.login_user_id, params, function(response, val)
            {
                if(response) {
                    var data = {
                        "first_name" : params.first_name,
                        "last_name" : params.last_name,
                        ...(params.email) && {email: params.email},
                        "country_code" : params.country_code,
                        "mobile_number" : params.mobile_number,
                        "gender" : params.gender,
                        ...(params.bio) && {bio: params.bio},
                        ...(params.total_experience) && {total_experience: params.total_experience},
                        "location" : params.location,
                        "latitude" : params.latitude,
                        "longitude" : params.longitude,
                        "main_category" : params.main_category,
                        "sub_category" : params.sub_category,
                        "update_datetime" : moment().format("X")
                    }
                    if(params.profile_image){
                        common.get_old_image_name_and_delete(`tbl_user`,`profile_image`,`id = ${req.login_user_id}`,GLOBALS.USER_IMAGE, ()=>{});
                        data.profile_image = params.profile_image;
                    }
                    authentication_model.edit_profile(req.login_user_id, data, req.language, function(resCode, resMsg, resData) {
                        common.sendResponse(res, resCode, resMsg, resData);
                    });
                }
                else {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',val), null);
                }
            });
        }
    });
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Home Status                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/home_status', function(req, res)
{
    common.decryption(req.body, function(params) {
        // var rules =  { "first_name" : "required" }
        // if(common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            authentication_model.home_status(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData);
            }).catch((err)=>{
                common.sendResponse(res, "0", lang[req.language]['text_sql_err'], null);
            })
        // }
    });
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Add Staff                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_staff", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            first_name: 'required',
            last_name: 'required',
            country_code: 'required',
            mobile_number: 'required',
            aadhar_number: 'required',
            pan_number: 'required',
            aadhar_number_file: 'required',
            pan_number_file: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            if(params.password){
                const cryptoLib = require('cryptlib');
                const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
                params.password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV);
            }
            params.login_user_id = req.login_user_id
            authentication_model.add_staff(params).then((resCode)=>{
                if(resCode.code == 1){
                    let updateData = []
                    updateData.push([
                        resCode.id, params.aadhar_number, 'aadhar_number', moment().format("X")
                    ])
                    updateData.push([
                        resCode.id, params.pan_number, 'pan_number', moment().format("X")
                    ])
                    asyncLoop(params.aadhar_number_file.split(','), (item,next) => {
                        updateData.push([
                            resCode.id, item, 'aadhar_number_file', moment().format("X")
                        ])
                        next();
                    }, () => {
                        asyncLoop(params.pan_number_file.split(','), (item,next) => {
                            updateData.push([
                                resCode.id, item, 'pan_number_file', moment().format("X")
                            ])
                            next();
                        }, () => {
                            authentication_model.document_update(updateData,resCode.id)
                            .then((resDocumentDetail) => {
                                params.user_id = resCode.id;
                                if(params.sub_category_id){
                                    authentication_model.add_service(params).then((response)=>{
                                        authentication_model.user_details({user_id:resCode.id,language:req.language},(resC,resM,resD)=>{
                                            let action = (params.id) ? `updated` : `added`
                                            common.sendResponse(res, "1", lang[req.language]['text_staff_su'].replace('{action}',action), resD);
                                        })
                                    }).catch((error)=>{
                                        common.sendResponse(res, "0", lang[req.language]['text_add_service_fails'], null);
                                    })
                                }else{
                                    authentication_model.user_details({user_id:resCode.id,language:req.language},(resC,resM,resD)=>{
                                        let action = (params.id) ? `updated` : `added`
                                        common.sendResponse(res, "1", lang[req.language]['text_staff_su'].replace('{action}',action), resD);
                                    })
                                }
                            }).catch((err) => {
                                common.sendResponse(res, "0", lang[req.language]['text_user_document_fails'], null);
                            })
                        })
                    })
                }else{
                    let action = (resCode.code == 0) ? `added` : `updated`;
                    common.sendResponse(res, "0", lang[req.language]['text_staff_un'].replace('{action}',action), null);
                }
            }).catch((error) => {
                if(error.code == 5){
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}',error.val), null);
                }else{
                    let action = (error.code == 0) ? `added` : `updated`;
                    common.sendResponse(res, "0", lang[req.language]['text_staff_un'].replace('{action}',action), null);
                }
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Staff List                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/staff_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            page_token: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language)){
            params.login_user_id = req.login_user_id;
            authentication_model.staff_list(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_user_bank_list_found'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_user_bank_list_not_found'], null)
            })
        }
    })
})

module.exports = router;