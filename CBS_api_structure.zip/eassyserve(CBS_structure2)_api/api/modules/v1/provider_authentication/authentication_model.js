const { read,write } = require('../../../config/database');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const moment_timezone = require('moment-timezone');
const lang = require('../../../config/language');
const asyncLoop = require("node-async-loop");
const common = require('../../../config/common');

var auth = {

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Signup                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    signup : function(params, referal_code, callback)
    {
        read.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'commission' LIMIT 1`,(cErr,cResult)=>{
            params.commission = cResult[0].attribute_value;
            write.query(`INSERT INTO tbl_user SET ?`, params, function(err, result) {
                if(!err && result != undefined) {
                    // if(referal_code){
                    //     read.query(`SELECT id FROM tbl_user WHERE referal_code = '${referal_code}'`, function(uErr, uResult){
                    //         if(!uErr && uResult[0] != undefined){
                    //             write.query(`UPDATE tbl_user SET coin = coin + 20 WHERE id = '${uResult[0].id}'`);
                    //             write.query(`UPDATE tbl_user SET coin = coin + 50, friend_refer_code = '${referal_code}' WHERE id = '${result.insertId}'`);
                    //             let insertData = [
                    //                 [uResult[0].id,'refer_code',20,moment().format("X")],
                    //                 [result.insertId,'friend_refer_code',50,moment().format("X")]
                    //             ];
                    //             write.query(`INSERT INTO tbl_user_coins_collect(user_id,type,coin,insert_datetime) VALUES ?`, [insertData], function(cErr, cResult){
                    //                 let insertData = {
                    //                     user_id: uResult[0].id,
                    //                     friend_id: result.insertId,
                    //                     insert_datetime: moment().format("X")
                    //                 }
                    //                 write.query(`INSERT INTO tbl_user_friend SET ?`, insertData, function(fErr, fResult){
                    //                     callback(result);
                    //                 });
                    //             });
                    //         } else {
                    //             callback(result);
                    //         } 
                    //     });
                    // } else {
                        callback(result);
                    // }
                }
                else {
                    callback(null);
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                   Other Details                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    other_details : function(params, id)
    {
        return new Promise((resolve,reject) => {
            write.query(`UPDATE tbl_user SET ? WHERE id = '${id}'`, params, (err,result) => {
                if(!err) {
                    resolve("1")
                } else {
                    reject("0")
                }
            })
        })
    },
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Document Update                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    document_update : function(params, id)
    {
        return new Promise((resolve,reject) => {
            write.query(`DELETE FROM tbl_user_document WHERE user_id = '${id}'`, (dErr,dResult) => {
                write.query(`INSERT INTO tbl_user_document(user_id,name,type,insert_datetime) VALUES ?`, [params], (iErr,iResult) => {
                    if(!iErr) {
                        auth.user_reunverify(id)
                        resolve(1)
                    } else {
                        reject(0)
                    }
                })
            })
        })
    },
    async user_reunverify(id){
        read.query(`SELECT verify_document FROM tbl_user WHERE id = '${id}'`,(err,result)=>{
            if(!err && result[0] != undefined){
                if(result[0].verify_document == "reject"){
                    write.query(`UPDATE tbl_user SET verify_document = 'unverify' WHERE id = '${id}'`)
                }
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Get Documents                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_document : function(id)
    {
        return new Promise((resolve,reject) => {
            read.query(`SELECT IF(type = 'aadhar_number' OR type = 'pan_number',name,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_DOCUMENT_IMAGE}',name)) AS name, type FROM tbl_user_document WHERE user_id = ${id} AND type NOT IN ('certificate_image','certificate_pdf','aadhar_number_file')`,(err,result)=>{
                if(!err && result[0] != undefined){
                    let finalDocument = {};
                    result.map(function(element){
                        finalDocument[element.type] = element.name
                    })
                    read.query(`SELECT CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_DOCUMENT_IMAGE}',name) AS name FROM tbl_user_document WHERE user_id = ${id} AND type = 'aadhar_number_file' ORDER BY id`,(aErr,aResult)=>{
                        read.query(`SELECT CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_DOCUMENT_IMAGE}',name) AS name FROM tbl_user_document WHERE user_id = ${id} AND type IN ('certificate_image','certificate_pdf')`,(cErr,cResult)=>{
                            finalDocument['aadhar_number_file'] = aResult
                            finalDocument['certificate'] = cResult
                            resolve(finalDocument)
                        })
                    })
                }else{
                    resolve({})
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Bank List                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    bank_list: function() {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, name FROM tbl_bank WHERE is_active = '1' ORDER BY name`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Bank Details                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    bank_details : function(params, id)
    {
        return new Promise((resolve,reject) => {
            read.query(`SELECT id FROM tbl_user_bank_detail WHERE user_id = '${id}'`, (sErr,sResult) => {
                if(!sErr && sResult[0] != undefined) {
                    params.update_datetime = moment().format("X")
                    write.query(`UPDATE tbl_user_bank_detail SET ? WHERE user_id = '${id}'`, params, (uErr,uResult) => {
                        if(!uErr) {
                            resolve(3)
                        } else {
                            reject(0)
                        }
                    })
                } else {
                    params.insert_datetime = moment().format("X")
                    write.query(`INSERT INTO tbl_user_bank_detail SET ?`, params, (iErr,iResult) => {
                        if(!iErr) {
                            resolve(1)
                        } else {
                            reject(0)
                        }
                    })
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Get Bank Details                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_bank_details : function(id)
    {
        return new Promise((resolve,reject) => {
            read.query(`SELECT id, bank_name, account_number, holder_name, ifsc_code, CONCAT('${GLOBALS.S3_URL+GLOBALS.BANK_IMAGE}',passbook_image) AS passbook_image FROM tbl_user_bank_detail WHERE user_id = '${id}' AND is_active = '1' LIMIT 1`, (err,result) => {
                if(!err && result[0] != undefined) {
                    resolve(result[0])
                } else {
                    resolve({})
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                       Check User Register Flow Complete                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    check_user_register_complete : function(id)
    {
        return new Promise((resolve,reject) => {
            let is_complete = 'done'
            read.query(`SELECT id FROM tbl_user_bank_detail WHERE user_id = '${id}'`, (bErr,bResult) => {
                if(bResult[0] == undefined){
                    is_complete = 'bank'
                }
                read.query(`SELECT id FROM tbl_user_document WHERE user_id = '${id}'`, (dErr,dResult) => {
                    if(dResult[0] == undefined) {
                        is_complete = 'document'
                    }
                    read.query(`SELECT location FROM tbl_user WHERE id = '${id}'`, (oErr,oResult) => {
                        if(oResult[0].location == '') {
                            is_complete = 'other'
                        }
                        resolve(is_complete)
                    })
                })
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Get Sub Category                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_sub_category : function(id)
    {
        return new Promise((resolve,reject) => {
            let sub_category_id = (id) ? `WHERE id IN(${id})` : `WHERE id IN('')`
            read.query(`SELECT IFNULL(GROUP_CONCAT(name),'') AS sub_category FROM tbl_category ${sub_category_id} LIMIT 1`, (err,result) => {
                resolve((result[0] != undefined) ? result[0].sub_category : '')
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Get Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    user_details : function(params, callback)
    {
        if(params.user_id != undefined && params.user_id != "") {
            var where = `u.id = '${params.user_id}'`;
        } else {
            if(params.email != undefined && params.email != "") {
                var where = `u.email = '${params.email}'`;
            } else {
                var where = `(u.mobile_number = '${params.mobile_number}' AND u.country_code = '${params.country_code}')`;
            }
        }
        let sql = `SELECT u.id, u.parent_id, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, u.country_code, u.mobile_number, u.email, u.gender, u.referal_code, u.role, u.bio, u.total_experience, u.main_category, u.sub_category, IFNULL(c.name,'') AS main_category_name, u.location, u.latitude, u.longitude, u.gst, u.region_location, u.region_latitute, u.region_longitude, u.region_building, u.region_zipcode, u.region_raduis, u.verify_document, u.is_authorise, u.password FROM tbl_user AS u LEFT JOIN tbl_category AS c ON c.id = u.main_category WHERE u.is_active = '1' AND u.role IN ('provider','learner') AND ${where}`;
        read.query({sql:sql
            , typeCast: (field,next)=>{
                if(field.type == "BLOB"){
                    return field.string();
                }
                return next();
            }
        }, function(err, result) {
            if(!err && result[0] != undefined) {
                auth.get_sub_category(result[0].sub_category).then((resSubCategory)=>{
                    auth.check_user_register_complete(result[0].id).then((response)=>{
                        auth.get_document(result[0].id).then((resDocumentDetail)=>{
                            auth.get_bank_details(result[0].id).then((resBankDetail)=>{
                                auth.get_review_count(result[0].id).then((resReview)=>{
                                    result[0].sub_category_name = resSubCategory
                                    result[0].rating = resReview.rating
                                    result[0].review_count = resReview.review_count
                                    result[0].is_complete = response
                                    result[0].bank_details = resBankDetail
                                    resDocumentDetail.gst = result[0].gst
                                    result[0].document_details = resDocumentDetail
                                    callback("1", lang[params.language]['get_profile_data'], result[0])
                                })
                            })
                        })
                    })
                })
            }
            else {
                callback("2", lang[params.language]['get_no_profile_data'], null)
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Signin                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    signin : function(params, callback)
    {
        var star = `u.id, u.parent_id, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, u.country_code, u.mobile_number, u.email, u.gender, u.referal_code, u.role, u.bio, u.total_experience, u.main_category, u.sub_category, IFNULL(c.name,'') AS main_category_name, u.location, u.latitude, u.longitude, u.gst, u.region_location, u.region_latitute, u.region_longitude, u.region_building, u.region_zipcode, u.region_raduis, u.verify_document, u.is_authorise`;
        const cryptoLib = require('cryptlib');
        const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
        var sql = `SELECT ${star} FROM tbl_user AS u LEFT JOIN tbl_category AS c ON c.id = u.main_category WHERE (u.mobile_number = '${params.mobile_number}' AND u.country_code = '${params.country_code}') AND u.password = '${cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV)}' AND u.role IN ('provider','learner') AND u.is_active != '0'`;
        read.query({sql:sql
            , typeCast: (field,next)=>{
                if(field.type == "BLOB"){
                    return field.string();
                }
                return next();
            }
        }, function(err, result)
        {
            if(!err) {
                if(result[0] != undefined) {
                    if(result[0].is_active == "2"){
                        callback("3", lang[params.language]["text_user_login_inactive"], null)
                    } else {
                        auth.check_user_register_complete(result[0].id).then((resIsComplete) => {
                            // if(result[0].verify_document == "unverify" && result[0].role == "provider" && (resIsComplete == "done" || resIsComplete == "bank")){
                            //     callback("3", lang[params.language]["text_user_login_unverify"], null)
                            // } else {
                                auth.get_sub_category(result[0].sub_category).then((resSubCategory)=>{
                                    auth.get_document(result[0].id).then((resDocumentDetail)=>{
                                        auth.get_bank_details(result[0].id).then((resBankDetail)=>{
                                            auth.get_review_count(result[0].id).then((resReview)=>{
                                                // delete result[0].verify_document
                                                delete result[0].role
                                                result[0].sub_category_name = resSubCategory
                                                result[0].rating = resReview.rating
                                                result[0].review_count = resReview.review_count
                                                result[0].is_complete = resIsComplete
                                                result[0].bank_details = resBankDetail
                                                resDocumentDetail.gst = result[0].gst
                                                result[0].document_details = resDocumentDetail
                                                callback("1", lang[params.language]["signin_success"], result[0])
                                            })
                                        })
                                    })
                                })
                            // }
                        })
                    }
                } else {
                    callback("0", lang[params.language]["text_user_login_fail"], result[0])
				}
            }
            else {
                callback("0", lang[params.language]["text_sql_err"], null)
            }
        });
    },
    async get_review_count(id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT COUNT(e.id) AS review_count, IFNULL(ROUND(SUM(e.experience)/COUNT(e.id),1),0) AS rating FROM tbl_booking AS b JOIN tbl_booking_experience AS e ON e.booking_id = b.id WHERE provider_id = ${id}`,(rErr,rResult)=>{
                if(!rErr && rResult[0] != undefined){
                    resolve({review_count:rResult[0].review_count,rating:rResult[0].rating})
                }else{
                    resolve({review_count:0,rating:0})
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Edit Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    edit_check_unique : function(id, params, callback)
    {
        auth.edit_unique_fields('mobile_number', id, params.mobile_number, function(mobile_number) {
            if(mobile_number){
                if(params.email){
                    auth.edit_unique_fields('email', id, params.email, function(email) {
                        if(email){
                            callback(true);
                        }
                        else{
                            callback(false, params.email);
                        }
                    });
                }else{
                    callback(true);
                }
            }
            else{
                callback(false, params.mobile_number);
            }
        });
    },
    edit_unique_fields : function(field, id, params, callback)
    {
        if(params != '') {
            read.query(`SELECT id FROM tbl_user WHERE ${field} = "${params}" AND role = 'provider' AND is_active != "0"`, function(err, result) {
                if(result.length == 1 && result[0].id == id){
                    callback(true);
                }
                else if(result.length == 0){
                    callback(true);
                }
                else{
                    callback(false);
                }
            });
        } else {
            callback(true);
        }
    },
    edit_profile: function(user_id, params, language, callback) {
        write.query(`UPDATE tbl_user SET ? WHERE id = '${user_id}'`, params, function(err, result) {
            if (!err) {
                auth.user_details({"user_id": user_id,"language": language}, function(resCode, resMsg, resData) {
                    delete resData.password;
                    // delete resData.login_type;
                    callback('1', lang[language]['text_user_edit_profile_success'], resData);
                });
            } else {
                callback('0', lang[language]['text_user_edit_profile_fail'], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Home Status                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async home_status(params)
    {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT u.id, u.verify_document, u.document_reject_reason, u.region_raduis, IFNULL(a.id,'false') AS is_availability, IFNULL(cs.id,'false') AS is_service FROM tbl_user AS u LEFT JOIN tbl_availability AS a ON a.user_id = u.id LEFT JOIN tbl_category_service AS cs ON cs.user_id = u.id AND cs.type = 'filter' WHERE u.id = '${params.login_user_id}' LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    if(params.device_token){
                        write.query(`UPDATE tbl_user_device SET device_token = '${params.device_token}' WHERE user_id = '${params.login_user_id}'`);
                    }
                    auth.check_user_register_complete(result[0].id).then((resIsComplete)=>{
                        read.query(`SELECT IFNULL(id,'false') AS is_service_price FROM tbl_category_service WHERE user_id = ${params.login_user_id} AND type = 'charge' LIMIT 1`,(pErr,pResult)=>{
                            result[0].is_service_price = (pResult[0] == undefined || pResult[0].is_service == 'false') ? false : true
                            result[0].is_service = (result[0].is_service == 'false') ? false : true
                            result[0].is_availability = (result[0].is_availability == 'false') ? false : true
                            result[0].is_region = (result[0].region_raduis == 0) ? false : true
                            result[0].is_complete = resIsComplete
                            result[0].current_datetime = moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss")
                            delete result[0].region_raduis
                            resolve(result[0])
                        })
                    })
                }else{
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Add Staff                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_staff: function(params) {
        return new Promise((resolve,reject)=>{
            if(params.id){
                auth.edit_check_unique(params.id,params,function(response,val){
                    if(response){
                        let updateData = {
                            first_name: params.first_name,
                            last_name: params.last_name,
                            ...(params.gender) && {gender: params.gender},
                            country_code: params.country_code,
                            mobile_number: params.mobile_number,
                            update_datetime: moment().format("X")
                        };
                        if(params.password){
                            updateData.password = params.password;
                        }
                        if(params.profile_image){
                            updateData.profile_image = params.profile_image;
                        }
                        write.query(`UPDATE tbl_user SET ? WHERE id = ${params.id}`, updateData, function(err, result) {
                            if (!err) {
                                resolve({code:1,id:params.id})
                            } else {
                                reject({code:3})
                            }
                        })
                    }else{
                        reject({code:5,val:val});
                    }
                })
            }else{
                params.user_type = 'provider';
                common.check_unique(params,function(response,val,field){
                    if(response){
                        reject({code:5,val:val});
                    }else{
                        let insertData = {
                            parent_id: params.login_user_id,
                            first_name: params.first_name,
                            last_name: params.last_name,
                            ...(params.gender) && {gender: params.gender},
                            country_code: params.country_code,
                            mobile_number: params.mobile_number,
                            password: params.password,
                            role: "provider",
                            insert_datetime: moment().format("X")
                        };
                        if(params.profile_image){
                            insertData.profile_image = params.profile_image;
                        }
                        write.query(`INSERT INTO tbl_user SET ?`, insertData, function(err, result) {
                            if (!err) {
                                read.query(`SELECT current_language FROM tbl_user WHERE id = ${params.login_user_id} LIMIT 1`,(uErr,uResult)=>{
                                    var push_data = {
                                        title: lang[uResult[0].current_language]['text_staff_add_title'],
                                        body: lang[uResult[0].current_language]['text_staff_add_body'].replace('{name}',params.first_name+' '+params.last_name).replace('{staff_id}',result.insertId),
                                        custom: {
                                            tag: "staff_added",
                                            staff_id: result.insertId
                                        }
                                    }
                                    var push_notification = {
                                        sender_id: params.login_user_id,
                                        receiver_id: params.login_user_id,
                                        action_id: result.insertId,
                                        message: JSON.stringify({title:'text_staff_add_title',body:'text_staff_add_body'}),
                                        tag: 'staff_added',
                                        insert_datetime: moment().format("X")
                                    }
                                    common.prepare_notification(params.login_user_id,push_data)
                                    common.add_data('tbl_notification',push_notification,(res)=>{})
                                    resolve({code:1,id:result.insertId})
                                })
                            } else {
                                reject({code:0})
                            }
                        })
                    }
                })
            }
        })
    },
    add_service: function(params) {
        return new Promise((resolve,reject)=>{
            let finalInsert = []
            write.query(`DELETE FROM tbl_category_service WHERE user_id = ${params.user_id}`,(dErr,dResult)=>{
                asyncLoop(params.sub_category_id.split(','),(item,next)=>{
                    finalInsert.push([item,params.user_id,'filter',moment().format("X")])
                    next();
                },()=>{
                    write.query(`INSERT INTO tbl_category_service(sub_category_id,user_id,type,insert_datetime) VALUES ?`, [finalInsert], function(err, result) {
                        if (!err) {
                            resolve(1);
                        } else {
                            reject(0);
                        }
                    })
                })
            });
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Staff List                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    staff_list: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',profile_image) AS profile_image, first_name, last_name, gender FROM tbl_user WHERE is_active = '1' AND parent_id = ${params.login_user_id} ORDER BY insert_datetime DESC LIMIT ${parseInt(params.page_token)*parseInt(GLOBALS.PER_PAGE)},${GLOBALS.PER_PAGE}`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject(null)
                }
            })
        })
    },
}
module.exports = auth;