const { read,write } = require('../../../config/database');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const moment_timezone = require('moment-timezone');
const lang = require('../../../config/language');
const asyncLoop = require('node-async-loop');
const common = require('../../../config/common');

const home = {

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Home Status                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async home_status(params)
    {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT COUNT(id) AS cart_total FROM tbl_cart WHERE user_id = '${params.login_user_id}'`,(err,result)=>{
                read.query(`SELECT GROUP_CONCAT(booking_id) AS booking_id FROM tbl_booking_experience WHERE user_id = ${params.login_user_id} LIMIT 1`,(eErr,eResult)=>{
                    var where = (!eErr && eResult[0] != undefined && eResult[0].booking_id != null) ? ` AND id NOT IN (${eResult[0].booking_id})` : ``
                    read.query(`SELECT id, order_id, date, time FROM tbl_booking WHERE user_id = ${params.login_user_id} AND status = 'completed' ${where}`,(bErr,bResult)=>{
                        if(!err && result[0] != undefined){
                            if(params.device_token){
                                write.query(`UPDATE tbl_user_device SET device_token = '${params.device_token}' WHERE user_id = '${params.login_user_id}'`);
                            }
                            result[0].booking_id = (!bErr && bResult[0] != undefined) ? bResult[0].id : 0
                            result[0].order_id = (!bErr && bResult[0] != undefined) ? bResult[0].order_id : 0
                            result[0].current_datetime = moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss")
                            if(result[0].booking_id != 0){
                                home.my_service_details({login_user_id:params.login_user_id,id:result[0].booking_id}).then((response)=>{
                                    result[0].booking_details = response
                                    resolve(result[0])
                                }).catch((err)=>{
                                    resolve(result[0])
                                })
                            }else{
                                resolve(result[0])
                            }
                        }else{
                            reject()
                        }
                    })
                })
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Category List                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    category_list : function(params)
    {
        return new Promise((resolve,reject)=>{
            let where = (params.parent_id) ? `AND parent_id = '${params.parent_id}'` : `AND parent_id = '0'`
            if(params.search){
                where += ` AND name LIKE '%${params.search}%'`;
            }
            read.query(`SELECT id, CONCAT('${GLOBALS.S3_URL+GLOBALS.CATEGORY_IMAGE}',image) AS image, CONCAT('${GLOBALS.S3_URL+GLOBALS.CATEGORY_IMAGE}',outer_image) AS outer_image, name FROM tbl_category WHERE is_active = '1' ${where} ORDER BY id DESC`, function(err, result) {
                // LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}
                if(!err && result[0] != undefined) {
                    resolve(result)
                    // page_token:parseInt(params.page_token)+1
                }
                else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Notification List                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    notification_list : function(params)
    {
        let type = (params.type == "order_related") ? `AND tag != 'admin_notification'` : `AND tag = 'admin_notification'`
        return new Promise((resolve,reject)=>{
            read.query({sql:`SELECT n.id, n.action_id, n.tag, n.message, n.is_read, n.insert_datetime, u.current_language FROM tbl_notification AS n JOIN tbl_user AS u ON u.id = n.receiver_id WHERE n.is_active = '1' AND n.receiver_id = '${params.login_user_id}' ${type} ORDER BY n.id DESC LIMIT ${parseInt(params.page_token) * parseInt(GLOBALS.NOTIFICATION_PER_PAGE)},${GLOBALS.NOTIFICATION_PER_PAGE}`,
                typeCast: (field, next) => {
                    if (field.type == 'BLOB') {
                        return field.string()
                    }
                    return next()
                }
            }, function(err, result) {
                if(!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        try{
                            item.message = JSON.parse(item.message)
                        }catch(e){
                            item.message = item.message
                        }
                        if(item.tag == "admin_notification"){
                            item.title = item.message.title
                            item.body = item.message.body
                            delete item.current_language
                            delete item.message
                            next()
                        }else{
                            if(["booking_rejected","booking_accepted","booking_cancelled","booking_started","booking_ended","booking_additional_cost_added"].indexOf(item.tag) !== -1){
                                read.query(`SELECT b.order_id, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE b.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title].replace('{order_id}',bResult[0].order_id).replace('{sp_name}',bResult[0].sp_name)
                                    item.body = lang[item.current_language][item.message.body].replace('{order_id}',bResult[0].order_id)
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else{
                                item.title = lang[item.current_language][item.message.title]
                                item.body = lang[item.current_language][item.message.body]
                                delete item.current_language
                                delete item.message
                                next()
                            }
                        }
                    },()=>{
                        resolve({"page_token":parseInt(params.page_token)+1,"result":result})
                    })
                }
                else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Clear Notification                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    clear_notification : function(id)
    {
        return new Promise((resolve,reject)=>{
            write.query(`UPDATE tbl_notification SET ? WHERE receiver_id = '${id}'`, {is_active:'0'}, function(err, result) {
                if(!err && result != undefined) {
                    resolve(result)
                }
                else {
                    reject(null)
                }
            });
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Add Address                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_address: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`UPDATE tbl_user_address SET is_default = 0 WHERE user_id = ${params.login_user_id}`,(uErr,uResult)=>{
                let insertData = {
                    user_id: params.login_user_id,
                    location: params.location,
                    latitude: params.latitude,
                    longitude: params.longitude,
                    ...(params.flat_number) && { pincode: params.flat_number },
                    ...(params.pincode) && { pincode: params.pincode },
                    insert_datetime: moment().format("X")
                };
                write.query(`INSERT INTO tbl_user_address SET ?`, insertData, function(err, result) {
                    if (!err) {
                        resolve(result)
                    } else {
                        reject(null)
                    }
                })
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Edit Address                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    edit_address: function(params) {
        return new Promise((resolve,reject)=>{
            let updateData = {
                location: params.location,
                latitude: params.latitude,
                longitude: params.longitude,
                ...(params.flat_number) && { pincode: params.flat_number },
                ...(params.pincode) && { pincode: params.pincode },
                update_datetime: moment().format("X")
            };
            write.query(`UPDATE tbl_user_address SET ? WHERE id = ?`, [updateData, params.id], function(err, result) {
                if (!err) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Get Address List                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    address_list: function(user_id) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, location, longitude, latitude, flat_number, pincode, is_default FROM tbl_user_address WHERE user_id = "${user_id}" AND is_active = '1' ORDER BY insert_datetime DESC`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Set Default Address                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    set_default_address: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`UPDATE tbl_user_address SET is_default = 0 WHERE user_id = ${params.login_user_id}`,(uErr,uResult)=>{
                let updateData = {
                    is_default: 1,
                    update_datetime: moment().format("X")
                };
                write.query(`UPDATE tbl_user_address SET ? WHERE id = ?`, [updateData, params.id], function(err, result) {
                    if (!err) {
                        resolve(result)
                    } else {
                        reject(null)
                    }
                })
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Get Default Address                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_default_address: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT * FROM tbl_user_address WHERE user_id = ${params.login_user_id} AND is_default = '1' LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve(result[0])
                }else{
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Delete Address                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    delete_address: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`DELETE FROM tbl_user_address WHERE id = '${params.id}' AND user_id = '${params.login_user_id}'`, function(err, result) {
                if (!err && result != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                   Add Card                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_card: function(params) {
        return new Promise((resolve,reject)=>{
            let insertData = {
                user_id: params.login_user_id,
                name_on_card: params.name_on_card,
                card_number: params.card_number,
                expiry_date: params.expiry_date,
                expiry_month: params.expiry_month,
                cvv: params.cvv,
                insert_datetime: moment().format("X")
            };
            write.query(`INSERT INTO tbl_user_card_detail SET ?`, insertData, function(err, result) {
                if (!err) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Delete Card                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    delete_card: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`DELETE FROM tbl_user_card_detail WHERE id = '${params.id}' AND user_id = '${params.login_user_id}'`, function(err, result) {
                if (!err && result != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Get Card List                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    card_list: function(user_id) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, name_on_card, card_number, expiry_date, expiry_month FROM tbl_user_card_detail WHERE user_id = "${user_id}" ORDER BY insert_datetime DESC`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Service Provider List                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    service_provider_list: function(params) {
        return new Promise((resolve,reject)=>{
            var where = (params.filter_id) ? `AND cs.service_name IN (${params.filter_id}) AND cs.type IN ('filter','charge')` : `AND cs.type = 'charge'`;
            var order_by = ``
            if(params.order_by_price == 'ASC'){
                order_by = `MIN(cs.price) ASC`;
            }
            if(params.order_by_price == 'DESC'){
                order_by = `MIN(cs.price) DESC`
            }
            order_by += (params.newest_first) ? `${(order_by != '')?`,`:``}cs.user_id DESC` : ``
            if(params.near_to_fear == true){
                if(order_by != ''){
                    order_by += `,distance`;
                }else{
                    order_by = `distance`;
                }
            }
            if(params.near_to_fear == false){
                if(order_by != ''){
                    order_by += `,distance DESC`;
                }else{
                    order_by = `distance DESC`;
                }
            }
            if(params.rating_low_to_high){
                if(order_by != ''){
                    order_by += `,rating`;
                }else{
                    order_by = `rating`;
                }
            }
            if(params.rating_high_to_low){
                if(order_by != ''){
                    order_by += `,rating DESC`;
                }else{
                    order_by = `rating DESC`;
                }
            }
            if(params.discount){
                if(order_by != ''){
                    order_by += `,total_offer DESC`
                }else{
                    order_by = `total_offer DESC`
                }
            }
            if(params.popularity){
                if(order_by != ''){
                    order_by += `,total_completed DESC`
                }else{
                    order_by = `total_completed DESC`
                }
            }
            if(order_by != ``){
                order_by = `ORDER BY `+order_by
            }
            read.query({sql:`SELECT u.id,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image,u.first_name,u.last_name,u.location,u.latitude,u.longitude,u.is_authorise,u.main_category AS main_category_id,c.name AS main_category_name,cs.sub_category_id,u.bio,u.region_raduis, ROUND((6371 * acos( cos( radians(${params.latitude}) ) * cos( radians( u.region_latitute ) ) * cos( radians( u.region_longitude ) - radians(${params.longitude}) ) + sin( radians(${params.latitude}) ) * sin( radians( u.region_latitute ) ) ) ), 2) AS distance,COUNT(e.id) AS review_count,IFNULL(ROUND(SUM(e.experience)/COUNT(e.id),1),0) AS rating, (SELECT COUNT(id) FROM tbl_offer WHERE user_id = u.id AND category_id = cs.sub_category_id AND start_date <= CURRENT_DATE() AND end_date >= CURRENT_DATE()) AS total_offer, (SELECT COUNT(id) FROM tbl_booking WHERE provider_id = u.id AND status = 'completed') AS total_completed FROM tbl_category_service AS cs JOIN tbl_user AS u ON u.id = cs.user_id JOIN tbl_user_bank_detail AS b ON b.user_id = u.id JOIN tbl_category AS c ON c.id = u.main_category LEFT JOIN tbl_booking AS bo ON bo.provider_id = u.id LEFT JOIN tbl_booking_experience AS e ON e.booking_id = bo.id WHERE cs.sub_category_id = '${params.sub_category_id}' AND cs.is_active = '1' AND u.is_active = '1' AND u.verify_document = 'verify' AND u.region_raduis != 0 ${where} GROUP BY cs.user_id HAVING distance <= u.region_raduis ${order_by} LIMIT ${parseInt(params.page_token)*parseInt(GLOBALS.PER_PAGE)},${GLOBALS.PER_PAGE}`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string()
                    }
                    return next()
                }
            }, function(err, result) {
                if (!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        home.get_provider_lower_service(item).then((response)=>{
                            home.get_provider_service(item).then((resServices)=>{
                                home.get_service_provider_fav_unfav(params.login_user_id,item.id).then((resFavUnfav)=>{
                                    home.get_review_count(item.id).then((resReview)=>{
                                        item.price = (response) ? response.price : ``
                                        item.service_name = (response) ? response.service_name : ``
                                        item.services = resServices
                                        item.is_favorite = resFavUnfav
                                        // item.rating = resReview.rating
                                        item.review_count = resReview.review_count
                                        next()
                                    })
                                })
                            })
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result})
                    })
                } else {
                    reject(null)
                }
            })
        })
    },
    get_service_provider_fav_unfav: function(login_user_id, provider_id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT type FROM tbl_user_favorite_unfavorite WHERE user_id = ${login_user_id} AND provider_id = ${provider_id}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve((result[0].type == "Favorite") ? true : false)
                }else{
                    resolve(false)
                }
            })
        })
    },
    async get_review_count(id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT COUNT(e.id) AS review_count, IFNULL(ROUND(SUM(e.experience)/COUNT(e.id),1),0) AS rating FROM tbl_booking AS b JOIN tbl_booking_experience AS e ON e.booking_id = b.id WHERE b.provider_id = ${id}`,(rErr,rResult)=>{
                if(!rErr && rResult[0] != undefined){
                    resolve({review_count:rResult[0].review_count,rating:rResult[0].rating})
                }else{
                    resolve({review_count:0,rating:0})
                }
            })
        })
    },
    
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Get Availability Time Slot                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_available_time_slot: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, type, TIME_FORMAT(start_time,'%H:%i') AS start_time, insert_datetime FROM tbl_availability WHERE type IN ('AD','BD') AND user_id IN (${params.login_user_id}) AND start_date <= '${params.date}' AND end_date >= '${params.date}' ORDER BY id DESC LIMIT 1`,(err, result)=>{
                if (!err && result[0] != undefined) {
                    read.query(`SELECT TIME_FORMAT(time,'%H:%i') AS time FROM tbl_booking WHERE provider_id IN (${params.login_user_id}) AND date = '${params.date}' AND status IN ('accepted')`,(bErr,bResult)=>{
                        bResult = (bResult[0] != undefined) ? bResult.map(x=>x.time) : []
                        let alltimesolt = []
                        let dType = result[0].type
                        let timesolt = common.get_all_time_slot();
                        asyncLoop(timesolt,(item,next)=>{
                            let type = (result[0].type == "AD") ? `A` : `U`
                            read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND insert_datetime >= '${result[0].insert_datetime}' AND user_id IN (${params.login_user_id}) AND start_date <= '${params.date}' AND end_date >= '${params.date}' AND start_time <= '${item}' AND end_time >= '${item}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                                if(!cErr && cResult[0] != undefined){
                                    if(cResult[0].type == "A"){
                                        type = 'A'
                                        type = (bResult.includes(item)) ? 'B' : type
                                        alltimesolt.push({time:item,type:type})
                                        next()
                                    }else{
                                        next()
                                    }
                                }else{
                                    if(type == "A"){
                                        type = 'A'
                                        type = (bResult.includes(item)) ? 'B' : type
                                        alltimesolt.push({time:item,type:type})
                                        next()
                                    }else{
                                        next()
                                    }
                                }
                            })
                        },()=>{
                            resolve({timesolt:alltimesolt,type:dType})
                        })
                    })
                } else {
                    let alltimesolt = []
                    let aType = 'U'
                    let timesolt = common.get_all_time_slot();
                    read.query(`SELECT TIME_FORMAT(time,'%H:%i') AS time FROM tbl_booking WHERE provider_id IN (${params.login_user_id}) AND date = '${params.date}' AND status IN ('accepted')`,(bErr,bResult)=>{
                        bResult = (bResult[0] != undefined) ? bResult.map(x=>x.time) : []
                        asyncLoop(timesolt,(item,next)=>{
                            var type = 'U'
                            read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND user_id IN (${params.login_user_id}) AND start_date <= '${params.date}' AND end_date >= '${params.date}' AND start_time <= '${item}' AND end_time >= '${item}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                                if(!cErr && cResult[0] != undefined && cResult[0].type == "A"){
                                    aType = 'A'
                                    type = 'A'
                                    type = (bResult.includes(item)) ? 'B' : type
                                    alltimesolt.push({time:item,type:type})
                                    next()
                                }else{
                                    next()
                                }
                            })
                        },()=>{
                            resolve({timesolt:alltimesolt,type:aType})
                        })
                    })
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Get Availability Month Slot                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async get_available_month_slot(params) {
        return new Promise((resolve,reject)=>{
            var array = common.get_all_month_date_slot(params.start_date,params.end_date);
            var slotArray = []
            asyncLoop(array,(item,next)=>{
                home.get_available_time_slot({login_user_id:params.ids,date:item}).then((resTimeSlot)=>{
                    if(resTimeSlot.timesolt != ''){
                        slotArray.push({
                            date: item,
                            type: resTimeSlot.type,
                            time: resTimeSlot.timesolt
                        })
                        next()
                    }else{
                        next()
                    }
                })
            },()=>{
                if(slotArray.length != 0){
                    resolve(slotArray)
                }else{
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Filter List                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    filter_list : function(params)
    {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT f.id, f.name, f.is_multiple_customer FROM tbl_category AS c JOIN tbl_filter AS f ON f.id = c.filter_id WHERE c.parent_id = '${params.category_id}' AND c.is_active = '1' GROUP BY c.filter_id`, function(err, result) {
                if(!err && result[0] != undefined) {
                    asyncLoop(result, (item,next) => {
                        read.query(`SELECT c.id, c.name FROM tbl_category AS c WHERE c.parent_id = '${params.category_id}' AND c.filter_id = '${item.id}' AND c.is_active = '1'`, (cErr,cResult) => {
                            item.is_multiple_customer = (item.is_multiple_customer == 'yes') ? true : false
                            item.list = cResult
                            next()
                        })
                    },()=>{
                        resolve(result)
                    })
                }
                else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Get Provider Lower Service                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_provider_lower_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT price,service_name FROM tbl_category_service WHERE user_id = '${params.id}' AND sub_category_id = '${params.sub_category_id}' AND type = 'charge' AND is_active = '1' ORDER BY price LIMIT 1`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve(result[0])
                } else {
                    resolve(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Get Provider Service                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_provider_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id,price,service_name FROM tbl_category_service WHERE user_id = '${params.id}' AND sub_category_id = '${params.sub_category_id}' AND type = 'charge' AND is_check = 'true' AND is_active = '1' ORDER BY price`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve(result)
                } else {
                    resolve([])
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Service Provider Details                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    service_provider_details: function(params) {
        return new Promise((resolve,reject)=>{
            read.query({sql:`SELECT u.id,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image,u.first_name,u.last_name,u.location,u.latitude,u.longitude,u.is_authorise,u.total_experience,u.bio,c.name AS main_category_name FROM tbl_user AS u JOIN tbl_category AS c ON c.id = u.main_category WHERE u.id = '${params.id}' AND u.is_active = '1' LIMIT 1`,
                typeCast: (field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string()
                    }
                    return next()
                }
            }, function(err, result) {
                if (!err && result[0] != undefined) {
                    home.get_provider_lower_service(params).then((response)=>{
                        home.get_provider_document(params).then((resDocument)=>{
                            home.get_all_provider_services(params.id).then((resServices)=>{
                                home.get_additional_cost(result[0].id).then((resAdditionalCost)=>{
                                    home.get_service_provider_fav_unfav(params.login_user_id,params.id).then((resFavUnfav)=>{
                                        home.get_review_count(result[0].id).then((resReview)=>{
                                            result[0].price = (response) ? response.price : ``
                                            result[0].service_name = (response) ? response.service_name : ``
                                            result[0].is_favorite = resFavUnfav
                                            result[0].additional_cost = resAdditionalCost
                                            result[0].services = resServices
                                            result[0].rating = resReview.rating
                                            result[0].review_count = resReview.review_count
                                            result[0].certificate = resDocument
                                            resolve(result[0])
                                        })
                                    })
                                })
                            })
                        })
                    })
                } else {
                    reject(false)
                }
            })
        })
    },
    async get_additional_cost(booking_id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT additional_id,status,payment_mode,payment_status FROM tbl_booking_additional_cost WHERE booking_id = '${booking_id}' AND status != 'reject' GROUP BY additional_id`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        read.query(`SELECT id,name,value FROM tbl_booking_additional_cost WHERE status != 'reject' AND booking_id = '${booking_id}' AND additional_id = '${item.additional_id}'`,(cErr,cResult)=>{
                            home.get_additional_cost_images(booking_id,item.additional_id).then((resAdditionalCostImages)=>{
                                item.costs = cResult
                                item.images = resAdditionalCostImages
                                next()
                            })
                        })
                    },()=>{
                        resolve(result)
                    })
                }else{
                    resolve([])
                }
            })
        })
    },
    async get_additional_cost_images(booking_id,additional_id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT CONCAT('${GLOBALS.S3_URL+GLOBALS.COST_IMAGE}',image) AS image FROM tbl_booking_additional_cost_images WHERE booking_id = '${booking_id}' AND additional_id = '${additional_id}'`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve(result)
                }else{
                    resolve([])
                }
            })
        })
    },
    async get_all_provider_services(id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT c.id, c.name FROM tbl_category_service AS cs JOIN tbl_category AS s ON s.id = cs.sub_category_id JOIN tbl_category AS c ON c.id = s.parent_id WHERE cs.user_id = ${id} AND cs.is_check = 'true' AND cs.type = 'charge' GROUP BY c.id`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        read.query(`SELECT c.id, c.name FROM tbl_category AS c JOIN tbl_category_service AS cs ON cs.sub_category_id = c.id WHERE c.parent_id = ${item.id} AND cs.user_id = ${id} GROUP BY c.id`,(sErr,sResult)=>{
                            item.services = sResult
                            next()
                        })
                    },()=>{
                        resolve(result)
                    })
                }else{
                    resolve([])
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Get Provider Document                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_provider_document: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_DOCUMENT_IMAGE}',name) AS certificate_image FROM tbl_user_document WHERE user_id = '${params.id}' AND type = 'certificate_image'`, function(err, result) {
                if (!err && result[0] != undefined) {
                    resolve(result)
                } else {
                    resolve([])
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Add To Cart                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_to_cart: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`INSERT INTO tbl_cart SET ?`, params, (err, result) => {
                if (!err) {
                    resolve(result)
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Add To Cart List                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_to_cart_list: function(params) {
        return new Promise((resolve,reject)=>{
            let where = (params.id) ? ` AND c.id = ${params.id}` : ``
            // LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}
            read.query({sql:`SELECT c.id, c.user_id, c.provider_id, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, c.service_ids, c.date, c.time, c.type, c.address, c.description FROM tbl_cart AS c JOIN tbl_user AS u ON u.id = c.provider_id WHERE c.is_active = '1' AND c.user_id = ${params.login_user_id} ${where} ORDER BY c.id DESC`,
            typeCast: (field,next) => {
                if(field.type == "BLOB"){
                    return field.string()
                }
                return next()
            }
        }, (err, result) => {
                if (!err && result[0] != undefined) {
                    let total = 0
                    asyncLoop(result,(item,next)=>{
                        item.address = (item.address) ? JSON.parse(item.address) : {}
                        home.get_cart_service(item.service_ids).then((resService)=>{
                            let sub_total = 0
                            resService.result.map(function(element){
                                sub_total += element.price
                                total += element.price
                            })
                            item.main_category = (resService.main) ? resService.main.id : ``
                            item.main_category_name = (resService.main) ? resService.main.name : ``
                            item.sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                            item.sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                            item.services = resService.result
                            item.sub_total = sub_total
                            item.discount = 0
                            item.total = sub_total
                            next()
                        })
                    },()=>{
                        // page_token:parseInt(params.page_token)+1,
                        resolve({result:result,total:total,discount:0})
                    })
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Get Cart Service                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_cart_service: function(service_ids) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT cs.id, cs.sub_category_id, c.name AS sub_category_name, cs.service_name, cs.price FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id WHERE cs.id IN (${service_ids})`, (err, result) => {
                if (!err) {
                    read.query(`SELECT s.id, s.name FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id JOIN tbl_category AS s ON s.id = c.parent_id WHERE cs.id IN (${service_ids}) LIMIT 1`, (mErr, mResult) => {
                        resolve({result:result,main:mResult[0]})
                    })
                } else {
                    resolve(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Delete Cart Service                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    delete_cart_service: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`DELETE FROM tbl_cart WHERE id = ${params.id} AND user_id = ${params.login_user_id}`, (err, result) => {
                if (!err && result.affectedRows != 0) {
                    resolve(result)
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Available Offer                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_available_offer: function(params) {
        return new Promise((resolve,reject)=>{
            let sub_category_id = (params.sub_category_id) ? `,${params.sub_category_id}` : ``
            read.query(`SELECT id, added_by, user_id, title, start_date, end_date, discount, description, CONCAT('${GLOBALS.S3_URL+GLOBALS.OFFER_IMAGE}',image) AS image FROM tbl_offer WHERE is_active = '1' AND start_date <= CURRENT_DATE() AND end_date >= CURRENT_DATE() AND ((category_id IN (0,${params.category_id}${sub_category_id}) AND added_by = 'admin') OR (category_id IN (${params.sub_category_id}) AND user_id IN (${params.provider_id}))) ORDER BY id DESC LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`, (err, result) => {
                if (!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Verify Offer                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    verify_promocode: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, added_by, category_id, user_id, title, start_date, end_date, discount, description, type FROM tbl_offer WHERE title = '${params.promocode}' AND is_active = '1' AND start_date <= CURRENT_DATE() AND end_date >= CURRENT_DATE() LIMIT 1`, (err, result) => {
                if (!err && result[0] != undefined) {
                    var final_total = 0
                    var discount = 0
                    asyncLoop(params.services,(item,next)=>{
                        if(result[0].added_by == "admin"){
                            if(result[0].category_id == 0){
                                // console.log("ADMIN GLOBAL OFFER")
                                if(result[0].type == "percentage"){
                                    item.discount = ((item.sub_total * result[0].discount) / 100).toFixed(2)
                                    discount += parseFloat(item.discount)
                                    item.total = (item.sub_total - item.discount)
                                    final_total += item.total
                                }
                                next()
                            }
                            else if(result[0].category_id == item.main_category){
                                // console.log("ADMIN MAIN OFFER")
                                if(result[0].type == "percentage"){
                                    item.discount = ((item.sub_total * result[0].discount) / 100).toFixed(2)
                                    discount += parseFloat(item.discount)
                                    item.total = (item.sub_total - item.discount)
                                    final_total += item.total
                                }
                                next()
                            }
                            else if(result[0].category_id == item.sub_category_id){
                                // console.log("ADMIN SUB OFFER")
                                if(result[0].type == "percentage"){
                                    item.discount = ((item.sub_total * result[0].discount) / 100).toFixed(2)
                                    discount += parseFloat(item.discount)
                                    item.total = (item.sub_total - item.discount)
                                    final_total += item.total
                                }
                                next()
                            }
                            else{
                                final_total += item.total
                                next()
                            }
                        }
                        else if(result[0].added_by == "provider" && result[0].user_id == item.provider_id && result[0].category_id == item.sub_category_id){
                            // console.log("PROVIDER OFFER")
                            if(result[0].type == "percentage"){
                                item.discount = ((item.sub_total * result[0].discount) / 100).toFixed(2)
                                discount += parseFloat(item.discount)
                                item.total = (item.sub_total - item.discount)
                                final_total += item.total
                            }
                            next()
                        }
                        else{
                            final_total += item.total
                            next()
                        }
                    },()=>{
                        discount = parseFloat(discount)
                        final_total = parseFloat(final_total)
                        resolve({promocode:result[0],services:params.services,discount:discount.toFixed(2),total:final_total.toFixed(2)})
                    })
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Check Provider Available                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    check_provider_available: function(params) {
        return new Promise((resolve,reject)=>{
            let provider_names = ''
            asyncLoop(params.services,(item,next)=>{
                common.get_provider_ids(item.provider_id,item.sub_category_id).then((resIds)=>{
                    let is_available = false;
                    asyncLoop(resIds.ids.split(','),(item1,next1)=>{
                        read.query(`SELECT id, type, insert_datetime FROM tbl_availability WHERE type IN ('AD','BD') AND user_id = ${item1} AND start_date <= '${item.date}' AND end_date >= '${item.date}' ORDER BY id DESC LIMIT 1`,(err, result)=>{
                            if(!err && result[0] != undefined){
                                read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND insert_datetime >= '${result[0].insert_datetime}' AND user_id = ${item1} AND start_date <= '${item.date}' AND end_date >= '${item.date}' AND start_time <= '${item.time}' AND end_time >= '${item.time}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                                    if(!cErr && cResult[0] != undefined){
                                        if(cResult[0].type == "A"){
                                            if(!is_available){ is_available = true; }
                                            next1()
                                        }else{
                                            next1()
                                        }
                                    }else{
                                        if(result[0].type == 'AD'){
                                            if(!is_available){ is_available = true; }
                                            next1()
                                        }else{
                                            next1()
                                        }
                                    }
                                })
                            }else{
                                read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND user_id = ${item1} AND start_date <= '${item.date}' AND end_date >= '${item.date}' AND start_time <= '${item.time}' AND end_time >= '${item.time}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                                    if(!cErr && cResult[0] != undefined && cResult[0].type == "A"){
                                        if(!is_available){ is_available = true; }
                                        next1()
                                    }else{
                                        next1()
                                    }
                                })
                            }
                        })
                    },()=>{
                        if(is_available){
                            next()
                        }else{
                            read.query(`SELECT first_name, last_name FROM tbl_user WHERE id = ${item.provider_id}`,(uErr,uResult)=>{
                                provider_names += `${uResult[0].first_name} ${uResult[0].last_name} (${item.sub_category_name}),`
                                next()
                            })
                        }
                    })
                })
            },()=>{
                if(provider_names){
                    reject(provider_names.slice(0,-1))
                }else{
                    resolve()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Book Service                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    book_service: function(params) {
        return new Promise((resolve,reject)=>{
            var insertData = {
                user_id: params.login_user_id,
                payment_type: params.payment_type,
                transaction_id: params.transaction_id,
                payment_status: params.payment_status,
                ...(params.card_id) && {card_id: params.card_id},
                insert_datetime: moment().format('X')
            }
            asyncLoop(params.services,(item,next)=>{
                home.assign_booking(item.provider_id,item.sub_category_id,item.date,item.time).then((resAssignId)=>{
                    insertData.order_id = common.stringGen(12)
                    insertData.provider_id = resAssignId
                    insertData.date = item.date
                    insertData.time = item.time
                    insertData.type = item.type
                    insertData.service_ids = item.services.map(element => element.id)
                    insertData.service_ids = insertData.service_ids.join(',')
                    if(item.address){
                        insertData.address = JSON.stringify(item.address)
                    }
                    insertData.description = item.description
                    insertData.total_amount = item.sub_total
                    insertData.discount_amount = item.discount
                    insertData.start_service_otp = Math.floor(1000 + Math.random() * 9000)
                    insertData.end_service_otp = Math.floor(1000 + Math.random() * 9000)
                    insertData.final_amount = item.total
                    write.query(`INSERT INTO tbl_booking SET ?`, insertData, (err,result)=>{
                        write.query(`DELETE FROM tbl_cart WHERE id = ${item.id}`)
                        read.query(`SELECT current_language, CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE id = ${resAssignId} LIMIT 1`,(uErr,uResult)=>{
                            var push_data = {
                                title: lang[uResult[0].current_language]['text_place_booking_title'].replace('{sp_name}',uResult[0].sp_name),
                                body: lang[uResult[0].current_language]['text_place_booking_body'].replace('{order_id}',insertData.order_id),
                                custom: {
                                    tag: "place_booking",
                                    order_id: insertData.order_id,
                                    booking_id: result.insertId
                                }
                            }
                            var push_notification = {
                                sender_id: params.login_user_id,
                                receiver_id: resAssignId,
                                action_id: result.insertId,
                                message: JSON.stringify({title:'text_place_booking_title',body:'text_place_booking_body'}),
                                tag: 'place_booking',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(resAssignId,push_data)
                            common.add_data('tbl_notification',push_notification,(res)=>{})
                            next()
                        })
                    })
                }).catch((error)=>{
                    next()
                })
            },()=>{
                resolve()
            })
        })
    },
    async assign_booking(provider_id, sub_category_id, date, time){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT GROUP_CONCAT(id) AS ids FROM tbl_user WHERE id = ${provider_id} OR parent_id = ${provider_id} LIMIT 1`,(err,result)=>{
                read.query(`SELECT user_id FROM tbl_category_service WHERE user_id IN (${result[0].ids}) AND sub_category_id = ${sub_category_id} GROUP BY user_id`,(aErr,aResult)=>{
                    if(!aErr && aResult[0] != undefined){
                        let avaialble_provider = [];
                        asyncLoop(aResult,(item,next)=>{
                            home.check_available_provider(item.user_id,date,time).then((resBool)=>{
                                if(resBool){
                                    avaialble_provider.push(item.user_id)
                                    next()
                                }else{
                                    next()
                                }
                            }).catch((error)=>{
                                next()
                            })
                        },()=>{
                            if(avaialble_provider != ''){
                                resolve(avaialble_provider[Math.floor(Math.random() * avaialble_provider.length)]);
                            }else{
                                resolve(provider_id)
                            }
                        })
                    }else{
                        resolve(provider_id)
                    }
                })
            })
        })
    },
    async check_available_provider(id,date,time){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, type, TIME_FORMAT(start_time,'%H:%i') AS start_time, insert_datetime FROM tbl_availability WHERE type IN ('AD','BD') AND user_id = ${id} AND start_date <= '${date}' AND end_date >= '${date}' ORDER BY id DESC LIMIT 1`,(err, result)=>{
                if (!err && result[0] != undefined) {
                    let type = (result[0].type == "AD") ? `A` : `U`
                    read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND insert_datetime >= '${result[0].insert_datetime}' AND user_id = ${id} AND start_date <= '${date}' AND end_date >= '${date}' AND start_time <= '${time}' AND end_time >= '${time}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                        if(!cErr && cResult[0] != undefined){
                            resolve((cResult[0].type == "A") ? true : false)
                        }else{
                            resolve((type == "A") ? true : false)
                        }
                    })
                } else {
                    read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND user_id = ${id} AND start_date <= '${date}' AND end_date >= '${date}' AND start_time <= '${time}' AND end_time >= '${time}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                        resolve((!cErr && cResult[0] != undefined && cResult[0].type == "A") ? true : false)
                    })
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                My Service                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    my_service: function(params) {
        return new Promise((resolve,reject)=>{
            let where = ``
            let order_by = `ORDER BY b.insert_datetime DESC, b.date, b.time`
            if(params.status == "today"){
                where = `AND date = CURRENT_DATE() AND status NOT IN ('completed','cancelled')`
            }else if(params.status == "upcoming"){
                where = `AND date != CURRENT_DATE() AND status IN ('${params.status}','accepted','running')`
            }else if(params.status == "completed"){
                order_by = `ORDER BY b.update_datetime DESC, b.date, b.time`
                where = `AND status = '${params.status}'`
            }else{
                where = `AND status = '${params.status}'`
            }
            if(params.status == "cancelled"){
                order_by = `ORDER BY b.update_datetime DESC`
            }
            read.query(`SELECT b.id, b.order_id, b.date, b.time, b.provider_id, b.service_ids, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, b.total_amount, b.final_amount, b.status, b.cancel_by FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.user_id = ${params.login_user_id} ${where} ${order_by} LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        home.get_cart_service(item.service_ids).then((resService)=>{
                            item.main_category_id = (resService.main) ? resService.main.id : ``
                            item.main_category_name = (resService.main) ? resService.main.name : ``
                            item.sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                            item.sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                            item.services = resService.result
                            next()
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result})
                    })
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           My Service Details                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    my_service_details: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.order_id, b.date, b.time, b.provider_id, b.type, b.description, b.address, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, b.service_ids, b.total_amount, b.discount_amount, b.final_amount, b.payment_type, b.start_service_otp, b.end_service_otp, b.status, b.cancel_by FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.user_id = ${params.login_user_id} AND b.id = ${params.id} LIMIT 1`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    home.get_cart_service(result[0].service_ids).then((resService)=>{
                        home.get_additional_cost(result[0].id).then((resAdditionalCost)=>{
                            result[0].main_category_id = (resService.main) ? resService.main.id : ``
                            result[0].main_category_name = (resService.main) ? resService.main.name : ``
                            result[0].sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                            result[0].sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                            result[0].services = resService.result
                            result[0].additional_cost = resAdditionalCost
                            result[0].address = (result[0].address) ? JSON.parse(result[0].address) : {}
                            resolve(result[0])
                        })
                    })
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Re-Sechedule Service                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    reschedule_service: function(params) {
        return new Promise((resolve,reject)=>{
            home.check_provider_available({
                services:[{
                    provider_id:params.provider_id,
                    date:params.date,
                    time:params.time,
                    sub_category_name:params.sub_category_name
                }]
            }).then((response)=>{
                let updateData = {
                    date: params.date,
                    time: params.time,
                    update_datetime: moment().format("X")
                }
                write.query(`UPDATE tbl_booking SET ? WHERE id = ${params.id}`, updateData, (uErr,uResult)=>{
                    if(!uErr && uResult != undefined){
                        read.query(`SELECT b.id, b.provider_id, b.order_id, u.current_language FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.user_id = ${params.login_user_id} AND b.id = ${params.id} LIMIT 1`,(err,result)=>{
                            var push_data = {
                                title: lang[result[0].current_language]['text_booking_reschedule_title'].replace('{order_id}',result[0].order_id),
                                body: lang[result[0].current_language]['text_booking_reschedule_body'].replace('{order_id}',result[0].order_id),
                                custom: {
                                    tag: "booking_reschedule",
                                    order_id: result[0].order_id,
                                    booking_id: result[0].id
                                }
                            }
                            var push_notification = {
                                sender_id: params.login_user_id,
                                receiver_id: result[0].provider_id,
                                action_id: result[0].id,
                                message: JSON.stringify({title:'text_booking_reschedule_title',body:'text_booking_reschedule_body'}),
                                tag: 'booking_reschedule',
                                insert_datetime: moment().format("X")
                            }
                            console.log(result[0].provider_id,push_data)
                            common.prepare_notification(result[0].provider_id,push_data)
                            common.add_data('tbl_notification',push_notification,(res)=>{})
                            resolve(uResult)
                        })
                    }else{
                        reject(false)
                    }
                })
            }).catch((err)=>{
                reject(err)
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Cancel Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    cancel_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.status, b.provider_id, b.order_id, u.current_language, CONCAT(first_name,' ',last_name) AS sp_name, b.payment_type, b.transaction_id, b.final_amount FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.user_id = ${params.login_user_id} AND b.id = ${params.id} LIMIT 1`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    if(["running","completed","cancelled"].indexOf(result[0].status) !== -1){
                        resolve({code:"0",status:result[0].status})
                    }else{
                        let updateData = {
                            cancel_by: 'customer',
                            status: 'cancelled',
                            cancel_reason: params.reason,
                            ...(params.comment) && {cancel_comment:params.comment},
                            update_datetime: moment().format("X")
                        }
                        write.query(`UPDATE tbl_booking SET ? WHERE id = ${params.id}`, updateData, (uErr,uResult)=>{
                            if(!uErr && uResult != undefined){
                                if(result[0].payment_type == "card"){
                                    common.razorpay_refund(result[0].transaction_id,result[0].final_amount,`Booking Id #${result[0].order_id}`).catch((error)=>{});
                                }
                                var push_data = {
                                    title: lang[result[0].current_language]['text_booking_cancelled_title'].replace('{sp_name}',result[0].sp_name),
                                    body: lang[result[0].current_language]['text_booking_cancelled_body'].replace('{order_id}',result[0].order_id),
                                    custom: {
                                        tag: "booking_cancelled",
                                        order_id: result[0].order_id,
                                        booking_id: result[0].id
                                    }
                                }
                                var push_notification = {
                                    sender_id: params.login_user_id,
                                    receiver_id: result[0].provider_id,
                                    action_id: result[0].id,
                                    message: JSON.stringify({title:'text_booking_cancelled_title',body:'text_booking_cancelled_body'}),
                                    tag: 'booking_cancelled',
                                    insert_datetime: moment().format("X")
                                }
                                common.prepare_notification(result[0].provider_id,push_data)
                                common.add_data('tbl_notification',push_notification,(res)=>{})
                                resolve(uResult)
                            }else{
                                reject(false)
                            }
                        })
                    }
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Service Provider Fav Unfav                            /////
    //////////////////////////////////////////////////////////////////////////////////////////
    provider_fav_unfav: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, type FROM tbl_user_favorite_unfavorite WHERE user_id = ${params.login_user_id} AND provider_id = ${params.provider_id} LIMIT 1`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    let updateData = {
                        type: (result[0].type == "Favorite") ? "Unfavorite" : "Favorite",
                        update_datetime: moment().format('X')
                    }
                    write.query(`UPDATE tbl_user_favorite_unfavorite SET ? WHERE id = ${result[0].id}`, updateData,(uErr,uResult)=>{
                        if(!uErr){
                            resolve(updateData.type)
                        }else{
                            reject(updateData.type)
                        }
                    })
                } else {
                    let insertData = {
                        user_id: params.login_user_id,
                        provider_id: params.provider_id,
                        type: 'Favorite',
                        insert_datetime: moment().format('X')
                    }
                    write.query(`INSERT INTO tbl_user_favorite_unfavorite SET ?`, insertData, (err,result)=>{
                        if(!err){
                            resolve('Favorite')
                        }else{
                            reject('Favorite')
                        }
                    })
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Favorite Provider List                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    provider_fav_list: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT u.id,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image,u.first_name,u.last_name,u.location,u.latitude,u.longitude,u.main_category,CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',c.image) AS main_category_image FROM tbl_user_favorite_unfavorite AS f JOIN tbl_user AS u ON u.id = f.provider_id JOIN tbl_category AS c ON c.id = u.main_category WHERE f.user_id = ${params.login_user_id} AND f.type = 'Favorite' AND u.is_active = '1' LIMIT ${parseInt(params.page_token)*parseInt(GLOBALS.PER_PAGE)},${GLOBALS.PER_PAGE}`, function(err, result) {
                if (!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        home.get_service_provider_fav_unfav(params.login_user_id,item.id).then((resFavUnfav)=>{
                            home.get_review_count(item.id).then((resReview)=>{
                                item.is_favorite = resFavUnfav
                                item.rating = resReview.rating
                                item.review_count = resReview.review_count
                                next()
                            })
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result})
                    })
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Booking Experience                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_booking_experience: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id FROM tbl_booking_experience WHERE booking_id = ${params.booking_id} LIMIT 1`,(sErr,sResult)=>{
                let insertData = {
                    user_id: params.login_user_id,
                    booking_id: params.booking_id,
                    experience: params.experience,
                    arrived_on_time: params.arrived_on_time,
                    finished_on_time: params.finished_on_time,
                    polite: params.polite,
                    overall_satisfaction: params.overall_satisfaction,
                    ...(params.review) && {review: params.review},
                    insert_datetime: moment().format("X")
                }
                if(!sErr && sResult[0] != undefined){
                    write.query(`UPDATE tbl_booking_experience SET ? WHERE booking_id = ${params.booking_id}`,[insertData],(err,result)=>{
                        if(!err && result != undefined){
                            home.send_notification_booking_experience(params.booking_id,params.experience);
                            resolve();
                        }else{
                            reject();
                        }
                    })
                }else{
                    write.query(`INSERT INTO tbl_booking_experience SET ?`,insertData,(err,result)=>{
                        if(!err && result != undefined){
                            home.send_notification_booking_experience(params.booking_id,params.experience);
                            resolve();
                        }else{
                            reject();
                        }
                    })
                }
            })
        })
    },
    async send_notification_booking_experience(booking_id,experience){
        read.query(`SELECT b.id, b.order_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name, b.provider_id, b.user_id FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.id = ${booking_id} LIMIT 1`,(err,result)=>{
            if(experience <= 2){
                var push_data = {
                    title: lang[result[0].current_language]['text_booking_experience_title'].replace('{sp_name}',result[0].sp_name),
                    body: lang[result[0].current_language]['text_booking_experience_body'].replace('{order_id}',result[0].order_id),
                    custom: {
                        tag: "booking_experience",
                        order_id: result[0].order_id,
                        booking_id: result[0].id
                    }
                }
                var push_notification = {
                    sender_id: result[0].user_id,
                    receiver_id: result[0].provider_id,
                    action_id: result[0].id,
                    message: JSON.stringify({title:'text_booking_experience_title',body:'text_booking_experience_body'}),
                    tag: 'booking_experience',
                    insert_datetime: moment().format("X")
                }
                common.prepare_notification(result[0].provider_id,push_data)
                common.add_data('tbl_notification',push_notification,(res)=>{})
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Booking Report Issue                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_booking_report_issue: function(params) {
        return new Promise((resolve,reject)=>{
            let insertData = {
                user_id: params.login_user_id,
                booking_id: params.booking_id,
                reason: params.reason,
                description: params.description,
                insert_datetime: moment().format("X")
            }
            write.query(`INSERT INTO tbl_booking_issue SET ?`,insertData,(err,result)=>{
                if(!err && result != undefined){
                    read.query(`SELECT b.id, b.order_id, b.provider_id, u.current_language AS sp_lang, CONCAT(u.first_name,' ',u.last_name) AS sp_name, u.parent_id FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.id = ${params.booking_id} LIMIT 1`,(pErr,pResult)=>{
                        var push_data = {
                            title: lang[pResult[0].sp_lang]['text_booking_issue_title'].replace('{sp_name}',pResult[0].sp_name),
                            body: lang[pResult[0].sp_lang]['text_booking_issue_body'].replace('{order_id}',pResult[0].order_id),
                            custom: {
                                tag: "booking_issue",
                                order_id: pResult[0].order_id,
                                booking_id: pResult[0].id
                            }
                        }
                        var push_notification = {
                            sender_id: params.login_user_id,
                            receiver_id: pResult[0].provider_id,
                            action_id: pResult[0].id,
                            message: JSON.stringify({title:'text_booking_issue_title',body:'text_booking_issue_body'}),
                            tag: 'booking_issue',
                            insert_datetime: moment().format("X")
                        }
                        common.prepare_notification(pResult[0].provider_id,push_data)
                        common.add_data('tbl_notification',push_notification,(res)=>{})
                        if(pResult[0].parent_id != 0){
                            read.query(`SELECT current_language FROM tbl_user WHERE id = ${pResult[0].parent_id} LIMIT 1`,(mErr,mResult)=>{
                                var push_data = {
                                    title: lang[mResult[0].current_language]['text_booking_issue_on_staff_title'],
                                    body: lang[mResult[0].current_language]['text_booking_issue_on_staff_body'].replace('{order_id}',pResult[0].order_id),
                                    custom: {
                                        tag: "booking_issue_on_staff",
                                        order_id: pResult[0].order_id,
                                        booking_id: pResult[0].id
                                    }
                                }
                                var push_notification = {
                                    sender_id: params.login_user_id,
                                    receiver_id: pResult[0].parent_id,
                                    action_id: pResult[0].id,
                                    message: JSON.stringify({title:'text_booking_issue_on_staff_title',body:'text_booking_issue_on_staff_body'}),
                                    tag: 'booking_issue_on_staff',
                                    insert_datetime: moment().format("X")
                                }
                                common.prepare_notification(pResult[0].parent_id,push_data)
                                common.add_data('tbl_notification',push_notification,(res)=>{})
                            })
                        }
                    })
                    resolve();
                }else{
                    reject();
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Get Review List                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_review_list: function(params) {
        return new Promise((resolve,reject)=>{
            var low_to_high = ``
            var high_to_low = ``
            if(params.low_to_high){
                low_to_high = `ORDER BY e.experience`
                if(params.newest_to_oldest){
                    low_to_high += `,e.id DESC`
                }
                if(params.oldest_to_newest){
                    low_to_high += `,e.id`
                }
            }
            if(params.high_to_low){
                high_to_low = `ORDER BY e.experience DESC`
                if(params.newest_to_oldest){
                    high_to_low += `,e.id DESC`
                }
                if(params.oldest_to_newest){
                    high_to_low += `,e.id`
                }
            }
            if(params.newest_to_oldest && params.low_to_high == `` && params.high_to_low == ``){
                low_to_high += `ORDER BY e.id DESC`
            }
            if(params.oldest_to_newest && params.low_to_high == `` && params.high_to_low == ``){
                low_to_high += `ORDER BY e.id`
            }
            if(low_to_high == `` && high_to_low == ``){
                low_to_high = `ORDER BY e.insert_datetime DESC`
            }
            var rating = (params.rating) ? `AND e.experience = '${params.rating}'` : ``
            read.query({sql:`SELECT e.id, e.user_id, u.first_name, u.last_name, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, e.experience, e.review, e.insert_datetime FROM tbl_booking AS b JOIN tbl_booking_experience AS e ON b.id = e.booking_id JOIN tbl_user AS u ON u.id = e.user_id WHERE b.provider_id = '${params.provider_id}' ${rating} ${low_to_high} ${high_to_low} LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`,
                typeCast:(field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string()
                    }
                    return next()
                }
            }, (err, result) => {
                if (!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Additional Cost Action                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    additional_cost_action: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT c.status, c.value, b.id, b.provider_id, b.order_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking_additional_cost AS c JOIN tbl_booking AS b ON b.id = c.booking_id JOIN tbl_user AS u ON u.id = b.provider_id WHERE c.booking_id = '${params.booking_id}' AND c.additional_id = '${params.additional_id}'`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    if(result[0].status == "pending"){
                        var updateData = {
                            status: params.action
                        }
                        if(params.action == "accept"){
                            updateData.payment_mode = params.payment_mode;
                            updateData.payment_status = params.payment_status;
                            if(params.transaction_id){
                                updateData.transaction_id = params.transaction_id;
                            }
                        }
                        write.query(`UPDATE tbl_booking_additional_cost SET ? WHERE booking_id = '${params.booking_id}' AND additional_id = '${params.additional_id}'`,[updateData],(uErr,uResult)=>{
                            if(!uErr && uResult != undefined){
                                var title = (params.action == "accept") ? lang[result[0].current_language]['text_booking_additional_cost_accepted_title'].replace('{sp_name}',result[0].sp_name) : lang[result[0].current_language]['text_booking_additional_cost_rejected_title'].replace('{sp_name}',result[0].sp_name)
                                var body = (params.action == "accept") ? lang[result[0].current_language]['text_booking_additional_cost_accepted_body'].replace('{rs}',result[0].value) : lang[result[0].current_language]['text_booking_additional_cost_rejected_body'].replace('{rs}',result[0].value)
                                var push_data = {
                                    title: title,
                                    body: body,
                                    custom: {
                                        tag: "booking_additional_cost_action",
                                        order_id: result[0].order_id,
                                        booking_id: result[0].id
                                    }
                                }

                                var ptitle = (params.action == "accept") ? `text_booking_additional_cost_accepted_title` : `text_booking_additional_cost_rejected_title`
                                var pbody = (params.action == "accept") ? `text_booking_additional_cost_accepted_body` : `text_booking_additional_cost_rejected_body`
                                var push_notification = {
                                    sender_id: params.login_user_id,
                                    receiver_id: result[0].provider_id,
                                    action_id: result[0].id,
                                    message: JSON.stringify({title:ptitle,body:pbody,action:params.action,rs:result[0].value}),
                                    tag: 'booking_additional_cost_action',
                                    insert_datetime: moment().format("X")
                                }
                                common.prepare_notification(result[0].provider_id,push_data)
                                common.add_data('tbl_notification',push_notification,(res)=>{})
                                resolve({code:1})
                            }else{
                                resolve({code:0})
                            }
                        })
                    }else{
                        resolve({code:2,status:result[0].status})
                    }
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                       Provider Sub Category List                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    provider_sub_category_list: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT s.id, s.name FROM tbl_category_service AS cs JOIN tbl_category AS s ON s.id = cs.sub_category_id WHERE cs.user_id = ${params.provider_id} AND cs.type = 'charge' AND cs.is_check = 'true' GROUP BY cs.sub_category_id LIMIT ${parseInt(params.page_token)*parseInt(GLOBALS.PER_PAGE)},${GLOBALS.PER_PAGE}`,(err, result)=>{
                if (!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Provider Service On Off                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    provider_service_on_off: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT is_active FROM tbl_user WHERE id = ${params.provider_id}`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    if(result[0].is_active == "1"){
                        var services = ``
                        asyncLoop(params.service_ids.split(','),(item,next)=>{
                            read.query(`SELECT id, service_name, is_check, is_active FROM tbl_category_service WHERE id = ${item} AND type = 'charge'`,(sErr,sResult)=>{
                                if(!sErr && sResult[0] != undefined){
                                    if(sResult[0].is_active != "1" || sResult[0].is_check != "true"){
                                        services += sResult[0].service_name+','
                                    }
                                    next()
                                }else{
                                    next()
                                }
                            })
                        },()=>{
                            if(services){
                                resolve({code:2,service_name:services.slice(0,-1)})
                            }else{
                                resolve({code:1})
                            }
                        })
                    }else{
                        resolve({code:2,status:result[0].is_active})
                    }
                } else {
                    reject()
                }
            })
        })
    },
}

module.exports = home;