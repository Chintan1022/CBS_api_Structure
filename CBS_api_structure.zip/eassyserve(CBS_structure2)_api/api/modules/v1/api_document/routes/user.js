var express = require('express');
var GLOBALS = require('../../../../config/constants');
var user_model = require('../../authentication/authentication_model');
app = express()

exports.login = function(req, res){ 
   var message = '';
   var sess = req.session; 

   if(req.method == "POST"){
      var post  = req.body;
      var password = post.password;
      var static_doc_password = GLOBALS.STATIC_DOC_PASSWORD;
         if(password == static_doc_password){
            sess.user = static_doc_password;
            res.redirect('/home/dashboard');
         }
         else{
            message = 'You have entered invalid password.';
            res.render('index.ejs',{message: message, GLOBALS: GLOBALS});
         }
   } else {
      res.render('index.ejs',{message: message, GLOBALS: GLOBALS});
   }
};

exports.dashboard = function(req, res, next){
   var user =  req.session.user
   if(user == null){
      res.redirect("/login");
      return;
   }else{
      res.render('api_doc.ejs', {GLOBALS: GLOBALS}); 
   }       
};

exports.user_list = function(req, res){
   var user = req.session.user;
   if(user == null){
      res.redirect("/login");
      return;
   }
   user_model.api_user_list(function(response){
      res.render('user_list.ejs', { data: response, GLOBALS: GLOBALS })
   })
};

exports.code = function(req, res){
   var user = req.session.user;
   if(user == null){
      res.redirect("/login");
      return;
   }
   res.render('reference_code.ejs', { GLOBALS: GLOBALS })
};

exports.enc_dec = function(req, res){
   var user = req.session.user;
   if(user == null){
      res.redirect("/login");
      return;
   }
   res.render('enc_dec.php', { GLOBALS: GLOBALS })
};

exports.logout=function(req,res){
   req.session.destroy(function(err) {
      res.redirect("/login");
   })
};