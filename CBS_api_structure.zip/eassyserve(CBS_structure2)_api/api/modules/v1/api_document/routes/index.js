/*
* GET home page.
*/
var GLOBALS = require('../../../../config/constants');

exports.index = function(req, res){
  var message = '';
  res.render('index',{message: message, GLOBALS: GLOBALS});
};