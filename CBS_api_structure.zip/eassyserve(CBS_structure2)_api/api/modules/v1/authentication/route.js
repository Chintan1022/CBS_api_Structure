const express = require('express');
var authentication_model = require('./authentication_model');
var common = require('../../../config/common');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const lang = require("../../../config/language");

app = express();
var router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Check Unique                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/check_unique', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "mobile_number": "required",
            "user_type": "required|in:customer,provider",
            "is_signup": "required"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            if (params.is_signup == "true" || params.is_signup == true) {
                common.check_unique(params, function(response, val, field) {
                    if (response) {
                        if (field == 'mobile_number') {
                            common.sendResponse(res, "17", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                        }
                    } else {
                        common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
                    }
                });
            } else {
                if (req.headers['token']) {
                    authentication_model.user_details_with_token({ 'token': req.headers['token'], language: req.language }, function(resCode, resMsg, resData) {
                        if (resCode == "1") {
                            authentication_model.edit_check_unique(resData.user_id, params, function(response, val) {
                                if (response) {
                                    common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
                                } else {
                                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                                }
                            });
                        } else {
                            common.sendResponse(res, resCode, resMsg, resData);
                        }
                    });
                } else {
                    common.sendResponse(res, "-1", lang[req.language]['text_rest_tokeninvalid'], null, '401');
                }
            }
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Send OTP                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/send_otp", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            country_code: 'required',
            mobile_number: 'required',
            user_type: "required|in:customer,provider",
            type: 'required:in:signup,forgot'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            if (params.type == "signup") {
                params.language = req.language
                authentication_model.user_details(params, (resCode, resMsg, resData) => {
                    if (resCode == "1") {
                        common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', params.mobile_number), null);
                    } else {
                        //send otp
                        params.otp = Math.floor(1000 + Math.random() * 9000);
                        common.send_sms(params.mobile_number, params.otp, `otp_send`, function(resSMS) {
                            if (resSMS.code) {
                                authentication_model.checkVerify(params, function(response) {
                                    if (response) {
                                        common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}', 'mobile number'), { session_id: resSMS.session_id });
                                    } else {
                                        common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                                    }
                                });
                            } else {
                                common.sendResponse(res, "0", lang[req.language]['otp_not_send'], null);
                            }
                        });
                    }
                })
            } else {
                var where = {
                    mobile_number: params.mobile_number,
                    country_code: params.country_code,
                    language: req.language,
                    user_type: params.user_type
                }
                authentication_model.user_details(where, function(resCode, resMsg, resData) {
                    if (resCode == "2") {
                        common.sendResponse(res, "0", lang[req.language]['text_user_login_new'], null);
                    } else {
                        //send otp
                        params.otp = Math.floor(1000 + Math.random() * 9000);
                        common.send_sms(params.mobile_number, params.otp, `send_otp`, function(resSMS) {
                            if (resSMS.code) {
                                params.user_id = resData.id
                                authentication_model.checkVerify(params, function(response) {
                                    if (response) {
                                        common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}', 'mobile number'), { session_id: resSMS.session_id });
                                    } else {
                                        common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                                    }
                                });
                            } else {
                                common.sendResponse(res, "0", lang[req.language]['otp_not_send'], null);
                            }
                        });
                    }
                });
            }
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Verify OTP                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/verify_otp", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "otp": "required",
            "mobile_number": "required",
            "country_code": "required",
            "user_type": "required|in:customer,provider",
            "type": "required:in:signup,forgot"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            if (params.type == "signup") {
                common.check_unique(params, function(response, val) {
                    if (response) {
                        common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                    } else {
                        authentication_model.verify_otp(params, function(resCode, resMsg, resData) {
                            common.sendResponse(res, resCode, resMsg, resData);
                        });
                    }
                })
            } else {
                authentication_model.user_details(params, (resCode1, resMsg1, resData1) => {
                    authentication_model.verify_otp(params, function(resCode, resMsg, resData) {
                        if (params.type == "forgot") {
                            common.update_data(`tbl_user`, resData1.id, { is_forgot_verify: 1 });
                        }
                        common.sendResponse(res, resCode, resMsg, resData);
                    });
                })
            }
        }
    })
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signup                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signup', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "first_name": "required",
            "last_name": "required",
            "email": "required|email",
            "country_code": "required",
            "mobile_number": "required",
            "gender": "required|in:male,female",
            "password": "required",
            "device_token": "required",
            "device_type": "required",
            "device_model": "required",
            "uuid": "required",
            "ip": "required"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.user_type = 'customer';
            common.check_unique(params, function(response, val) {
                if (response) {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                } else {
                    var data = {
                        "first_name": params.first_name,
                        "last_name": params.last_name,
                        "email": params.email,
                        "country_code": params.country_code,
                        "mobile_number": params.mobile_number,
                        "gender": params.gender,
                        "referal_code": common.stringGen(10),
                        ...(params.referal_code) && { friend_refer_code: params.referal_code },
                        "insert_datetime": moment().format("X")
                    }
                    const cryptoLib = require('cryptlib');
                    const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
                    data.password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV);
                    authentication_model.signup(data, params.referal_code, function(result) {
                        if (result != null) {
                            common.checkDeviceInfo(result.insertId, params, function(response) {
                                if (response) {
                                    authentication_model.user_details({ "user_id": result.insertId, 'language': req.language, "user_type": "customer" }, function(resCode, resMsg, resData) {
                                        delete resData.password;
                                        // delete resData.login_type;
                                        resData['token'] = response.token;
                                        common.sendResponse(res, "1", lang[req.language]['text_user_signup_success'], resData);
                                    });
                                } else {
                                    common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                                }
                            });
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['signup_unsuccess'], null);
                        }
                    });
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signin                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signin', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "country_code": "required",
            "mobile_number": "required",
            "password": "required",
            "device_token": "required",
            "device_type": "required",
            "device_model": "required",
            "uuid": "required",
            "ip": "required"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            authentication_model.signin(params, function(resCode, resMsg, resData) {
                if (resData != null) {
                    common.checkDeviceInfo(resData.id, params, function(response) {
                        if (response != null) {
                            delete resData.password;
                            resData['token'] = response.token;
                            common.sendResponse(res, resCode, resMsg, resData);
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                        }
                    });
                } else {
                    common.sendResponse(res, resCode, resMsg, resData);
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Edit Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/edit_profile', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "first_name": "required",
            "last_name": "required",
            "email": "required",
            "country_code": "required",
            "mobile_number": "required",
            "gender": "required|in:male,female"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            authentication_model.edit_check_unique(req.login_user_id, params, function(response, val) {
                if (response) {
                    var data = {
                        "first_name": params.first_name,
                        "last_name": params.last_name,
                        "email": params.email,
                        "country_code": params.country_code,
                        "mobile_number": params.mobile_number,
                        "gender": params.gender,
                        ...(params.bio) && { bio: params.bio },
                        "update_datetime": moment().format("X")
                    }
                    if (params.profile_image) {
                        common.get_old_image_name_and_delete(`tbl_user`, `profile_image`, `id = ${req.login_user_id}`, GLOBALS.USER_IMAGE, () => {});
                        data.profile_image = params.profile_image;
                    }
                    authentication_model.edit_profile(req.login_user_id, data, req.language, function(resCode, resMsg, resData) {
                        common.sendResponse(res, resCode, resMsg, resData);
                    });
                } else {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Get Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_profile", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "user_id": "required" }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            params.user_type = 'customer'
            authentication_model.user_details(params, function(resCode, resMsg, resData) {
                if (resCode == "1") {
                    delete resData.password;
                    // delete resData.login_type;
                }
                common.sendResponse(res, resCode, resMsg, resData);
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Get Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/change_language", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "language": "required|in:en,hi,enhi,mr" }
        if (common.checkValidation(params, rules, res, req.language)) {
            let updateData = {
                current_language: params.language
            }
            common.update_data('tbl_user', req.login_user_id, updateData);
            common.sendResponse(res, "1", lang[req.language], null);
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Contact Us                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/contact_us", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "email": "required", "subject": "required", "description": "required" }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.insert_datetime = moment().format("X");
            common.add_data('tbl_contact_us', params, function() {
                common.sendResponse(res, "1", lang[req.language]["text_user_contactus_success"], null);
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Reset Password                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/reset_password", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            country_code: 'required',
            mobile_number: 'required',
            password: 'required',
            user_type: 'required|in:customer,provider'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            authentication_model.reset_password(params, function(resCode, resMsg, resData) {
                common.sendResponse(res, resCode, resMsg, resData);
            })
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Change Password                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/change_password', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "old_password": "required",
            "new_password": "required",
            "confirm_password": "required",
            "user_type": "required|in:customer,provider"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            const cryptoLib = require('cryptlib');
            const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
            authentication_model.user_details({ 'user_id': req.login_user_id, 'language': req.language, 'user_type': params.user_type }, function(resCode, resMsg, resData) {
                if (cryptoLib.encrypt(params.old_password, shaKey, GLOBALS.ENC_IV) == resData.password) {
                    if (params.new_password != params.old_password) {
                        if (params.new_password == params.confirm_password) {
                            common.update_data("tbl_user", req.login_user_id, { "password": cryptoLib.encrypt(params.new_password, shaKey, GLOBALS.ENC_IV) });
                            common.sendResponse(res, "1", lang[req.language]["text_user_change_password_success"], null);
                        } else {
                            common.sendResponse(res, "0", lang[req.language]["text_new_confirm_password_not_match"], null);
                        }
                    } else {
                        common.sendResponse(res, "0", lang[req.language]["text_old_new_password_same"], null);
                    }
                } else {
                    common.sendResponse(res, "0", lang[req.language]["text_user_change_password_fail"], null);
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                   Logout                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/logout", function(req, res) {
    authentication_model.logout(req.login_user_id, function(resCode) {
        common.sendResponse(res, resCode, lang[req.language]['text_user_logout'], null);
    });
});

module.exports = router;