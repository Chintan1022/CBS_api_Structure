const {read,write} = require('../../../config/database');
const common = require('../../../config/common');
const asyncLoop = require('node-async-loop');
const lang = require('../../../config/language');
const moment = require('moment');

var cron = {
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Booking Accepted Or Not                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async check_booking_accepted_or_not()
    {
        read.query(`SELECT b.id, b.user_id, b.provider_id, b.order_id, u.parent_id, u.current_language, b.transaction_id, b.final_amount FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 30 MINUTE) AND (NOW() - INTERVAL 29 MINUTE) AND b.status = 'pending'`,(err,result)=>{
            if(!err && result[0] != undefined){
                asyncLoop(result,(item,next)=>{
                    if(result[0].payment_type == "card"){
                        common.razorpay_refund(result[0].transaction_id,result[0].final_amount,`Booking Id #${result[0].order_id}`).catch((error)=>{});
                    }
                    read.query(`SELECT current_language, CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE id = ${item.provider_id} LIMIT 1`,(pErr,pResult)=>{
                        var updateData = {
                            status: 'cancelled',
                            cancel_by: 'provider',
                            is_auto_reject: 'true',
                            update_datetime: moment().format("X")
                        }
                        write.query(`UPDATE tbl_booking SET ? WHERE id = ${item.id}`,updateData,(uErr,uResult)=>{
                            // send to customer
                            var push_data = {
                                title: lang[item.current_language]['text_booking_not_accepted_title'].replace('{order_id}',item.order_id),
                                body: lang[item.current_language]['text_booking_not_accepted_body'],
                                custom: {
                                    tag: "booking_rejected",
                                    order_id: item.order_id,
                                    booking_id: item.id
                                }
                            }
                            var push_notification = {
                                sender_id: item.provider_id,
                                receiver_id: item.user_id,
                                action_id: item.id,
                                message: JSON.stringify({title:'text_booking_not_accepted_title',body:'text_booking_not_accepted_body'}),
                                tag: 'booking_rejected',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(item.user_id,push_data)
                            common.add_data('tbl_notification',push_notification,(res)=>{})
                            // send to provider
                            var push_data_provider = {
                                title: lang[pResult[0].current_language]['text_booking_not_accepted_provider_title'].replace('{sp_name}',pResult[0].sp_name),
                                body: lang[pResult[0].current_language]['text_booking_not_accepted_provider_body'].replace('{order_id}',item.order_id),
                                custom: {
                                    tag: "booking_missed",
                                    order_id: item.order_id,
                                    booking_id: item.id
                                }
                            }
                            var push_notification_provider = {
                                sender_id: item.provider_id,
                                receiver_id: item.provider_id,
                                action_id: item.id,
                                message: JSON.stringify({title:'text_booking_not_accepted_provider_title',body:'text_booking_not_accepted_provider_body'}),
                                tag: 'booking_missed',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(item.provider_id,push_data_provider)
                            common.add_data('tbl_notification',push_notification_provider,(res)=>{})
                            if(item.parent_id != 0){
                                // send main provider
                                cron.send_sp_staff_missed_booking(item.id,item.order_id,item.parent_id,item.provider_id);
                            }
                            write.query(`UPDATE tbl_user SET total_auto_reject = (SELECT COUNT(id) FROM tbl_booking WHERE provider_id = ${item.provider_id} AND status = 'cancelled' AND cancel_by = 'provider' AND is_auto_reject = 'true') WHERE id = ${item.provider_id}`);
                            next()
                        })
                    })
                })
            }
        })
    },
    async send_sp_staff_missed_booking(booking_id,order_id,parent_id,staff_id){
        read.query(`SELECT CONCAT(s.first_name,' ',s.last_name) AS name, m.current_language FROM tbl_user AS s JOIN tbl_user AS m ON m.id = s.parent_id WHERE s.id = ${staff_id} LIMIT 1`,(err,result)=>{
            var push_data_provider = {
                title: lang[result[0].current_language]['text_booking_not_accepted_main_provider_title'],
                body: lang[result[0].current_language]['text_booking_not_accepted_main_provider_body'].replace('{order_id}',order_id).replace('{staff_id}',staff_id).replace('{name}',result[0].name),
                custom: {
                    tag: "booking_missed_by_staff",
                    order_id: order_id,
                    booking_id: booking_id
                }
            }
            var push_notification_provider = {
                sender_id: staff_id,
                receiver_id: parent_id,
                action_id: booking_id,
                message: JSON.stringify({title:'text_booking_not_accepted_main_provider_title',body:'text_booking_not_accepted_main_provider_body'}),
                tag: 'booking_missed_by_staff',
                insert_datetime: moment().format("X")
            }
            common.prepare_notification(parent_id,push_data_provider)
            common.add_data('tbl_notification',push_notification_provider,(res)=>{})
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Remove Past Cart Added                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async remove_past_cart_added()
    {
        read.query(`SELECT GROUP_CONCAT(id) AS ids FROM tbl_cart WHERE date < CURRENT_DATE()`,(err,result)=>{
            if(!err && result[0] != undefined && result[0].ids != null){
                write.query(`DELETE FROM tbl_cart WHERE id IN (${result[0].ids})`)
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Provider Offer Live                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async provider_offer_live()
    {
        read.query(`SELECT o.id, o.user_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_offer AS o JOIN tbl_user AS u ON u.id = o.user_id WHERE o.start_date = CURRENT_DATE() AND o.added_by = 'provider'`,(err,result)=>{
            if(!err && result[0] != undefined){
                asyncLoop(result,(item,next)=>{
                    var push_data = {
                        title: lang[item.current_language]['text_offer_live_title'].replace('{sp_name}',item.sp_name),
                        body: lang[item.current_language]['text_offer_live_body'],
                        custom: {
                            tag: "offer_live",
                            offer_id: item.id
                        }
                    }
                    var push_notification = {
                        sender_id: item.user_id,
                        receiver_id: item.user_id,
                        action_id: item.id,
                        message: JSON.stringify({title:'text_offer_live_title',body:'text_offer_live_body'}),
                        tag: 'offer_live',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.user_id,push_data)
                    common.add_data('tbl_notification',push_notification,(res)=>{})
                    next();
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Provider Offer End Remainder                            /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async provider_offer_end_remainder()
    {
        read.query(`SELECT o.id, o.user_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_offer AS o JOIN tbl_user AS u ON u.id = o.user_id WHERE o.end_date = DATE_ADD(CURRENT_DATE(),INTERVAL 1 DAY) AND o.added_by = 'provider'`,(err,result)=>{
            if(!err && result[0] != undefined){
                asyncLoop(result,(item,next)=>{
                    var push_data = {
                        title: lang[item.current_language]['text_offer_end_reminder_title'].replace('{sp_name}',item.sp_name),
                        body: lang[item.current_language]['text_offer_end_reminder_body'],
                        custom: {
                            tag: "offer_end_reminder",
                            offer_id: item.id
                        }
                    }
                    var push_notification = {
                        sender_id: item.user_id,
                        receiver_id: item.user_id,
                        action_id: item.id,
                        message: JSON.stringify({title:'text_offer_end_reminder_title',body:'text_offer_end_reminder_body'}),
                        tag: 'offer_end_reminder',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.user_id,push_data)
                    common.add_data('tbl_notification',push_notification,(res)=>{})
                    next();
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Work Region Not Set Reminder                           /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async region_reminder()
    {
        read.query(`SELECT id, current_language, CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE region_raduis = 0 AND role = 'provider' AND parent_id = 0`,(err,result)=>{
            if(!err && result[0] != undefined){
                asyncLoop(result,(item,next)=>{
                    var push_data = {
                        title: lang[item.current_language]['text_region_reminder_title'].replace('{sp_name}',item.sp_name),
                        body: lang[item.current_language]['text_region_reminder_body'],
                        custom: {
                            tag: "region_reminder"
                        }
                    }
                    var push_notification = {
                        sender_id: item.id,
                        receiver_id: item.id,
                        action_id: item.id,
                        message: JSON.stringify({title:'text_region_reminder_title',body:'text_region_reminder_body'}),
                        tag: 'region_reminder',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.id,push_data)
                    common.add_data('tbl_notification',push_notification,(res)=>{})
                    next();
                })
            }
        })
    },
    
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Rate Card Not Set Reminder                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    // async rate_card_not_set_reminder()
    // {
    //     read.query(``,(err,result)=>{
    //         if(!err && result[0] != undefined){
    //             asyncLoop(result,(item,next)=>{
    //                 var push_data = {
    //                     title: lang[item.current_language]['text_region_reminder_title'].replace('{sp_name}',item.sp_name),
    //                     body: lang[item.current_language]['text_region_reminder_body'],
    //                     custom: {
    //                         tag: "region_reminder"
    //                     }
    //                 }
    //                 var push_notification = {
    //                     sender_id: item.id,
    //                     receiver_id: item.id,
    //                     action_id: item.id,
    //                     message: JSON.stringify({title:'text_region_reminder_title',body:'text_region_reminder_body'}),
    //                     tag: 'region_reminder',
    //                     insert_datetime: moment().format("X")
    //                 }
    //                 common.prepare_notification(item.id,push_data)
    //                 common.add_data('tbl_notification',push_notification,(res)=>{})
    //                 next();
    //             })
    //         }
    //     })
    // },
}

module.exports = cron;