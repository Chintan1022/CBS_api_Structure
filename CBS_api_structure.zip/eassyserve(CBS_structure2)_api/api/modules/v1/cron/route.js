const express = require('express');
const cron_model = require('../cron/cron_model');
const cron = require('cron');
const moment = require('moment');
const moment_timezone = require('moment-timezone');

const router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Cron Set In 1 Minutes                              /////
//////////////////////////////////////////////////////////////////////////////////////////
var one_minute = new cron.CronJob({
    cronTime: '* * * * *',
    onTick: function() {
        console.log('1 MINUTE CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss"));
        cron_model.check_booking_accepted_or_not();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Cron Set In 01 Hours                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
var one_hour = new cron.CronJob({
    cronTime: '0 0 */1 * * *',
    onTick: function() {
        console.log('1 HOURS CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss"));
        cron_model.region_reminder();
        // cron_model.rate_card_not_set_reminder();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                        Cron Set In Every Day 12 AM                             /////
//////////////////////////////////////////////////////////////////////////////////////////
var every_day_12_AM = new cron.CronJob({
    cronTime: '0 12 * * *',
    onTick: function() {
        console.log('EVERY DAY 12 AM CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss"));
        cron_model.provider_offer_end_remainder();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Cron Set In 24 Hours                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
var one_day = new cron.CronJob({
    cronTime: '0 */23 * * *',
    onTick: function() {
        console.log('24 HOURS CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD HH:mm:ss"));
        cron_model.remove_past_cart_added();
        cron_model.provider_offer_live();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

module.exports = router;