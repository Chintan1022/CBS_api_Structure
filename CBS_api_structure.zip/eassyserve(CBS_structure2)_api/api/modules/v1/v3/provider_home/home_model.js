const { read,write } = require('../../../config/database');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const moment_timezone = require('moment-timezone');
const lang = require('../../../config/language');
const asyncLoop = require('node-async-loop');
const common = require('../../../config/common');
const template = require('../../../config/template');
const { ToWords } = require('to-words');
const toWords = new ToWords({
    converterOptions: {
        currency: true,
        ignoreDecimal: false,
        ignoreZeroCurrency: false,
        doNotAddOnly: false
    }
});
const htmlpdf = require('html-pdf');
const AWS = require('aws-sdk');
const s3 = new AWS.S3({
    accessKeyId: GLOBALS.S3_ACCESS_KEY,
    secretAccessKey: GLOBALS.S3_SECRET_KEY,
    region: GLOBALS.S3_REGION
});

var home = {

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Filter List                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    filter_list : function(params)
    {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT f.id, f.name, f.is_multiple FROM tbl_category AS c JOIN tbl_filter AS f ON f.id = c.filter_id WHERE c.parent_id = '${params.category_id}' AND c.is_active = '1' GROUP BY c.filter_id`, function(err, result) {
                if(!err && result[0] != undefined) {
                    asyncLoop(result, (item,next) => {
                        read.query(`SELECT c.id, c.name, IF(IFNULL(s.id,'false') = 'false','false','true') AS is_check FROM tbl_category AS c LEFT JOIN tbl_category_service AS s ON s.service_name = c.id  AND s.user_id = '${params.login_user_id}' AND s.type = 'filter' WHERE c.parent_id = '${params.category_id}' AND c.filter_id = '${item.id}' AND c.is_active = '1'`, (cErr,cResult) => {
                            item.is_multiple = (item.is_multiple == 'yes') ? true : false
                            item.list = cResult
                            next()
                        })
                    },()=>{
                        read.query(`SELECT id,price,service_name,is_check FROM tbl_category_service WHERE sub_category_id = '${params.category_id}' AND user_id = '${params.login_user_id}' AND type = 'charge' AND is_active = '1'`,function(sErr,sResult){
                            if(!sErr && sResult[0] != undefined){
                                result.push({id:0,name:"Service & Price",list:sResult})
                                resolve(result)
                            }else{
                                result.push({id:0,name:"Service & Price",list:[]})
                                resolve(result)
                            }
                        })
                    })
                }
                else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Add Service & Price                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_service_price: function(params) {
        return new Promise((resolve,reject)=>{
            let insertData = {
                user_id: params.login_user_id,
                sub_category_id: params.sub_category_id,
                service_name: params.service_name,
                price: params.price,
                type: 'charge',
                insert_datetime: moment().format("X")
            };
            write.query(`INSERT INTO tbl_category_service SET ?`, insertData, function(err, result) {
                if (!err) {
                    insertData.id = result.insertId
                    resolve(insertData)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Check | Uncheck Service Price                          /////
    //////////////////////////////////////////////////////////////////////////////////////////
    check_uncheck_service_price: function(params) {
        return new Promise((resolve,reject)=>{
            if(params.charge_ids){
                write.query(`UPDATE tbl_category_service SET is_check = 'true' WHERE id IN (${params.charge_ids})`,(err,result)=>{
                    if(!err){
                        write.query(`UPDATE tbl_category_service SET is_check = 'false' WHERE id NOT IN (${params.charge_ids}) AND user_id = ${params.login_user_id} AND sub_category_id = ${params.sub_category_id}`,(uErr,uResult)=>{
                            resolve(1)
                        })
                    }else{
                        reject(0)
                    }
                })
            }else{
                write.query(`UPDATE tbl_category_service SET is_check = 'false' WHERE user_id = ${params.login_user_id} AND sub_category_id = ${params.sub_category_id}`,(uErr,uResult)=>{
                    resolve(1)
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Edit Service & Price                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    edit_service_price: function(params) {
        return new Promise((resolve,reject)=>{
            let updateData = {
                service_name: params.service_name,
                price: params.price,
                update_datetime: moment().format("X")
            };
            write.query(`UPDATE tbl_category_service SET ? WHERE id = ?`, [updateData, params.id], function(err, result) {
                if (!err) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Delete Service & Price                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    delete_service_price: function(params) {
        return new Promise((resolve,reject)=>{
            // `DELETE FROM tbl_category_service WHERE id = '${params.id}' AND user_id = '${params.login_user_id}'`
            write.query(`UPDATE tbl_category_service SET is_active = '0' WHERE id = '${params.id}' AND user_id = '${params.login_user_id}'`, (err, result) => {
                if (!err && result != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Add User Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_user_service: function(params) {
        return new Promise((resolve,reject)=>{
            if(params.filter_ids){
                let deleteService = []
                asyncLoop(params.filter_ids.split(','), (item,next) => {
                    read.query(`SELECT id FROM tbl_category_service WHERE sub_category_id = '${params.sub_category_id}' AND service_name IN ('${item}','') AND user_id = '${params.login_user_id}'`, (err,result) => {
                        let data = {
                            sub_category_id: params.sub_category_id,
                            user_id: params.login_user_id,
                            type: 'filter',
                            service_name: item
                        }
                        if(!err && result[0] != undefined) {
                            data.update_datetime = moment().format("X")
                            write.query(`UPDATE tbl_category_service SET ? WHERE id = '${result[0].id}'`, data, (uErr,uResult) => {
                                deleteService.push(result[0].id)
                                next()
                            })
                        } else {
                            data.insert_datetime = moment().format("X")
                            write.query(`INSERT INTO tbl_category_service SET ?`, data, (iErr, iResult) => {
                                deleteService.push(iResult.insertId)
                                next()
                            })
                        }
                    })
                },()=>{
                    write.query(`DELETE FROM tbl_category_service WHERE sub_category_id = '${params.sub_category_id}' AND user_id = '${params.login_user_id}' AND id NOT IN (${deleteService}) AND type != 'charge'`, (dErr,dResult) => {
                        if(!dErr) {
                            resolve(null)
                        } else {
                            reject(null)
                        }
                    })
                })
            }else{
                resolve();
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Manage Service                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    manage_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id,name FROM tbl_category WHERE is_active = '1' AND parent_id = '0' ORDER BY name LIMIT ${parseInt(params.page_token)*parseInt(GLOBALS.PER_PAGE)},${GLOBALS.PER_PAGE}`, (err, result) => {
                if (!err) {
                    read.query(`SELECT sub_category_id FROM tbl_category_service WHERE user_id = '${params.login_user_id}' GROUP BY sub_category_id`, (sErr,sResult) => {
                        let sub_category_id = (sResult[0]) ? sResult.map(x=>x.sub_category_id) : 0;
						// let sub_category_id = (sResult[0] && sResult[0].sub_category_id) ? ((sResult[0].sub_category_id.charAt(sResult[0].sub_category_id.length - 1) == ',') ? sResult[0].sub_category_id.slice(0,-1) : sResult[0].sub_category_id) : 0
                        if(sub_category_id != 0){
                            let select = (params.user_id) ? `,IF(IFNULL(cs.id,1) = 1,'false','true') AS is_check` : ``
                            let join = (params.user_id) ? `LEFT JOIN tbl_category_service AS cs ON cs.sub_category_id = c.id AND cs.user_id = ${params.user_id}` : ``
                            asyncLoop(result, (item,next) => {
                                if(item != undefined){
                                    read.query(`SELECT c.id,c.name${select} FROM tbl_category AS c ${join} WHERE c.id IN (${sub_category_id}) AND c.parent_id = '${item.id}' AND c.is_active = '1'`, (scErr,scResult) => {
                                        item.list = (!scErr && scResult[0] != undefined) ? scResult : []
                                        next()
                                    })
                                }else{
                                    next()
                                }
                            }, () => {
                                resolve({page_token:parseInt(params.page_token)+1,result:result})
                            })
                        }else{
                            resolve({page_token:parseInt(params.page_token)+1,result:result})
                        }
                    })
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Add Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_service: function(params) {
        return new Promise((resolve,reject)=>{
            let finalInsert = []
            read.query(`SELECT f.user_id,u.current_language FROM tbl_user_favorite_unfavorite AS f JOIN tbl_user AS u ON u.id = f.user_id WHERE f.provider_id = ${params.login_user_id} AND f.type = 'Favorite'`,(fErr,fResult)=>{
                asyncLoop(params.sub_category_id.split(','),(item,next)=>{
                    finalInsert.push([item,params.login_user_id,'filter',moment().format("X")])
                    this.send_category_notification(fResult,params.login_user_id,item)
                    next()
                },()=>{
                    write.query(`INSERT INTO tbl_category_service(sub_category_id,user_id,type,insert_datetime) VALUES ?`, [finalInsert], function(err, result) {
                        if (!err) {
                            resolve(1)
                        } else {
                            reject(0)
                        }
                    }) 
                })
            })
        })
    },
    async send_category_notification(senders,provider_id,sub_category_id){
        if(senders[0] != undefined){
            read.query(`SELECT name FROM tbl_category WHERE id = ${sub_category_id} LIMIT 1`,(cErr,cResult)=>{
                read.query(`SELECT CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE id = ${provider_id} LIMIT 1`,(err,result)=>{
                    asyncLoop(senders,(item,next)=>{
                        var push_data = {
                            title: lang[item.current_language]['text_category_added_title'].replace('{sp_name}',result[0].sp_name),
                            body: lang[item.current_language]['text_category_added_body'].replace('{service_name}',cResult[0].name),
                            custom: {
                                tag: "new_service_added",
                                provider_id: provider_id
                            }
                        }
                        var push_notification = {
                            sender_id: provider_id,
                            receiver_id: item.user_id,
                            action_id: provider_id,
                            message: JSON.stringify({title:'text_category_added_title',body:'text_category_added_body',sub_category_id:sub_category_id}),
                            tag: 'new_service_added',
                            insert_datetime: moment().format("X")
                        }
                        common.prepare_notification(item.user_id,push_data)
                        common.add_data('tbl_notification',push_notification,(res)=>{})
                        next();
                    },()=>{});
                })
            })
        }
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Delete Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    delete_service: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`DELETE FROM tbl_category_service WHERE sub_category_id = '${params.sub_category_id}' AND user_id = '${params.login_user_id}'`, (err, result) => {
                if (!err && result != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 Add Offer                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_offer: function(params) {
        return new Promise((resolve,reject)=>{
            if(params.id){
                let updateData = {
                    user_id: params.login_user_id,
                    title: params.title,
                    category_id: params.category_id,
                    start_date: params.start_date,
                    end_date: params.end_date,
                    discount: params.discount,
                    description: params.description,
                    update_datetime: moment().format("X")
                };
                write.query(`UPDATE tbl_offer SET ? WHERE id = ${params.id}`, updateData, function(err, result) {
                    if (!err) {
                        resolve(3)
                    } else {
                        reject(3)
                    }
                })
            }else{
                let insertData = {
                    added_by: 'provider',
                    user_id: params.login_user_id,
                    title: params.title,
                    category_id: params.category_id,
                    start_date: params.start_date,
                    end_date: params.end_date,
                    discount: params.discount,
                    ...(params.description) && {description: params.description},
                    insert_datetime: moment().format("X")
                };
                write.query(`INSERT INTO tbl_offer SET ?`, insertData, function(err, result) {
                    if (!err) {
                        read.query(`SELECT current_language, CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE id = ${params.login_user_id} LIMIT 1`,(uErr,uResult)=>{
                            var push_data = {
                                title: lang[uResult[0].current_language]['text_offer_added_title'].replace('{sp_name}',uResult[0].sp_name),
                                body: lang[uResult[0].current_language]['text_offer_added_body'],
                                custom: {
                                    tag: 'offer_added',
                                    offer_id: result.insertId,
                                }
                            }
                            var push_notification = {
                                sender_id: 0,
                                receiver_id: params.login_user_id,
                                action_id: result.insertId,
                                message: JSON.stringify({title:'text_offer_added_title',body:'text_offer_added_body'}),
                                tag: 'offer_added',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(params.login_user_id,push_data)
                            common.add_data('tbl_notification',push_notification,(res)=>{})
                            resolve(1)
                        })
                    } else {
                        reject(0)
                    }
                })
            }
        })
    },
    async check_offer_unique(title){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id FROM tbl_offer WHERE LOWER(title) = LOWER('${title}') LIMIT 1`,(err,result)=>{
                if(!err && result[0] != undefined){
                    reject();
                }else{
                    resolve();
                }
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  My Offer                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    my_offer: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT o.id,o.title,o.category_id,c.name,o.start_date,o.end_date,o.discount,o.description,o.insert_datetime FROM tbl_offer AS o JOIN tbl_category AS c ON c.id = o.category_id WHERE o.is_active = '1' AND o.user_id = ${params.login_user_id} AND o.added_by = 'provider' ORDER BY o.id DESC LIMIT ${parseInt(params.page_token)*parseInt(GLOBALS.PER_PAGE)},${GLOBALS.PER_PAGE}`, (err, result) => {
                if (!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Delete Offer                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    delete_offer: function(params) {
        return new Promise((resolve,reject)=>{
            write.query(`DELETE FROM tbl_offer WHERE id = '${params.id}' AND user_id = '${params.login_user_id}'`, (err, result) => {
                if (!err && result != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Set Availability                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    set_available: function(params) {
        return new Promise((resolve,reject)=>{
            if(params.type == "AD" || params.type == "BD"){
                read.query(`SELECT * FROM tbl_availability WHERE type IN ('AD','BD') AND (start_date BETWEEN '${params.start_date}' AND '${params.end_date}' OR end_date BETWEEN '${params.start_date}' AND '${params.end_date}') AND user_id = ${params.login_user_id}`,(sErr,sResult)=>{
                    if(!sErr && sResult[0] != undefined){
                        let insertData = {
                            user_id: params.login_user_id,
                            type: params.type,
                            start_date: params.start_date,
                            end_date: params.end_date,
                            start_time: params.start_time,
                            end_time: params.end_time,
                            insert_datetime: moment().format('X')
                        }
                        write.query(`INSERT INTO tbl_availability SET ?`, insertData, (err, result) => {
                            if (!err && result != undefined) {
                                write.query(`DELETE FROM tbl_availability WHERE id IN (${sResult.map(x=>x.id)})`);
                                resolve(result)
                            } else {
                                reject(null)
                            }
                        })
                    }else{
                        let insertData = {
                            user_id: params.login_user_id,
                            type: params.type,
                            start_date: params.start_date,
                            end_date: params.end_date,
                            start_time: params.start_time,
                            end_time: params.end_time,
                            insert_datetime: moment().format('X')
                        }
                        write.query(`INSERT INTO tbl_availability SET ?`, insertData, (err, result) => {
                            if (!err && result != undefined) {
                                resolve(result)
                            } else {
                                reject(null)
                            }
                        })
                    }
                })
            }else{
                let enter_start_date = new Date(params.start_date)
                let enter_end_date = new Date(params.end_date)
                read.query(`SELECT * FROM tbl_availability WHERE type = '${params.type}' AND (start_date BETWEEN '${params.start_date}' AND '${params.end_date}' OR end_date BETWEEN '${params.start_date}' AND '${params.end_date}') AND user_id = ${params.login_user_id}`,(sErr,sResult)=>{
                    if(!sErr && sResult[0] != undefined){
                        var insertData = []
                        var first_row_start_date = new Date(sResult[0].start_date)
                        var last_row_end_date = new Date(sResult[sResult.length - 1].end_date)
                        if(first_row_start_date < enter_start_date){
                            var days = home.getDifferenceInDays(first_row_start_date,enter_start_date) - 1
                            first_row_start_date.setDate(first_row_start_date.getDate()+days)
                            // console.log(sResult[0].start_date, first_row_start_date, sResult[0].start_time, sResult[0].end_time)
                            insertData.push([ params.login_user_id, params.type,
                                sResult[0].start_date, first_row_start_date,
                                sResult[0].start_time, sResult[0].end_time,
                                moment().format('X')
                            ])
                        }
                        // console.log(params.start_date, params.end_date, params.start_time, params.end_time)
                        insertData.push([ params.login_user_id, params.type,
                            params.start_date, params.end_date,
                            params.start_time, params.end_time,
                            moment().format('X')
                        ])
                        if(last_row_end_date > enter_end_date){
                            enter_end_date.setDate(enter_end_date.getDate()+1)
                            // console.log(enter_end_date, sResult[sResult.length - 1].end_date, sResult[sResult.length - 1].start_time, sResult[sResult.length - 1].end_time)
                            insertData.push([ params.login_user_id, params.type,
                                enter_end_date, sResult[sResult.length - 1].end_date,
                                sResult[sResult.length - 1].start_time, sResult[sResult.length - 1].end_time,
                                moment().format('X')
                            ])
                        }
                        write.query(`INSERT INTO tbl_availability(user_id,type,start_date,end_date,start_time,end_time,insert_datetime) VALUES ?`, [insertData], (err, result) => {
                            if (!err && result != undefined) {
                                write.query(`DELETE FROM tbl_availability WHERE id IN (${sResult.map(x=>x.id)})`);
                                resolve()
                            } else {
                                reject(null)
                            }
                        })
                    }else{
                        let insertData = {
                            user_id: params.login_user_id,
                            type: params.type,
                            start_date: params.start_date,
                            end_date: params.end_date,
                            start_time: params.start_time,
                            end_time: params.end_time,
                            insert_datetime: moment().format('X')
                        }
                        write.query(`INSERT INTO tbl_availability SET ?`, insertData, (err, result) => {
                            if (!err && result != undefined) {
                                resolve(result)
                            } else {
                                reject(null)
                            }
                        })
                    }
                })
            }
        })
    },
    getDifferenceInDays(date1,date2){
        const diffInMs = Math.abs(date2 - date1);
        return diffInMs / (1000 * 60 * 60 * 24);
    },
    set_availability_one_slot: function(params) {
        return new Promise((resolve,reject)=>{
            let insertData = {
                user_id: params.login_user_id,
                type: params.type,
                start_date: params.start_date,
                end_date: params.end_date,
                start_time: params.start_time,
                end_time: params.end_time,
                insert_datetime: moment().format('X')
            }
            write.query(`INSERT INTO tbl_availability SET ?`, insertData, (err, result) => {
                if (!err && result != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Get Availability Time Slot                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_available_time_slot: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, type, TIME_FORMAT(start_time,'%H:%i') AS start_time, insert_datetime FROM tbl_availability WHERE type IN ('AD','BD') AND user_id = ${params.login_user_id} AND start_date <= '${params.date}' AND end_date >= '${params.date}' ORDER BY id DESC LIMIT 1`,(err, result)=>{
                if (!err && result[0] != undefined) {
                    read.query(`SELECT TIME_FORMAT(time,'%H:%i') AS time FROM tbl_booking WHERE provider_id = ${params.login_user_id} AND date = '${params.date}' AND status IN ('accepted')`,(bErr,bResult)=>{
                        bResult = (bResult[0] != undefined) ? bResult.map(x=>x.time) : []
                        let alltimesolt = []
                        let dType = result[0].type
                        let timesolt = common.get_all_time_slot();
                        asyncLoop(timesolt,(item,next)=>{
                            let type = (result[0].type == "AD") ? `A` : `U`
                            read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND insert_datetime >= '${result[0].insert_datetime}' AND user_id = ${params.login_user_id} AND start_date <= '${params.date}' AND end_date >= '${params.date}' AND start_time <= '${item}' AND end_time >= '${item}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                                if(!cErr && cResult[0] != undefined){
                                    type = cResult[0].type
                                    type = (bResult.includes(item)) ? 'B' : type
                                    dType = (bResult.includes(item) && dType != 'B') ? 'B' : dType
                                    alltimesolt.push({time:item,type:type})
                                    next()
                                }else{
                                    type = (bResult.includes(item)) ? 'B' : type
                                    dType = (bResult.includes(item) && dType != 'B') ? 'B' : dType
                                    alltimesolt.push({time:item,type:type})
                                    next()
                                }
                            })
                        },()=>{
                            resolve({timesolt:alltimesolt,type:dType})
                        })
                    })
                } else {
                    let alltimesolt = []
                    let dType = 'U'
                    let timesolt = common.get_all_time_slot();
                    read.query(`SELECT TIME_FORMAT(time,'%H:%i') AS time FROM tbl_booking WHERE provider_id = ${params.login_user_id} AND date = '${params.date}' AND status IN ('accepted')`,(bErr,bResult)=>{
                        bResult = (bResult[0] != undefined) ? bResult.map(x=>x.time) : []
                        asyncLoop(timesolt,(item,next)=>{
                            var type = 'U'
                            read.query(`SELECT type FROM tbl_availability WHERE type IN ('A','U') AND user_id = ${params.login_user_id} AND start_date <= '${params.date}' AND end_date >= '${params.date}' AND start_time <= '${item}' AND end_time >= '${item}' ORDER BY id DESC LIMIT 1`,(cErr,cResult)=>{
                                if(!cErr && cResult[0] != undefined){
                                    type = cResult[0].type
                                    type = (bResult.includes(item)) ? 'B' : type
                                    dType = (bResult.includes(item) && dType != 'B') ? 'B' : dType
                                    alltimesolt.push({time:item,type:type})
                                    next()
                                }else{
                                    type = (bResult.includes(item)) ? 'B' : type
                                    dType = (bResult.includes(item) && dType != 'B') ? 'B' : dType
                                    alltimesolt.push({time:item,type:type})
                                    next()
                                }
                            })
                        },()=>{
                            resolve({timesolt:alltimesolt,type:dType})
                        })
                    })
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Get Availability Month Slot                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async get_available_month_slot(params) {
        return new Promise((resolve,reject)=>{
            var array = common.get_all_month_date_slot(params.start_date,params.end_date);
            var slotArray = []
            asyncLoop(array,(item,next)=>{
                home.get_available_time_slot({login_user_id:params.login_user_id,date:item}).then((resTimeSlot)=>{
                    slotArray.push({
                        date: item,
                        type: resTimeSlot.type,
                        time: resTimeSlot.timesolt
                    })
                    next()
                })
            },()=>{
                resolve(slotArray)
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                My Service                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    my_service: function(params) {
        return new Promise((resolve,reject)=>{
            let where = ``
            let order_by = `ORDER BY b.insert_datetime DESC, b.date, b.time`
            if(params.status == "today"){
                where = `AND date = CURRENT_DATE() AND status NOT IN ('completed','cancelled')`
            }else if(params.status == "upcoming"){
                where = `AND date != CURRENT_DATE() AND status IN ('${params.status}','accepted','running')`
            }else if(params.status == "completed"){
                order_by = `ORDER BY b.update_datetime DESC, b.date, b.time`
                where = `AND status = '${params.status}'`
            }else{
                where = `AND status = '${params.status}'`
            }
            if(params.status == "cancelled"){
                order_by = `ORDER BY b.update_datetime DESC`
            }
            read.query({sql:`SELECT b.id, b.order_id, b.date, b.time, b.user_id, b.provider_id, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',p.profile_image) AS profile_image_provider, p.first_name AS first_name_provider, p.last_name AS last_name_provider, b.type, b.address, b.service_ids, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, b.total_amount, b.total_gst, b.final_amount, b.status, b.is_auto_reject, b.cancel_by FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_user AS p ON p.id = b.provider_id WHERE b.provider_id IN (${params.login_user_id}) ${where} ${order_by} LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`,
                typeCast:(field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string();
                    }
                    return next();
                },
            },(err,result)=>{
                if (!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        home.get_cart_service(item.service_ids).then((resService)=>{
                            item.main_category_id = (resService.main) ? resService.main.id : ``
                            item.main_category_name = (resService.main) ? resService.main.name : ``
                            item.sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                            item.sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                            item.services = resService.result
                            item.address = (item.address) ? JSON.parse(item.address) : {}
                            next()
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result})
                    })
                } else {
                    reject(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           My Service Details                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    my_service_details: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.order_id, b.date, b.time, b.user_id, b.provider_id, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',p.profile_image) AS profile_image_provider, p.first_name AS first_name_provider, p.last_name AS last_name_provider, b.type, b.description, b.address, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, b.service_ids, b.total_amount, b.discount_amount, b.final_amount, b.payment_type, b.status, b.cancel_by, b.insert_datetime,b.total_gst FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_user AS p ON p.id = b.provider_id WHERE b.id = ${params.id} LIMIT 1`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    home.get_cart_service(result[0].service_ids).then((resService)=>{
                        home.get_additional_cost(result[0].id).then((resAdditionalCost)=>{
                            result[0].main_category_id = (resService.main) ? resService.main.id : ``
                            result[0].main_category_name = (resService.main) ? resService.main.name : ``
                            result[0].sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                            result[0].sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                            result[0].services = resService.result
                            result[0].additional_cost = resAdditionalCost
                            result[0].address = (result[0].address) ? JSON.parse(result[0].address) : {}
                            resolve(result[0])
                        })
                    })
                } else {
                    reject(false)
                }
            })
        })
    },
    async get_additional_cost(booking_id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT additional_id,status,payment_mode,payment_status FROM tbl_booking_additional_cost WHERE booking_id = '${booking_id}' AND status != 'reject' GROUP BY additional_id`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        read.query(`SELECT id,name,value,sgst_amount,cgst_amount,igst_amount,total_gst FROM tbl_booking_additional_cost WHERE status != 'reject' AND booking_id = '${booking_id}' AND additional_id = '${item.additional_id}'`,(cErr,cResult)=>{
                            home.get_additional_cost_images(booking_id,item.additional_id).then((resAdditionalCostImages)=>{
                                item.costs = cResult
                                item.images = resAdditionalCostImages
                                next()
                            })
                        })
                    },()=>{
                        resolve(result)
                    })
                }else{
                    resolve([])
                }
            })
        })
    },
    async get_additional_cost_images(booking_id,additional_id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT CONCAT('${GLOBALS.S3_URL+GLOBALS.COST_IMAGE}',image) AS image FROM tbl_booking_additional_cost_images WHERE booking_id = '${booking_id}' AND additional_id = '${additional_id}'`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve(result)
                }else{
                    resolve([])
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Get Cart Service                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_cart_service: function(service_ids) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT cs.id, cs.sub_category_id, c.name AS sub_category_name, cs.service_name, cs.price, c.sac_code FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id WHERE cs.id IN (${service_ids})`, (err, result) => {
                if (!err) {
                    read.query(`SELECT s.id, s.name FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id JOIN tbl_category AS s ON s.id = c.parent_id WHERE cs.id IN (${service_ids}) LIMIT 1`, (mErr, mResult) => {
                        resolve({result:result,main:mResult[0]})
                    })
                } else {
                    resolve(false)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Service Action                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    service_action: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.user_id, b.order_id, u.current_language, b.status, b.payment_type, b.transaction_id, b.final_amount FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE b.provider_id = ${params.login_user_id} AND b.id = ${params.booking_id}`, (err, result) => {
                if (!err && result[0] != undefined) {
                    if(result[0].status == "pending"){
                        let updateData = {
                            status: params.action,
                            update_datetime: moment().format("X")
                        }
                        // if(params.action == "cancelled"){
                        //     updateData.cancel_by = 'provider';
                        // }
                        write.query(`UPDATE tbl_booking SET ? WHERE id = ${result[0].id}`,updateData,(uErr,uResult)=>{
                            if(!uErr && uResult != undefined){
                                if(result[0].payment_type == "card" && params.action == "cancelled"){
                                    common.razorpay_refund(result[0].transaction_id,result[0].final_amount,`Booking Id #${result[0].order_id}`).catch((error)=>{});
                                }
                                write.query(`UPDATE tbl_user SET total_reject = (SELECT COUNT(id) FROM tbl_booking WHERE provider_id = ${params.login_user_id} AND status = 'cancelled' AND cancel_by == '') WHERE id = ${params.login_user_id}`);
                                var title = (params.action == "cancelled") ? lang[result[0].current_language]['text_booking_not_accepted_title'].replace('{order_id}',result[0].order_id) : lang[result[0].current_language]['text_booking_accepted_title'].replace('{order_id}',result[0].order_id)
                                var body = (params.action == "cancelled") ? lang[result[0].current_language]['text_booking_not_accepted_body'] : lang[result[0].current_language]['text_booking_accepted_body'].replace('{order_id}',result[0].order_id)
    
                                var ptitle = (params.action == "cancelled") ? `text_booking_not_accepted_title` : `text_booking_accepted_title`
                                var pbody = (params.action == "cancelled") ? `text_booking_not_accepted_body` : `text_booking_accepted_body`
    
                                var tag = (params.action == "cancelled") ? `booking_rejected` : `booking_accepted`
    
                                var push_data = {
                                    title: title,
                                    body: body,
                                    custom: {
                                        tag: tag,
                                        order_id: result[0].order_id,
                                        booking_id: result[0].id
                                    }
                                }
                                var push_notification = {
                                    sender_id: params.login_user_id,
                                    receiver_id: result[0].user_id,
                                    action_id: result[0].id,
                                    message: JSON.stringify({title:ptitle,body:pbody}),
                                    tag: tag,
                                    insert_datetime: moment().format("X")
                                }
                                if(params.action == 'cancelled'){
                                    this.credit_note_invoice({id:params.booking_id});
                                }
                                common.prepare_notification(result[0].user_id,push_data)
                                common.add_data('tbl_notification',push_notification,(res)=>{})
                                resolve({code:1})
                            }else{
                                reject()
                            }
                        })
                    }else{
                        resolve({code:2,status:result[0].status})
                    }
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Cancel Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    cancel_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.status, b.order_id, b.user_id, b.provider_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS name, b.payment_type, b.transaction_id, b.final_amount FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE b.provider_id = ${params.login_user_id} AND b.id = ${params.id} LIMIT 1`,(err,result)=>{
                if (!err && result[0] != undefined) {
                    if(["running","completed","cancelled"].indexOf(result[0].status) !== -1){
                        resolve({code:"0",status:result[0].status})
                    }else{
                        let updateData = {
                            cancel_by: 'provider',
                            status: 'cancelled',
                            cancel_reason: params.reason,
                            ...(params.comment) && {cancel_comment:params.comment},
                            update_datetime: moment().format("X")
                        }
                        write.query(`UPDATE tbl_booking SET ? WHERE id = ${params.id}`, updateData, (uErr,uResult)=>{
                            if(!uErr && uResult != undefined){
                                if(result[0].payment_type == "card"){
                                    common.razorpay_refund(result[0].transaction_id,result[0].final_amount,`Booking Id #${result[0].order_id}`).catch((error)=>{});
                                }
                                write.query(`UPDATE tbl_user SET total_cancelled = (SELECT COUNT(id) FROM tbl_booking WHERE provider_id = ${params.login_user_id} AND status = 'cancelled' AND cancel_by != '') WHERE id = ${params.login_user_id}`);
                                var push_data = {
                                    title: lang[result[0].current_language]['text_booking_cancelled_provider_title'].replace('{sp_name}',result[0].name),
                                    body: lang[result[0].current_language]['text_booking_cancelled_provider_body'].replace('{order_id}',result[0].order_id),
                                    custom: {
                                        tag: "booking_cancelled",
                                        order_id: result[0].order_id,
                                        booking_id: result[0].id
                                    }
                                }
                                var push_notification = {
                                    sender_id: params.login_user_id,
                                    receiver_id: result[0].user_id,
                                    action_id: result[0].id,
                                    message: JSON.stringify({title:'text_booking_cancelled_provider_title',body:'text_booking_cancelled_provider_body'}),
                                    tag: 'booking_cancelled',
                                    insert_datetime: moment().format("X")
                                }
                                this.credit_note_invoice(params);
                                common.prepare_notification(result[0].user_id,push_data)
                                common.add_data('tbl_notification',push_notification,(res)=>{})
                                resolve(uResult)
                            }else{
                                reject(false)
                            }
                        })
                    }
                } else {
                    reject(false)
                }
            })
        })
    },
    async send_notification_reject_booking(booking_id,order_id,provider_id){
        read.query(`SELECT s.parent_id, CONCAT(s.first_name,' ',s.last_name) AS name, s.current_language AS staff_sp_lang, CONCAT(m.first_name,' ',m.last_name) AS sp_name, m.current_language AS main_sp_lang FROM tbl_user AS s LEFT JOIN tbl_user AS m ON m.id = s.parent_id WHERE s.id = ${provider_id} LIMIT 1`,(err,result)=>{
            if(!err && result[0] != undefined){
                if(result[0].parent_id != 0){
                    var push_data = {
                        title: lang[result[0].current_language]['text_booking_cancelled_by_staff_title'],
                        body: lang[result[0].current_language]['text_booking_cancelled_by_staff_body'].replace('{order_id}',order_id).replace('{name}',result[0].name).replace('{staff_id}',provider_id),
                        custom: {
                            tag: "booking_cancelled_by_staff",
                            order_id: order_id,
                            booking_id: booking_id
                        }
                    }
                    var push_notification = {
                        sender_id: provider_id,
                        receiver_id: result[0].parent_id,
                        action_id: booking_id,
                        message: JSON.stringify({title:'text_booking_cancelled_by_staff_title',body:'text_booking_cancelled_by_staff_body'}),
                        tag: 'booking_cancelled_by_staff',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(result[0].parent_id,push_data)
                    common.add_data('tbl_notification',push_notification,(res)=>{})
                }
            }
        })
    },
    async credit_note_invoice(params){
        read.query(`SELECT b.id,b.order_id,b.date,b.invoice_number,b.advance_receipt_number,b.place_to_supply,b.place_to_delivery,b.sgst,b.cgst,b.igst,b.sgst_amount,b.cgst_amount,b.igst_amount,p.first_name AS first_name_provider,p.last_name AS last_name_provider,p.parent_id,b.provider_id,p.region_location,p.region_zipcode,b.type,b.address,u.first_name,u.last_name,u.email,b.service_ids,b.total_amount,b.discount_amount,b.final_amount,b.payment_type,b.total_gst FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_user AS p ON p.id = b.provider_id WHERE b.id = ${params.id} LIMIT 1`,(err,result)=>{
            if (!err && result[0] != undefined) {
                home.get_cart_service(result[0].service_ids).then((resService)=>{
                    home.get_additional_cost(result[0].id).then((resAdditionalCost)=>{
                        read.query(`SELECT gst,commission,flat FROM tbl_user WHERE id = ${((result[0].parent_id == 0) ? result[0].provider_id : result[0].parent_id)} LIMIT 1`,(sErr,sResult)=>{
                            read.query(`SELECT name FROM tbl_user_document WHERE user_id = ${((result[0].parent_id == 0) ? result[0].provider_id : result[0].parent_id)} AND type = 'pan_number' LIMIT 1`,(spErr,spResult)=>{
                                read.query(`SELECT tin_number FROM tbl_state_code WHERE state_name = '${result[0].place_to_delivery}' LIMIT 1`,(stateErr,stateResult)=>{
                                    result[0].services = resService.result
                                    result[0].additional_cost = resAdditionalCost
                                    result[0].address = (result[0].address) ? JSON.parse(result[0].address) : {}
                                    var services = ``;
                                    var num = 1;
                                    let sac_code = ``;
                                    result[0].services.map(element => {
                                        sac_code = element.sac_code
                                        element.price = ((element.price * 100) / (100 + (parseFloat(result[0].sgst) + parseFloat(result[0].cgst) + parseFloat(result[0].igst)))).toFixed(2);
                                        services += 
                                        `<tr>`+
                                            `<td style="border: 1px solid #ccc"><b>${num}</b></td>`+
                                            `<td style="border: 1px solid #ccc">${element.service_name}</td>`+
                                            `<td style="border: 1px solid #ccc">${element.sac_code}</td>`+
                                            `<td style="border: 1px solid #ccc">inr ${element.price}</td>`+
                                            `<td style="border: 1px solid #ccc">1</td>`+
                                            `<td style="border: 1px solid #ccc">inr ${element.price}</td>`+
                                        `</tr>`;
                                        num++;
                                    });
                                    result[0].additional_cost.map(element => {
                                        if(element.status == "accept"){
                                            element.costs.map(element1 => {
                                                result[0].total_amount += element1.value;
                                                result[0].final_amount += parseFloat(element1.value) + parseFloat(element1.total_gst);
                                                result[0].sgst_amount += parseFloat(element1.sgst_amount);
                                                result[0].cgst_amount += parseFloat(element1.cgst_amount);
                                                result[0].igst_amount += parseFloat(element1.igst_amount);
                                                services += 
                                                `<tr>`+
                                                    `<td style="border: 1px solid #ccc"><b>${num}</b></td>`+
                                                    `<td style="border: 1px solid #ccc">${element1.name}</td>`+
                                                    `<td style="border: 1px solid #ccc">${sac_code}</td>`+
                                                    `<td style="border: 1px solid #ccc">inr ${element1.value}</td>`+
                                                    `<td style="border: 1px solid #ccc">1</td>`+
                                                    `<td style="border: 1px solid #ccc">inr ${element1.value}</td>`+
                                                `</tr>`;
                                                num++;
                                            });
                                        }
                                    });
                                    let discount = ``;
                                    if(result[0].discount_amount != 0){
                                        discount = `<tr>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc"><b>discount amount</b></td>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc">inr ${result[0].discount_amount}</td>`+
                                        `</tr>`;
                                    }
                                    var credit_note_invoice = {
                                        invoice_number: result[0].invoice_number,
                                        invoice_date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        supplier_name: `${result[0].first_name_provider} ${result[0].last_name_provider}`,
                                        billing_name: `${result[0].first_name} ${result[0].last_name}`,
                                        supplier_place: result[0].region_location,
                                        region_zipcode: result[0].region_zipcode,
                                        billing_place: (result[0].type == "home_visit") ? result[0].address.location : result[0].location,
                                        billing_zipcode: (result[0].type == "home_visit") ? result[0].address.pincode : result[0].region_zipcode,
                                        date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        pan_number: spResult[0].name,
                                        gst_number: sResult[0].gst,
                                        booking_id: result[0].id,
                                        order_id: result[0].order_id,
                                        booking_date: moment(result[0].date).format("DD/MM/YYYY"),
                                        advance_receipt_number: result[0].advance_receipt_number,
                                        state_code: (!stateErr && stateResult[0] != undefined) ? stateResult[0].tin_number : ``,
                                        place_supply: result[0].place_to_supply,
                                        services: services,
                                        net_amount: result[0].total_amount,
                                        discount: discount,
                                        cgst: result[0].cgst,
                                        cgst_amount: result[0].cgst_amount.toFixed(2),
                                        sgst: result[0].sgst,
                                        sgst_amount: result[0].sgst_amount.toFixed(2),
                                        igst: result[0].igst,
                                        igst_amount: result[0].igst_amount.toFixed(2),
                                        total_amount: (parseFloat(result[0].final_amount)).toFixed(2),
                                        total_amount_in_word: (toWords.convert((parseFloat(result[0].final_amount)).toFixed(2))).toLowerCase(),
                                        invoice_link: ``,
                                        rcm: (sResult[0].gst == '') ? 'yes' : 'no'
                                    }
                                    template.credit_note_to_customer(credit_note_invoice,(html)=>{
                                        htmlpdf.create(html,{format:'A4'}).toStream((errInvoice,resInvoice)=>{
                                            s3.upload({
                                                Bucket: GLOBALS.S3_BUCKET_NAME,
                                                Key: `invoice/credit-note-${result[0].invoice_number}.pdf`,
                                                ACL: "public-read",
                                                Body: resInvoice
                                            },(errS3,resS3)=>{
                                                credit_note_invoice.invoice_link = `<a href="${resS3.Location}">Click Here To Download Invoice</a>`;
                                                template.credit_note_to_customer(credit_note_invoice,(html)=>{
                                                    common.send_email(GLOBALS.APP_NAME + " <"+GLOBALS.EMAIL_ID+">",`Credit Note Invoice For ${result[0].order_id} from EASSY INNOVATIVE SERVICES PRIVATE LIMITED`,result[0].email,html,(resEmail)=>{});
                                                });
                                            });
                                        });
                                    });
                                })
                            })
                        })
                    })
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Start Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    start_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.user_id, b.order_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE b.provider_id = ${params.login_user_id} AND b.id = ${params.booking_id} AND b.status = 'accepted' AND b.start_service_otp = '${params.otp}'`, (err, result) => {
                if (!err && result[0] != undefined) {
                    write.query(`UPDATE tbl_booking SET start_service_time = '${moment().format("X")}', status = 'running' WHERE id = ${result[0].id}`);
                    var push_data = {
                        title: lang[result[0].current_language]['text_booking_started_title'].replace('{sp_name}',result[0].sp_name),
                        body: lang[result[0].current_language]['text_booking_started_body'].replace('{order_id}',result[0].order_id),
                        custom: {
                            tag: "booking_started",
                            order_id: result[0].order_id,
                            booking_id: result[0].id
                        }
                    }
                    var push_notification = {
                        sender_id: params.login_user_id,
                        receiver_id: result[0].user_id,
                        action_id: result[0].id,
                        message: JSON.stringify({title:'text_booking_started_title',body:'text_booking_started_body'}),
                        tag: 'booking_started',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(result[0].user_id,push_data)
                    common.add_data('tbl_notification',push_notification,(res)=>{})
                    resolve()
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                 End Service                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    end_service: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id, b.user_id, b.order_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE b.provider_id = ${params.login_user_id} AND b.id = ${params.booking_id} AND b.status = 'running' AND b.end_service_otp = '${params.otp}'`, (err, result) => {
                if (!err && result[0] != undefined) {
                    write.query(`UPDATE tbl_booking SET end_service_time = '${moment().format("X")}', status = 'completed' WHERE id = ${result[0].id}`);
                    write.query(`UPDATE tbl_user SET total_completed = (SELECT COUNT(id) FROM tbl_booking WHERE provider_id = ${params.login_user_id} AND status = 'completed') WHERE id = ${params.login_user_id}`);
                    this.invoice_send(params);
                    var push_data = {
                        title: lang[result[0].current_language]['text_booking_ended_title'].replace('{sp_name}',result[0].sp_name),
                        body: lang[result[0].current_language]['text_booking_ended_body'].replace('{order_id}',result[0].order_id),
                        custom: {
                            tag: "booking_ended",
                            order_id: result[0].order_id,
                            booking_id: result[0].id
                        }
                    }
                    var push_notification = {
                        sender_id: params.login_user_id,
                        receiver_id: result[0].user_id,
                        action_id: result[0].id,
                        message: JSON.stringify({title:'text_booking_ended_title',body:'text_booking_ended_body'}),
                        tag: 'booking_ended',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(result[0].user_id,push_data)
                    common.add_data('tbl_notification',push_notification,(res)=>{})
                    resolve()
                } else {
                    reject()
                }
            })
        })
    },
    async invoice_send(params){
        read.query(`SELECT b.id, b.order_id, b.date, b.time, b.invoice_number,b.is_local,b.advance_receipt_number, b.place_to_supply, b.place_to_delivery,b.sgst,b.cgst,b.igst,b.sgst_amount,b.cgst_amount,b.igst_amount, b.user_id, b.provider_id,b.commission_1,b.commission_2, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',p.profile_image) AS profile_image_provider, p.first_name AS first_name_provider, p.last_name AS last_name_provider,p.email AS email_provider,p.parent_id,p.region_location,p.region_zipcode, b.type, b.description, b.address, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, u.email, b.service_ids, b.total_amount, b.discount_amount, b.final_amount, b.payment_type, b.status, b.cancel_by, b.insert_datetime,b.total_gst FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_user AS p ON p.id = b.provider_id WHERE b.id = ${params.booking_id} LIMIT 1`,(err,result)=>{
            if (!err && result[0] != undefined) {
                home.get_cart_service(result[0].service_ids).then((resService)=>{
                    home.get_additional_cost(result[0].id).then((resAdditionalCost)=>{
                        read.query(`SELECT gst,commission,flat FROM tbl_user WHERE id = ${((result[0].parent_id == 0) ? result[0].provider_id : result[0].parent_id)} LIMIT 1`,(sErr,sResult)=>{
                            read.query(`SELECT name FROM tbl_user_document WHERE user_id = ${((result[0].parent_id == 0) ? result[0].provider_id : result[0].parent_id)} AND type = 'pan_number' LIMIT 1`,(spErr,spResult)=>{
                                read.query(`SELECT tin_number FROM tbl_state_code WHERE state_name = '${result[0].place_to_delivery}' LIMIT 1`,(stateErr,stateResult)=>{
                                    result[0].main_category_id = (resService.main) ? resService.main.id : ``
                                    result[0].main_category_name = (resService.main) ? resService.main.name : ``
                                    result[0].sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                                    result[0].sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                                    result[0].services = resService.result
                                    result[0].additional_cost = resAdditionalCost
                                    result[0].address = (result[0].address) ? JSON.parse(result[0].address) : {}
                                    var services = ``;
                                    var num = 1;
                                    let sac_code = ``;
                                    result[0].services.map(element => {
                                        sac_code = element.sac_code
                                        element.price = ((element.price * 100) / (100 + (parseFloat(result[0].sgst) + parseFloat(result[0].cgst) + parseFloat(result[0].igst)))).toFixed(2);
                                        services += 
                                        `<tr>`+
                                            `<td style="border: 1px solid #ccc"><b>${num}</b></td>`+
                                            `<td style="border: 1px solid #ccc">${element.service_name}</td>`+
                                            `<td style="border: 1px solid #ccc">${element.sac_code}</td>`+
                                            `<td style="border: 1px solid #ccc">inr ${element.price}</td>`+
                                            `<td style="border: 1px solid #ccc">1</td>`+
                                            `<td style="border: 1px solid #ccc">inr ${element.price}</td>`+
                                        `</tr>`;
                                        num++;
                                    });
                                    result[0].additional_cost.map(element => {
                                        if(element.status == "accept"){
                                            element.costs.map(element1 => {
                                                result[0].total_amount += element1.value;
                                                result[0].final_amount += parseFloat(element1.value) + parseFloat(element1.total_gst);
                                                result[0].sgst_amount += parseFloat(element1.sgst_amount);
                                                result[0].cgst_amount += parseFloat(element1.cgst_amount);
                                                result[0].igst_amount += parseFloat(element1.igst_amount);
                                                services += 
                                                `<tr>`+
                                                    `<td style="border: 1px solid #ccc"><b>${num}</b></td>`+
                                                    `<td style="border: 1px solid #ccc">${element1.name}</td>`+
                                                    `<td style="border: 1px solid #ccc">${sac_code}</td>`+
                                                    `<td style="border: 1px solid #ccc">inr ${element1.value}</td>`+
                                                    `<td style="border: 1px solid #ccc">1</td>`+
                                                    `<td style="border: 1px solid #ccc">inr ${element1.value}</td>`+
                                                `</tr>`;
                                                num++;
                                            });
                                        }
                                    });
                                    let discount = ``;
                                    if(result[0].discount_amount != 0){
                                        discount = `<tr>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc"><b>discount amount</b></td>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc"></td>`+
                                            `<td style="border: 1px solid #ccc">inr ${result[0].discount_amount}</td>`+
                                        `</tr>`;
                                    }
                                    var tax_invoice = {
                                        invoice_number: result[0].invoice_number,
                                        invoice_date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        supplier_name: `${result[0].first_name_provider} ${result[0].last_name_provider}`,
                                        billing_name: `${result[0].first_name} ${result[0].last_name}`,
                                        supplier_place: result[0].region_location,
                                        region_zipcode: result[0].region_zipcode,
                                        billing_place: (result[0].type == "home_visit") ? result[0].address.location : ``,
                                        billing_zipcode: (result[0].type == "home_visit") ? result[0].address.pincode : ``,
                                        date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        pan_number: spResult[0].name,
                                        gst_number: sResult[0].gst,
                                        booking_id: result[0].id,
                                        order_id: result[0].order_id,
                                        booking_date: moment(result[0].date).format("DD/MM/YYYY"),
                                        advance_receipt_number: result[0].advance_receipt_number,
                                        state_code: (!stateErr && stateResult[0] != undefined) ? stateResult[0].tin_number : ``,
                                        place_supply: result[0].place_to_supply,
                                        place_delivery: result[0].place_to_delivery,
                                        services: services,
                                        net_amount: result[0].total_amount,
                                        discount: discount,
                                        cgst: result[0].cgst,
                                        cgst_amount: result[0].cgst_amount.toFixed(2),
                                        sgst: result[0].sgst,
                                        sgst_amount: result[0].sgst_amount.toFixed(2),
                                        igst: result[0].igst,
                                        igst_amount: result[0].igst_amount.toFixed(2),
                                        total_amount: (parseFloat(result[0].final_amount)).toFixed(2),
                                        total_amount_in_word: (toWords.convert((parseFloat(result[0].final_amount)).toFixed(2))).toLowerCase(),
                                        invoice_link: ``,
                                        rcm: (sResult[0].gst == '') ? 'yes' : 'no'
                                    }
                                    template.tax_invoice_to_customer(tax_invoice,(html)=>{
                                        htmlpdf.create(html,{format:'A4'}).toStream((errInvoice,resInvoice)=>{
                                            s3.upload({
                                                Bucket: GLOBALS.S3_BUCKET_NAME,
                                                Key: `invoice/${result[0].invoice_number}.pdf`,
                                                ACL: "public-read",
                                                Body: resInvoice
                                            },(errS3,resS3)=>{
                                                tax_invoice.invoice_link = `<a href="${resS3.Location}">Click Here To Download Invoice</a>`;
                                                template.tax_invoice_to_customer(tax_invoice,(html)=>{
                                                    common.send_email(GLOBALS.APP_NAME + " <"+GLOBALS.EMAIL_ID+">",`Tax Invoice For ${result[0].order_id} from EASSY INNOVATIVE SERVICES PRIVATE LIMITED`,result[0].email,html,(resEmail)=>{});
                                                });
                                            });
                                        });
                                    });
                                    let commissions = 
                                    `<tr>`+
                                        `<td style="border: 1px solid #ccc"><b>1</b></td>`+
                                        `<td style="border: 1px solid #ccc">Commission</td>`+
                                        `<td style="border: 1px solid #ccc">996111</td>`+
                                        `<td style="border: 1px solid #ccc">inr ${sResult[0].flat}</td>`+
                                        `<td style="border: 1px solid #ccc">1</td>`+
                                        `<td style="border: 1px solid #ccc">inr ${sResult[0].flat}</td>`+
                                    `</tr>`;
                                    let total_amount = result[0].commission_2;
                                    let cgst_amount = 0;
                                    let sgst_amount = 0;
                                    let igst_amount = 0;
                                    if(result[0].is_local == "true"){
                                        cgst_amount = ((total_amount * 9) / 100);
                                        sgst_amount = ((total_amount * 9) / 100);
                                    }else{
                                        igst_amount = ((total_amount * 18) / 100);
                                    }
                                    var sp_commission = {
                                        invoice_number: result[0].invoice_number,
                                        invoice_date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        supplier_name: `${result[0].first_name_provider} ${result[0].last_name_provider}`,
                                        billing_name: `${result[0].first_name} ${result[0].last_name}`,
                                        supplier_place: result[0].region_location,
                                        region_zipcode: result[0].region_zipcode,
                                        billing_place: (result[0].type == "home_visit") ? result[0].address.location : ``,
                                        billing_zipcode: (result[0].type == "home_visit") ? result[0].address.pincode : ``,
                                        date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        pan_number: spResult[0].name,
                                        gst_number: sResult[0].gst,
                                        booking_id: result[0].id,
                                        order_id: result[0].order_id,
                                        booking_date: moment(result[0].date).format("DD/MM/YYYY"),
                                        advance_receipt_number: result[0].advance_receipt_number,
                                        state_code: (!stateErr && stateResult[0] != undefined) ? stateResult[0].tin_number : ``,
                                        place_supply: result[0].place_to_supply,
                                        services: commissions,
                                        net_amount: total_amount,
                                        cgst: '9',
                                        cgst_amount: cgst_amount,
                                        sgst: '9',
                                        sgst_amount: sgst_amount,
                                        igst: '18',
                                        igst_amount: igst_amount,
                                        total_amount: (parseFloat(total_amount)+parseFloat(cgst_amount)+parseFloat(sgst_amount)+parseFloat(igst_amount)).toFixed(2),
                                        total_amount_in_word: (toWords.convert((parseFloat(total_amount)+parseFloat(cgst_amount)+parseFloat(sgst_amount)+parseFloat(igst_amount)).toFixed(2))).toLowerCase(),
                                        invoice_link: ``,
                                        rcm: (sResult[0].gst == '') ? 'yes' : 'no'
                                    }
                                    let q = write.query(`UPDATE tbl_booking SET commission_2_amount = ${parseFloat(sp_commission.total_amount)}, tds = ${(tax_invoice.total_amount*1/100)}, tcs = ${(result[0].final_amount*1/100)} WHERE id = ${params.booking_id}`);
                                    console.log(`commission 2 => ${q.sql}`)
                                    template.eassyserve_to_sp_commission(sp_commission,(html)=>{
                                        htmlpdf.create(html,{format:'A4'}).toStream((errInvoice,resInvoice)=>{
                                            s3.upload({
                                                Bucket: GLOBALS.S3_BUCKET_NAME,
                                                Key: `invoice/commission-${result[0].invoice_number}.pdf`,
                                                ACL: "public-read",
                                                Body: resInvoice
                                            },(errS3,resS3)=>{
                                                if(result[0].email_provider){
                                                    sp_commission.invoice_link = `<a href="${resS3.Location}">Click Here To Download Invoice</a>`;
                                                    template.eassyserve_to_sp_commission(sp_commission,(html)=>{
                                                        common.send_email(GLOBALS.APP_NAME + " <"+GLOBALS.EMAIL_ID+">",`Commission Invoice For ${result[0].order_id} from EASSY INNOVATIVE SERVICES PRIVATE LIMITED`,result[0].email_provider,html,(resEmail)=>{});
                                                    });
                                                }
                                            });
                                        });
                                    });
                                    if(result[0].commission_1 != 0.00){
                                        let commission = ((result[0].final_amount * result[0].commission_1) / 100);
                                        var sp_transaction = {
                                            invoice_number: result[0].invoice_number,
                                            invoice_date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                            supplier_name: `${result[0].first_name_provider} ${result[0].last_name_provider}`,
                                            billing_name: `${result[0].first_name} ${result[0].last_name}`,
                                            supplier_place: result[0].region_location,
                                            region_zipcode: result[0].region_zipcode,
                                            billing_place: (result[0].type == "home_visit") ? result[0].address.location : ``,
                                            billing_zipcode: (result[0].type == "home_visit") ? result[0].address.pincode : ``,
                                            date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                            pan_number: spResult[0].name,
                                            gst_number: sResult[0].gst,
                                            booking_id: result[0].id,
                                            order_id: result[0].order_id,
                                            booking_date: moment(result[0].date).format("DD/MM/YYYY"),
                                            advance_receipt_number: result[0].advance_receipt_number,
                                            state_code: (!stateErr && stateResult[0] != undefined) ? stateResult[0].tin_number : ``,
                                            place_supply: result[0].place_to_supply,
                                            services: ``,
                                            net_amount: commission,
                                            cgst: '9',
                                            cgst_amount: 0,
                                            sgst: '9',
                                            sgst_amount: 0,
                                            igst: '18',
                                            igst_amount: 0,
                                            total_amount: (parseFloat(commission)).toFixed(2),
                                            total_amount_in_word: (toWords.convert((parseFloat(commission)).toFixed(2))).toLowerCase(),
                                            invoice_link: ``,
                                            rcm: (sResult[0].gst == '') ? 'yes' : 'no'
                                        }
                                        sp_transaction.services = `<tr>`+
                                            `<td style="border: 1px solid #ccc"><b>1</b></td>`+
                                            `<td style="border: 1px solid #ccc">Transaction Charges</td>`+
                                            `<td style="border: 1px solid #ccc">996111</td>`+
                                            `<td style="border: 1px solid #ccc">inr ${commission}</td>`+
                                            `<td style="border: 1px solid #ccc">1</td>`+
                                            `<td style="border: 1px solid #ccc">inr ${commission}</td>`+
                                        `</tr>`;
                                        if(result[0].is_local == "true"){
                                            sp_transaction.cgst_amount = ((commission * 9) / 100).toFixed(2);
                                            sp_transaction.sgst_amount = ((commission * 9) / 100).toFixed(2);
                                        }else{
                                            sp_transaction.igst_amount = ((commission * 18) / 100).toFixed(2);
                                        }
                                        sp_transaction.total_amount = (parseFloat(commission)+parseFloat(sp_transaction.cgst_amount)+parseFloat(sp_transaction.sgst_amount)+parseFloat(sp_transaction.igst_amount)).toFixed(2);
                                        sp_transaction.total_amount_in_word = toWords.convert(sp_transaction.total_amount);
                                        template.eassyserve_to_sp_transaction_commission(sp_transaction,(html)=>{
                                            htmlpdf.create(html,{format:'A4'}).toStream((errInvoice,resInvoice)=>{
                                                s3.upload({
                                                    Bucket: GLOBALS.S3_BUCKET_NAME,
                                                    Key: `invoice/transaction-${result[0].invoice_number}.pdf`,
                                                    ACL: "public-read",
                                                    Body: resInvoice
                                                },(errS3,resS3)=>{
                                                    let q = write.query(`UPDATE tbl_booking SET commission_1_amount = ${parseFloat(sp_transaction.total_amount)} WHERE id = ${params.booking_id}`);
                                                    console.log(`commission 1 => ${q.sql}`)
                                                    if(result[0].email_provider){
                                                        sp_transaction.invoice_link = `<a href="${resS3.Location}">Click Here To Download Invoice</a>`;
                                                        template.eassyserve_to_sp_transaction_commission(sp_transaction,(html)=>{
                                                            common.send_email(GLOBALS.APP_NAME + " <"+GLOBALS.EMAIL_ID+">",`Transaction Charges Invoice For ${result[0].order_id} from EASSY INNOVATIVE SERVICES PRIVATE LIMITED`,result[0].email_provider,html,(resEmail)=>{});
                                                        });
                                                    }
                                                });
                                            });
                                        });
                                    }
                                })
                            })
                        })
                    })
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Additional Cost                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    add_additional_cost: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT b.id,b.order_id,b.user_id,b.sgst,b.cgst,b.igst,u.current_language FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE b.provider_id = ${params.login_user_id} AND b.id = ${params.booking_id} AND b.status = 'running'`, (err, result) => {
                if (!err && result[0] != undefined) {
                    let insertData = []
                    let additional_id = common.stringGen(12)
                    asyncLoop(params.additional,(item,next)=>{
                        item.value = ((item.value * 100) / (100 + (parseFloat(result[0].sgst) + parseFloat(result[0].cgst) + parseFloat(result[0].igst)))).toFixed(2)
                        let sgst_amount = ((parseFloat(item.value) * parseFloat(result[0].sgst)) / 100);
                        let cgst_amount = ((parseFloat(item.value) * parseFloat(result[0].cgst)) / 100);
                        let igst_amount = ((parseFloat(item.value) * parseFloat(result[0].igst)) / 100);
                        let total_gst = sgst_amount + cgst_amount + igst_amount;
                        insertData.push([params.booking_id,additional_id,item.name,item.value,result[0].sgst,result[0].cgst,result[0].igst,sgst_amount,cgst_amount,igst_amount,total_gst,moment().format("X")]);
                        next()
                    },()=>{
                        write.query(`INSERT INTO tbl_booking_additional_cost(booking_id,additional_id,name,value,sgst,cgst,igst,sgst_amount,cgst_amount,igst_amount,total_gst,insert_datetime) VALUES ?`,[insertData],(iErr,iResult)=>{
                            if(!iErr && iResult != undefined){
                                if(params.images){
                                    home.add_additional_cost_images(params.booking_id,additional_id,params.images)
                                }
                                var push_data = {
                                    title: lang[result[0].current_language]['text_booking_additional_cost_added_title'].replace('{order_id}',result[0].order_id),
                                    body: lang[result[0].current_language]['text_booking_additional_cost_added_body'].replace('{order_id}',result[0].order_id),
                                    custom: {
                                        tag: "booking_additional_cost_added",
                                        order_id: result[0].order_id,
                                        booking_id: result[0].id
                                    }
                                }
                                var push_notification = {
                                    sender_id: params.login_user_id,
                                    receiver_id: result[0].user_id,
                                    action_id: result[0].id,
                                    message: JSON.stringify({title:'text_booking_additional_cost_added_title',body:'text_booking_additional_cost_added_body'}),
                                    tag: 'booking_additional_cost_added',
                                    insert_datetime: moment().format("X")
                                }
                                common.prepare_notification(result[0].user_id,push_data)
                                common.add_data('tbl_notification',push_notification,(res)=>{})
                                resolve()
                            }else{
                                reject()
                            }
                        })
                    })
                } else {
                    reject()
                }
            })
        })
    },
    add_additional_cost_images: function(booking_id,additional_id,images){
        asyncLoop(images.split(','),(item,next)=>{
            let insertData = {
                booking_id: booking_id,
                additional_id: additional_id,
                image: item,
                insert_datetime: moment().format("X")
            }
            write.query(`INSERT INTO tbl_booking_additional_cost_images SET ?`,insertData,(iErr,iResult)=>{
                next()
            })
        },()=>{})
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                           Get User Past Order                                  /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_past_orders: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id, order_id, final_amount, date, time, service_ids FROM tbl_booking WHERE user_id = '${params.user_id}' AND provider_id = '${params.login_user_id}' AND status = 'completed' LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`, (err, result) => {
                if (!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        home.get_cart_service(item.service_ids).then((resService)=>{
                            item.main_category = (resService.main) ? resService.main.id : ``
                            item.main_category_name = (resService.main) ? resService.main.name : ``
                            item.sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                            item.sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                            item.services = resService.result
                            next()
                        })
                    },()=>{
                        resolve({page_token:parseInt(params.page_token)+1,result:result})
                    })
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Get Review List                                   /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_review_list: function(params) {
        return new Promise((resolve,reject)=>{
            var low_to_high = (params.low_to_high) ? `ORDER BY e.experience,e.id` : ``
            var high_to_low = (params.high_to_low) ? `ORDER BY e.experience DESC,e.id DESC` : ``
            var rating = (params.rating) ? `AND e.experience = '${params.rating}'` : ``
            if(low_to_high == `` && high_to_low == ``){
                low_to_high = `ORDER BY e.id DESC`
            }
            read.query({sql:`SELECT e.id, e.user_id, u.first_name, u.last_name, CONCAT('${GLOBALS.S3_URL+GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, e.experience, e.review, e.insert_datetime FROM tbl_booking AS b JOIN tbl_booking_experience AS e ON b.id = e.booking_id JOIN tbl_user AS u ON u.id = e.user_id WHERE b.provider_id = '${params.login_user_id}' ${rating} ${low_to_high} ${high_to_low} LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`,
                typeCast:(field,next)=>{
                    if(field.type == "BLOB"){
                        return field.string()
                    }
                    return next()
                }
            }, (err, result) => {
                if (!err && result[0] != undefined) {
                    resolve({page_token:parseInt(params.page_token)+1,result:result})
                } else {
                    reject()
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Notification List                                 /////
    //////////////////////////////////////////////////////////////////////////////////////////
    notification_list : function(params)
    {
        return new Promise((resolve,reject)=>{
            read.query({sql:`SELECT n.id, n.action_id, n.tag, n.message, n.is_read, n.insert_datetime, CONCAT(u.first_name,' ',u.last_name) AS name, u.current_language FROM tbl_notification AS n JOIN tbl_user AS u ON u.id = n.receiver_id WHERE n.is_active = '1' AND n.receiver_id = '${params.login_user_id}' ORDER BY n.id DESC LIMIT ${parseInt(params.page_token) * parseInt(GLOBALS.NOTIFICATION_PER_PAGE)},${GLOBALS.NOTIFICATION_PER_PAGE}`,
                typeCast: (field, next) => {
                    if (field.type == 'BLOB') {
                        return field.string()
                    }
                    return next()
                }
            }, function(err, result) {
                if(!err && result[0] != undefined) {
                    asyncLoop(result,(item,next)=>{
                        try{
                            item.message = JSON.parse(item.message)
                        }catch(e){
                            item.message = item.message
                        }
                        if(item.tag == "admin_notification"){
                            item.title = item.message.title
                            item.body = item.message.body
                            delete item.current_language
                            delete item.message
                            next()
                        }else{
                            if(["place_booking","booking_experience","booking_missed","booking_reschedule","booking_experience","booking_issue","booking_request_reminder"].indexOf(item.tag) !== -1){
                                read.query(`SELECT b.order_id, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title].replace('{sp_name}',bResult[0].sp_name).replace('{order_id}',bResult[0].order_id)
                                    item.body = lang[item.current_language][item.message.body].replace('{order_id}',bResult[0].order_id)
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else if(["offer_added","offer_live","offer_end_reminder"].indexOf(item.tag) !== -1){
                                read.query(`SELECT CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_offer AS o JOIN tbl_user AS u ON u.id = o.user_id WHERE o.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title].replace('{sp_name}',(bResult[0] != undefined) ? bResult[0].sp_name : ``)
                                    item.body = lang[item.current_language][item.message.body]
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else if(["region_reminder","register_reminder","availability_not_set_reminder","rate_card_not_set_reminder","register_complete_admin_approval_pending"].indexOf(item.tag) !== -1){
                                read.query(`SELECT CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_user AS u WHERE u.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title].replace('{sp_name}',bResult[0].sp_name)
                                    item.body = lang[item.current_language][item.message.body]
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else if(["today_total_service","admin_approval"].indexOf(item.tag) !== -1){
                                item.title = lang[item.current_language][item.message.title].replace('{sp_name}',item.name)
                                item.body = lang[item.current_language][item.message.body].replace('{total}',(item.total) ? item.total : 0)
                                delete item.current_language
                                delete item.message
                                next()
                            }else if(["staff_added"].indexOf(item.tag) !== -1){
                                read.query(`SELECT u.id, CONCAT(u.first_name,' ',u.last_name) AS name FROM tbl_user AS u WHERE u.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title]
                                    item.body = lang[item.current_language][item.message.body].replace('{name}',bResult[0].name).replace('{staff_id}',bResult[0].id)
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else if(["booking_issue_on_staff","booking_cancelled_by_staff","booking_missed_by_staff"].indexOf(item.tag) !== -1){
                                read.query(`SELECT b.order_id, CONCAT(u.first_name,' ',u.last_name) AS name, b.provider_id FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title]
                                    item.body = lang[item.current_language][item.message.body].replace('{order_id}',bResult[0].order_id).replace('{name}',bResult[0].name).replace('{staff_id}',bResult[0].provider_id)
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else if(["booking_cancelled"].indexOf(item.tag) !== -1){
                                read.query(`SELECT b.order_id, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title].replace('{sp_name}',bResult[0].sp_name)
                                    item.body = lang[item.current_language][item.message.body].replace('{order_id}',bResult[0].order_id)
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else if(["booking_additional_cost_action"].indexOf(item.tag) !== -1){
                                read.query(`SELECT b.order_id, CONCAT(u.first_name,' ',u.last_name) AS sp_name, b.provider_id FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.id = ${item.action_id} LIMIT 1`,(bErr,bResult)=>{
                                    item.title = lang[item.current_language][item.message.title].replace('{sp_name}',bResult[0].sp_name)
                                    item.body = lang[item.current_language][item.message.body].replace('{rs}',item.message.rs)
                                    delete item.current_language
                                    delete item.message
                                    next()
                                })
                            }else{
                                item.title = lang[item.current_language][item.message.title]
                                item.body = lang[item.current_language][item.message.body]
                                delete item.current_language
                                delete item.message
                                next()
                            }
                        }
                    },()=>{
                        resolve({"page_token":parseInt(params.page_token)+1,"result":result})
                    })
                }
                else {
                    reject(null)
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                       Provider Sub Category List                               /////
    //////////////////////////////////////////////////////////////////////////////////////////
    provider_sub_category_list: function(params) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT s.id, s.name FROM tbl_category_service AS cs JOIN tbl_category AS s ON s.id = cs.sub_category_id WHERE cs.user_id = ${params.provider_id} AND cs.type = 'charge' AND cs.is_check = 'true' GROUP BY cs.sub_category_id`,(err, result)=>{
                if (!err && result[0] != undefined) {
                    resolve(result)
                } else {
                    reject(null)
                }
            })
        })
    },
}

module.exports = home;