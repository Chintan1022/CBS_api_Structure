const express = require('express');
const lang = require('../../../config/language');
var home_model = require('./home_model');
var common = require('../../../config/common');

var router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Filter List                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/filter_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "category_id" : "required" }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.filter_list(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Add Service & Price                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_service_price", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            sub_category_id: 'required',
            service_name: 'required',
            price: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.add_service_price(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_user_add_service_success'], resData)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_add_service_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Check | Uncheck Service Price                          /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/check_service_price", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            sub_category_id: 'required'
            // charge_ids: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.check_uncheck_service_price(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_user_add_service_success'], {id: resData.insertId})
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_add_service_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Edit Service & Price                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/edit_service_price", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            id: 'required',
            service_name: 'required',
            price: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.edit_service_price(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_user_edit_service_success'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_edit_service_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Delete Service & Price                               /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/delete_service_price", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.delete_service_price(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_user_service_price_deleted'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_service_price_delete_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Add User Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_user_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            sub_category_id: 'required'
            // filter_ids: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.add_user_service(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_service_filter_added_su'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_service_filter_added_fail'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Manage Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/manage_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { page_token: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.manage_service(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_service_found'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Add Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { sub_category_id: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.add_service(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_service_added_su'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_add_service_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Delete Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/delete_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { sub_category_id: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.delete_service(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_user_service_deleted'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_service_delete_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Add Offer                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_offer", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            title: 'required',
            category_id: 'required',
            start_date: 'required',
            end_date: 'required',
            discount: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.check_offer_unique(params.title).then((resUniqueOffer)=>{
                home_model.add_offer(params).then((resCode)=>{
                    let action = (resCode == 1) ? `added` : `updated`
                    common.sendResponse(res, "1", lang[req.language]['text_offer_su'].replace('{action}',action), null)
                }).catch((err) => {
                    let action = (err == 0) ? `added` : `updated`
                    common.sendResponse(res, "0", lang[req.language]['text_offer_un'].replace('{action}',action), null)
                })
            }).catch((err)=>{
                common.sendResponse(res, "0", lang[req.language]['text_offer_unique'], null)
            });
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                My Offer                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/my_offer", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { page_token: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.my_offer(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_offer_list_not_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Delete Offer                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/delete_offer", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.delete_offer(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_offer_delete_su'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_offer_delete_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Set Availability                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/set_availability", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            start_date: 'required',
            end_date: 'required',
            start_time: 'required',
            end_time: 'required',
            type: 'required|in:A,U,BD,AD'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.set_available(params).then((resData)=>{
                var tag = (params.type == "A" || params.type == "AD") ? `text_set_available_su` : `text_set_unavailable_su`
                common.sendResponse(res, "1", lang[req.language][tag], null)
            }).catch((err) => {
                var tag = (params.type == "A" || params.type == "AD") ? `text_set_available_un` : `text_set_unavailable_un`
                common.sendResponse(res, "0", lang[req.language][tag], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Set Availability                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/set_availability_one_slot", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            start_date: 'required',
            end_date: 'required',
            start_time: 'required',
            end_time: 'required',
            type: 'required|in:A,U'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.set_availability_one_slot(params).then((resData)=>{
                var tag = (params.type == "A") ? `text_set_available_su` : `text_set_unavailable_su`
                common.sendResponse(res, "1", lang[req.language][tag], null)
            }).catch((err) => {
                var tag = (params.type == "A") ? `text_set_available_un` : `text_set_unavailable_un`
                common.sendResponse(res, "0", lang[req.language][tag], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Get Availability Time Slot                             /////
//////////////////////////////////////////////////////////////////////////////////////////
// router.post("/get_availability_time_slot", function(req, res) {
//     common.decryption(req.body, function(params) {
//         var rules = { date: 'required' }
//         if(common.checkValidation(params, rules, res, req.language))
//         {
//             params.login_user_id = req.login_user_id
//             home_model.get_available_time_slot(params).then((resData)=>{
//                 common.sendResponse(res, "1", lang[req.language]['text_get_available_su'], resData)
//             }).catch((err) => {
//                 common.sendResponse(res, "2", lang[req.language]['text_get_available_un'], null)
//             })
//         }
//     })
// })

//////////////////////////////////////////////////////////////////////////////////////////
/////                        Get Availability Month Slot                             /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_availability_month_slot", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            start_date: 'required',
            end_date: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.get_available_month_slot(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_get_available_su'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_get_available_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                My Service                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/my_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            status: 'required|in:today,pending,upcoming,completed,cancelled',
            page_token: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            common.get_provider_ids(req.login_user_id,0).then((resIds)=>{
                params.login_user_id = resIds.ids
                home_model.my_service(params).then((resData)=>{
                    common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
                }).catch((err)=>{
                    common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
                })
            }).catch((error)=>{
                params.login_user_id = req.login_user_id
                home_model.my_service(params).then((resData)=>{
                    common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
                }).catch((err)=>{
                    common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
                })
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           My Service Details                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/my_service_details", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.my_service_details(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Service Action                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/service_action", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            booking_id: 'required',
            action: 'required|in:accepted,cancelled'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.service_action(params).then((resData)=>{
                if(resData.code == 1){
                    let message = lang[req.language]['text_service_action_su'].replace('{action}',(params.action == "accepted") ? `confirm` : `reject`);
                    common.sendResponse(res, "1", message, null)
                }else{
                    let message = lang[req.language]['text_service_action_already'].replace('{action}',resData.status);
                    common.sendResponse(res, "0", message, null)
                }
            }).catch((err)=>{
                let message = lang[req.language]['text_service_action_un'].replace('{action}',(params.action == "accepted") ? `confirm` : `reject`);
                common.sendResponse(res, "0", message, null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Cancel Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/cancel_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            id: 'required',
            reason: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.cancel_service(params).then((resData)=>{
                if(resData.code == "0"){
                    if(resData.status == "cancelled"){
                        common.sendResponse(res, "0", lang[req.language]['text_book_service_already'], null)
                    }else{
                        common.sendResponse(res, "0", lang[req.language]['text_book_service_not_cancel_un'].replace('{status}',resData.status), null)
                    }
                }else{
                    common.sendResponse(res, "1", lang[req.language]['text_book_service_cancel_su'], null)
                }
            }).catch((err)=>{
                common.sendResponse(res, "0", lang[req.language]['text_book_service_cancel_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Start Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/start_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            booking_id: 'required',
            otp: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.start_service(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_start_service_su'], null)
            }).catch((err)=>{
                common.sendResponse(res, "0", lang[req.language]['text_start_end_service_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                End Service                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/end_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            booking_id: 'required',
            otp: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.end_service(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_end_service_su'], null)
            }).catch((err)=>{
                common.sendResponse(res, "0", lang[req.language]['text_start_end_service_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Additional Cost                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_additional_cost", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            booking_id: 'required',
            additional: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.add_additional_cost(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_additional_cost_su'], null)
            }).catch((err)=>{
                common.sendResponse(res, "0", lang[req.language]['text_additional_cost_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Get User Past Order                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_user_past_order", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            user_id: 'required',
            page_token: 'required'
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.get_past_orders(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_past_order_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Get Review List                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_review_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { page_token: 'required' }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            home_model.get_review_list(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_no_review_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Notification List                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/notification_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { page_token : "required" }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            params.language = req.language
            home_model.notification_list(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['notification_list'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['notification_list_not_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                       Provider Sub Category List                               /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/provider_sub_category_list", function(req, res) {
    common.decryption(req.body, function(params) {
        params.provider_id = req.login_user_id
        home_model.provider_sub_category_list(params).then((resData)=>{
            common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
        }).catch((err)=>{
            common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
        })
    })
})

module.exports = router;