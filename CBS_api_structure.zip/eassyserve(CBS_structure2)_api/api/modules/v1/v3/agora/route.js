const lang = require('../../../config/language');
const {decryption,checkValidation,sendResponse,prepare_notification} = require('../../../config/common');
const {AGORA_APP_ID,AGORA_CERTIFICATE} = require('../../../config/constants');
const {read} = require('../../../config/database');

const router = require('express').Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                   RTC TOKEN                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/rtc_token',(req,res)=>{
    decryption(req.body,(params)=>{
        var rules = { "user_id": "required", "channel_name": "required" };
        if (checkValidation(params,rules,res)) {
            const appID = AGORA_APP_ID.toString();
            const appCertificate = AGORA_CERTIFICATE.toString();

            // rtc token => channel token
            const RtcTokenBuilder = require('../../../rtc/src/RtcTokenBuilder').RtcTokenBuilder;
            const RtcRole = require('../../../rtc/src/RtcTokenBuilder').Role;

            // rtm token => message token
            const RtmTokenBuilder = require('../../../rtc/src/RtmTokenBuilder').RtmTokenBuilder;
            const RtmRole = require('../../../rtc/src/RtmTokenBuilder').Role;
            const Priviledges = require('../../../rtc/src/AccessToken').priviledges;
            const account = params.user_id;

            const channelName = params.channel_name;
            const uid = parseInt(params.user_id);
            const role = RtcRole.PUBLISHER;

            const expirationTimeInSeconds = 3600;

            const currentTimestamp = Math.floor(Date.now() / 1000);

            const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

            // Build token with uid
            const rtcToken = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channelName, uid, role, privilegeExpiredTs);

            const rtmToken = RtmTokenBuilder.buildToken(appID, appCertificate, account, RtmRole, privilegeExpiredTs);
            
            sendResponse(res, "1", lang[req.language]['text_details_are'], {"rtc_token": rtcToken,"rtm_token": rtmToken});
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              SEND NOTIFICATION                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/send_notification',(req,res)=>{
    decryption(req.body,(params)=>{
        var rules = {
            "user_id": "required",
            "channel_name": "required",
			"flag": "required",
			"body": "required"
        };
        if (checkValidation(params,rules,res)) {
            read.query(`SELECT current_language,first_name,last_name FROM tbl_user WHERE id = ${params.user_id} LIMIT 1`,(err,result)=>{
                var push_data = {
                    title: `${result[0].first_name} ${result[0].last_name}`,
                    body: params.body,
                    custom: {
                        tag: params.flag,
						body: params.body,
                        user_id: params.user_id
                    }
                }
				console.log(push_data)
                prepare_notification(params.user_id,push_data)
                sendResponse(res, "1", lang[req.language]['text_details_are'], null);
            })
        }
    });
});

module.exports = router;