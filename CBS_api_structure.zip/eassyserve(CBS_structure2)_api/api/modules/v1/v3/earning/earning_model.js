const { read } = require('../../../config/database');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const lang = require('../../../config/language');
const asyncLoop = require('node-async-loop');

const model = {
    async earning_summary(params){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id FROM tbl_user WHERE parent_id = ${params.login_user_id}`,(uErr,uResult)=>{
                let provider_id = (!uErr && uResult[0]) ? `${uResult.map(x=>x.id)},${params.login_user_id}` : params.login_user_id;
                if(params.type == "day"){
                    let current_date = new Date();
                    let past_7_date = new Date();
                    past_7_date.setDate(current_date.getDate() - 7);
                    let dates = this.get_day(past_7_date,current_date);
                    let total_amount = 0;
                    asyncLoop(dates,(item,next)=>{
                        read.query(`SELECT GROUP_CONCAT(id) AS booking_ids,COUNT(id) AS total_booking,SUM(final_amount) AS final_amount FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date = '${item.start_date}' LIMIT 1`,(tbErr,tbResult)=>{
                            if(!tbErr && tbResult[0] && tbResult[0].booking_ids){
                                read.query(`SELECT SUM(value) AS total_additional_cost FROM tbl_booking_additional_cost WHERE booking_id IN (${tbResult[0].booking_ids}) AND status = 'accept' LIMIT 1`,(aErr,aResult)=>{
                                    tbResult[0].final_amount += (!aErr && aResult[0]) ? aResult[0].total_additional_cost : 0;
                                    item.total_booking = tbResult[0].total_booking;
                                    item.total_amount = tbResult[0].final_amount;
                                    total_amount += item.total_amount;
                                    next();
                                });
                            }else{
                                item.total_booking = 0;
                                item.total_amount = 0;
                                next();
                            }
                        });
                    },()=>{
                        past_7_date = dates[0].start_date;
                        current_date = dates[dates.length - 1].end_date;
                        read.query(`SELECT (SELECT COUNT(id) FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_date}' AND '${current_date}' LIMIT 1) AS total_successful,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_date}' AND '${current_date}' LIMIT 1) AS total_rejected,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND is_auto_reject = 'true' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_date}' AND '${current_date}' LIMIT 1) AS total_missed`,(tErr,tResult)=>{
                            resolve({
                                total_earning: total_amount,
                                total_successful: tResult[0].total_successful,
                                total_rejected: tResult[0].total_rejected,
                                total_missed: tResult[0].total_missed,
                                list: dates
                            });
                        });
                    })
                }else if(params.type == "week"){
                    let current_date = new Date();
                    let past_8_week_date = new Date();
                    past_8_week_date.setDate(current_date.getDate() - (7 * 8));
                    let weeks = this.get_weeks(past_8_week_date,current_date);
                    let total_amount = 0;
                    asyncLoop(weeks,(item,next)=>{
                        read.query(`SELECT GROUP_CONCAT(id) AS booking_ids,COUNT(id) AS total_booking,SUM(final_amount) AS final_amount FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${item.start_date}' AND '${item.end_date}' LIMIT 1`,(tbErr,tbResult)=>{
                            if(!tbErr && tbResult[0] && tbResult[0].booking_ids){
                                read.query(`SELECT SUM(value) AS total_additional_cost FROM tbl_booking_additional_cost WHERE booking_id IN (${tbResult[0].booking_ids}) AND status = 'accept' LIMIT 1`,(aErr,aResult)=>{
                                    tbResult[0].final_amount += (!aErr && aResult[0]) ? aResult[0].total_additional_cost : 0;
                                    item.total_booking = tbResult[0].total_booking;
                                    item.total_amount = tbResult[0].final_amount;
                                    total_amount += item.total_amount;
                                    next();
                                });
                            }else{
                                item.total_booking = 0;
                                item.total_amount = 0;
                                next();
                            }
                        });
                    },()=>{
                        past_8_week_date = weeks[0].start_date;
                        current_date = weeks[weeks.length - 1].end_date;
                        read.query(`SELECT (SELECT COUNT(id) FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_8_week_date}' AND '${current_date}' LIMIT 1) AS total_successful,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_8_week_date}' AND '${current_date}' LIMIT 1) AS total_rejected,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND is_auto_reject = 'true' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_8_week_date}' AND '${current_date}' LIMIT 1) AS total_missed`,(tErr,tResult)=>{
                            resolve({
                                total_earning: total_amount,
                                total_successful: tResult[0].total_successful,
                                total_rejected: tResult[0].total_rejected,
                                total_missed: tResult[0].total_missed,
                                list: weeks
                            });
                        });
                    })
                }else if(params.type == "month"){
                    let current_month = new Date();
                    let past_7_month = new Date();
                    past_7_month.setMonth(current_month.getMonth() - 7);
                    let months = this.get_month(past_7_month,current_month);
                    let total_amount = 0;
                    asyncLoop(months,(item,next)=>{
                        read.query(`SELECT GROUP_CONCAT(id) AS booking_ids,COUNT(id) AS total_booking,SUM(final_amount) AS final_amount FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${item.start_date}' AND '${item.end_date}' LIMIT 1`,(tbErr,tbResult)=>{
                            if(!tbErr && tbResult[0] && tbResult[0].booking_ids){
                                read.query(`SELECT SUM(value) AS total_additional_cost FROM tbl_booking_additional_cost WHERE booking_id IN (${tbResult[0].booking_ids}) AND status = 'accept' LIMIT 1`,(aErr,aResult)=>{
                                    tbResult[0].final_amount += (!aErr && aResult[0]) ? aResult[0].total_additional_cost : 0;
                                    item.total_booking = tbResult[0].total_booking;
                                    item.total_amount = tbResult[0].final_amount;
                                    total_amount += item.total_amount;
                                    next();
                                });
                            }else{
                                item.total_booking = 0;
                                item.total_amount = 0;
                                next();
                            }
                        });
                    },()=>{
                        past_7_month = months[0].start_date;
                        current_month = months[months.length - 1].end_date;
                        read.query(`SELECT (SELECT COUNT(id) FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_month}' AND '${current_month}' LIMIT 1) AS total_successful,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_month}' AND '${current_month}' LIMIT 1) AS total_rejected,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND is_auto_reject = 'true' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_month}' AND '${current_month}' LIMIT 1) AS total_missed`,(tErr,tResult)=>{
                            resolve({
                                total_earning: total_amount,
                                total_successful: tResult[0].total_successful,
                                total_rejected: tResult[0].total_rejected,
                                total_missed: tResult[0].total_missed,
                                list: months
                            });
                        });
                    })
                }else{
                    let current_year = new Date();
                    let past_7_year = new Date();
                    past_7_year.setFullYear(current_year.getFullYear() - 7);
                    let years = this.get_year(past_7_year,current_year);
                    let total_amount = 0;
                    asyncLoop(years,(item,next)=>{
                        read.query(`SELECT GROUP_CONCAT(id) AS booking_ids,COUNT(id) AS total_booking,SUM(final_amount) AS final_amount FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${item.start_date}' AND '${item.end_date}' LIMIT 1`,(tbErr,tbResult)=>{
                            if(!tbErr && tbResult[0] && tbResult[0].booking_ids){
                                read.query(`SELECT SUM(value) AS total_additional_cost FROM tbl_booking_additional_cost WHERE booking_id IN (${tbResult[0].booking_ids}) AND status = 'accept' LIMIT 1`,(aErr,aResult)=>{
                                    tbResult[0].final_amount += (!aErr && aResult[0]) ? aResult[0].total_additional_cost : 0;
                                    item.total_booking = tbResult[0].total_booking;
                                    item.total_amount = tbResult[0].final_amount;
                                    total_amount += item.total_amount;
                                    next();
                                });
                            }else{
                                item.total_booking = 0;
                                item.total_amount = 0;
                                next();
                            }
                        });
                    },()=>{
                        past_7_year = years[0].start_date;
                        current_year = years[years.length - 1].end_date;
                        read.query(`SELECT (SELECT COUNT(id) FROM tbl_booking WHERE status = 'completed' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_year}' AND '${current_year}' LIMIT 1) AS total_successful,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_year}' AND '${current_year}' LIMIT 1) AS total_rejected,(SELECT COUNT(id) FROM tbl_booking WHERE status = 'cancelled' AND is_auto_reject = 'true' AND provider_id IN (${provider_id}) AND date BETWEEN '${past_7_year}' AND '${current_year}' LIMIT 1) AS total_missed`,(tErr,tResult)=>{
                            resolve({
                                total_earning: total_amount,
                                total_successful: tResult[0].total_successful,
                                total_rejected: tResult[0].total_rejected,
                                total_missed: tResult[0].total_missed,
                                list: years
                            });
                        });
                    })
                }
            })
        })
    },
    get_day(start_date,end_date){
        let days = [];
        while(start_date <= end_date){
            days.push({
                title: (moment(start_date).format('ddd')).toLowerCase(),
                start_date: moment(start_date).format('YYYY-MM-DD'),
                end_date: moment(start_date).format('YYYY-MM-DD')
            });
            start_date.setDate(start_date.getDate() + 1);
        }
        return days;
    },
    get_weeks(start_date,end_date){
        let weeks = [];
        while(start_date <= end_date){
            let start = moment(start_date).startOf('week');
            let end = moment(start_date).endOf('week');
            weeks.push({
                title: moment(start,'YYYY-MM-DD').week(),
                start_date: start.format('YYYY-MM-DD'),
                end_date: end.format('YYYY-MM-DD')
            });
            start_date.setDate(start_date.getDate() + 7);
        }
        return weeks;
    },
    get_month(start_date,end_date){
        let months = [];
        while(start_date <= end_date){
            let start = moment(start_date).startOf('month');
            let end = moment(start_date).endOf('month');
            months.push({
                title: (start.format('MMM')).toLowerCase(),
                start_date: start.format('YYYY-MM-DD'),
                end_date: end.format('YYYY-MM-DD')
            });
            start_date.setMonth(start_date.getMonth() + 1);
        }
        return months;
    },
    get_year(start_date,end_date){
        let years = [];
        while(start_date <= end_date){
            let start = moment(start_date).startOf('year');
            let end = moment(start_date).endOf('year');
            years.push({
                title: start.format('YYYY'),
                start_date: start.format('YYYY-MM-DD'),
                end_date: end.format('YYYY-MM-DD')
            });
            start_date.setFullYear(start_date.getFullYear() + 1);
        }
        return years;
    },
    async earning_summary_detail(params){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT id FROM tbl_user WHERE parent_id = ${params.login_user_id}`,(uErr,uResult)=>{
                let provider_id = (!uErr && uResult[0]) ? `${uResult.map(x=>x.id)},${params.login_user_id}` : params.login_user_id;
                read.query(`SELECT b.id,b.order_id,b.date,b.time,b.service_ids,b.total_amount,b.final_amount FROM tbl_booking AS b WHERE b.status = 'completed' AND b.provider_id IN (${provider_id}) AND b.date BETWEEN '${params.start_date}' AND '${params.end_date}' LIMIT ${(parseInt(params.page_token) * parseInt(GLOBALS.PER_PAGE))},${parseInt(GLOBALS.PER_PAGE)}`,(err,result)=>{
                    if (!err && result[0] != undefined) {
                        asyncLoop(result,(item,next)=>{
                            this.get_cart_service(item.service_ids).then((resService)=>{
                                this.get_additional_cost(item.id).then((resAdditionalCost)=>{
                                    item.main_category_id = (resService.main) ? resService.main.id : ``
                                    item.main_category_name = (resService.main) ? resService.main.name : ``
                                    item.sub_category_id = (resService.result[0]) ? resService.result[0].sub_category_id : ``
                                    item.sub_category_name = (resService.result[0]) ? resService.result[0].sub_category_name : ``
                                    item.services = resService.result
                                    item.additional_cost = resAdditionalCost
                                    next()
                                })
                            })
                        },()=>{
                            resolve({page_token:parseInt(params.page_token)+1,result:result})
                        })
                    } else {
                        reject()
                    }
                })
            })
        })
    },
    async get_cart_service(service_ids) {
        return new Promise((resolve,reject)=>{
            read.query(`SELECT cs.id, cs.sub_category_id, c.name AS sub_category_name, cs.service_name, cs.price, c.sac_code FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id WHERE cs.id IN (${service_ids})`, (err, result) => {
                if (!err) {
                    read.query(`SELECT s.id, s.name FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id JOIN tbl_category AS s ON s.id = c.parent_id WHERE cs.id IN (${service_ids}) LIMIT 1`, (mErr, mResult) => {
                        resolve({result:result,main:mResult[0]})
                    })
                } else {
                    resolve(false)
                }
            })
        })
    },
    async get_additional_cost(booking_id){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT additional_id,status,payment_mode,payment_status FROM tbl_booking_additional_cost WHERE booking_id = '${booking_id}' AND status = 'accept' GROUP BY additional_id`,(err,result)=>{
                if(!err && result[0] != undefined){
                    asyncLoop(result,(item,next)=>{
                        read.query(`SELECT id,name,value FROM tbl_booking_additional_cost WHERE status != 'reject' AND booking_id = '${booking_id}' AND additional_id = '${item.additional_id}'`,(cErr,cResult)=>{
                            item.costs = cResult
                            next()
                        })
                    },()=>{
                        resolve(result)
                    })
                }else{
                    resolve([])
                }
            })
        })
    },
    async payout_summary(params){
        return new Promise((resolve,reject)=>{
            read.query(`SELECT start_date,end_date,amount,transaction_id,total_jobs,total_amount,cash,online,cash_es_commission,online_es_commission,cash_tds,cash_tcs,card_tds,card_tcs,insert_datetime FROM tbl_admin_transaction WHERE user_id = ${params.login_user_id} ORDER BY insert_datetime DESC LIMIT ${parseInt(params.page_token) * parseInt(GLOBALS.NOTIFICATION_PER_PAGE)},${GLOBALS.NOTIFICATION_PER_PAGE}`,(err,result)=>{
                if(!err && result[0] != undefined){
                    resolve({"page_token":parseInt(params.page_token)+1,"result":result})
                }else{
                    reject();
                }
            })
        })
    },
}

module.exports = model;