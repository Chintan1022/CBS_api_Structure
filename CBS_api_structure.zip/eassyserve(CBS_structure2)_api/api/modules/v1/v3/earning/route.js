const lang = require('../../../config/language');
const earning_model = require('./earning_model');
const common = require('../../../config/common');

const router = require('express').Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Earning Summary                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/earning_summary",(req,res)=>{
    common.decryption(req.body,(params)=>{
        const rules = { "type" : "required|in:day,week,month,year" }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            earning_model.earning_summary(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Earning Summary Detail                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/earning_summary_detail",(req,res)=>{
    common.decryption(req.body,(params)=>{
        const rules = {
            "start_date": "required",
            "end_date": "required",
            "page_token": "required"
        }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id
            earning_model.earning_summary_detail(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Payout Summary                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/payout_summary",(req,res)=>{
    common.decryption(req.body,(params)=>{
        const rules = { page_token: "required" }
        if(common.checkValidation(params, rules, res, req.language))
        {
            params.login_user_id = req.login_user_id;
            earning_model.payout_summary(params).then((resData)=>{
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err)=>{
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
        }
    })
})

module.exports = router;