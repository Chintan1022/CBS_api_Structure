const chat_model = require('./chat_model');
const lang = require('../../../config/language');

class Socket {
    connectSocket() {
        const io = require('socket.io')({
            cors: {
                origin: '*'
            },
            secure: true
        });
        io.listen(5999);

        console.log(`Socket is connected to 5999 port`)

        var users = {};

        const user_chat = io.of('/user').use((socket, next) => {
            return next();
        }).on('connection', (socket) => {
            // get user id
            let user_id = socket.handshake.query.user_id;

            // add user detail in users array
            users[user_id] = socket.id
                // users[user_id] = {
                //    "socket": socket.id
                // }
                // console.log(users)
            console.log(`user ${user_id} is connected`)

            // send message
            socket.on('send_message', (data, callback) => {
                try {
                    data = JSON.parse(data);
                } catch (error) {
                    data = data;
                }
                let request = {
                    chat_id: data.chat_id,
                    message: data.message,
                    type: data.type,
                    user_id: user_id
                }
                chat_model.send_message(request).then((response) => {
                    if (users[response.send_push_id]) {
                        user_chat.to(users[response.send_push_id]).emit('send_message', { code: '1', message: lang['en']['text_details_are'], data: response });
                    }
                    callback({ code: '1', message: lang['en']['text_details_are'], data: response });
                }).catch((error) => {
                    callback({ code: '0', message: lang['en']['something_wrong'] });
                })
            })

            // read message
            socket.on('read_message', (data) => {
                try {
                    data = JSON.parse(data);
                } catch (error) {
                    data = data;
                }
                chat_model.chat_message_read(data.chat_id, user_id);
                if (users[data.user_id]) {
                    user_chat.to(users[data.user_id]).emit('read_message', { user_id: user_id, chat_id: data.chat_id });
                }
            })

            // start typing
            socket.on('start_typing', (data) => {
                if (users[data.user_id]) {
                    chat_socket.to(users[data.user_id]).emit('start_typing', { user_id: user_id, chat_id: data.chat_id });
                }
            })

            // stop typing
            socket.on('stop_typing', (data) => {
                if (users[data.user_id]) {
                    chat_socket.to(users[data.user_id]).emit('stop_typing', { user_id: user_id, chat_id: data.chat_id });
                }
            })

            // disconnect a socket
            socket.on('disconnect', () => {
                let user_index = Object.keys(users).find(key => users[key] == socket.id);
                console.log(`user ${user_index} is disconnected`)
                delete users[user_index];

                // for(var user_id in users){
                //    if(users[user_id].socket === socket.id){
                //        console.log(user_id + " is disconnect");
                //        delete users[user_id];
                //        break;
                //    }
                // }
            })
        })
    }
}

module.exports = new Socket();