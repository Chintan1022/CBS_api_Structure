const { read, write } = require('../../../config/database');
const common = require('../../../config/common');
const asyncLoop = require('node-async-loop');
const lang = require('../../../config/language');
const quickbook = require('../../../config/quickbook');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const template = require('../../../config/template');
const { ToWords } = require('to-words');
const htmlpdf = require('html-pdf');
const toWords = new ToWords({
    converterOptions: {
        currency: true,
        ignoreDecimal: false,
        ignoreZeroCurrency: false,
        doNotAddOnly: false
    }
});
const moment_timezone = require('moment-timezone');

var cron = {
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Booking Accepted Or Not                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async check_booking_accepted_or_not() {
        read.query(`SELECT b.id, b.user_id, b.provider_id, b.order_id, u.parent_id, u.current_language, b.transaction_id, b.final_amount FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id WHERE FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 30 MINUTE) AND (NOW() - INTERVAL 29 MINUTE) AND b.status = 'pending'`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    if (result[0].payment_type == "card") {
                        common.razorpay_refund(result[0].transaction_id, result[0].final_amount, `Booking Id #${result[0].order_id}`).catch((error) => {});
                    }
                    read.query(`SELECT current_language, CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE id = ${item.provider_id} LIMIT 1`, (pErr, pResult) => {
                        var updateData = {
                            status: 'cancelled',
                            cancel_by: 'provider',
                            is_auto_reject: 'true',
                            update_datetime: moment().format("X")
                        }
                        write.query(`UPDATE tbl_booking SET ? WHERE id = ${item.id}`, updateData, (uErr, uResult) => {
                            // send to customer
                            var push_data = {
                                title: lang[item.current_language]['text_booking_not_accepted_title'].replace('{order_id}', item.order_id),
                                body: lang[item.current_language]['text_booking_not_accepted_body'],
                                custom: {
                                    tag: "booking_rejected",
                                    order_id: item.order_id,
                                    booking_id: item.id
                                }
                            }
                            var push_notification = {
                                sender_id: item.provider_id,
                                receiver_id: item.user_id,
                                action_id: item.id,
                                message: JSON.stringify({ title: 'text_booking_not_accepted_title', body: 'text_booking_not_accepted_body' }),
                                tag: 'booking_rejected',
                                insert_datetime: moment().format("X")
                            }
                            this.credit_note_invoice({ id: item.id });
                            common.prepare_notification(item.user_id, push_data)
                            common.add_data('tbl_notification', push_notification, (res) => {})
                                // send to provider
                            var push_data_provider = {
                                title: lang[pResult[0].current_language]['text_booking_not_accepted_provider_title'].replace('{sp_name}', pResult[0].sp_name),
                                body: lang[pResult[0].current_language]['text_booking_not_accepted_provider_body'].replace('{order_id}', item.order_id),
                                custom: {
                                    tag: "booking_missed",
                                    order_id: item.order_id,
                                    booking_id: item.id
                                }
                            }
                            var push_notification_provider = {
                                sender_id: item.provider_id,
                                receiver_id: item.provider_id,
                                action_id: item.id,
                                message: JSON.stringify({ title: 'text_booking_not_accepted_provider_title', body: 'text_booking_not_accepted_provider_body' }),
                                tag: 'booking_missed',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(item.provider_id, push_data_provider)
                            common.add_data('tbl_notification', push_notification_provider, (res) => {})
                            if (item.parent_id != 0) {
                                // send main provider
                                cron.send_sp_staff_missed_booking(item.id, item.order_id, item.parent_id, item.provider_id);
                            }
                            write.query(`UPDATE tbl_user SET total_auto_reject = (SELECT COUNT(id) FROM tbl_booking WHERE provider_id = ${item.provider_id} AND status = 'cancelled' AND cancel_by = 'provider' AND is_auto_reject = 'true') WHERE id = ${item.provider_id}`);
                            next()
                        })
                    })
                })
            }
        })
    },
    async send_sp_staff_missed_booking(booking_id, order_id, parent_id, staff_id) {
        read.query(`SELECT CONCAT(s.first_name,' ',s.last_name) AS name, m.current_language FROM tbl_user AS s JOIN tbl_user AS m ON m.id = s.parent_id WHERE s.id = ${staff_id} LIMIT 1`, (err, result) => {
            var push_data_provider = {
                title: lang[result[0].current_language]['text_booking_not_accepted_main_provider_title'],
                body: lang[result[0].current_language]['text_booking_not_accepted_main_provider_body'].replace('{order_id}', order_id).replace('{staff_id}', staff_id).replace('{name}', result[0].name),
                custom: {
                    tag: "booking_missed_by_staff",
                    order_id: order_id,
                    booking_id: booking_id
                }
            }
            var push_notification_provider = {
                sender_id: staff_id,
                receiver_id: parent_id,
                action_id: booking_id,
                message: JSON.stringify({ title: 'text_booking_not_accepted_main_provider_title', body: 'text_booking_not_accepted_main_provider_body' }),
                tag: 'booking_missed_by_staff',
                insert_datetime: moment().format("X")
            }
            common.prepare_notification(parent_id, push_data_provider)
            common.add_data('tbl_notification', push_notification_provider, (res) => {})
        })
    },
    async credit_note_invoice(params) {
        read.query(`SELECT b.id,b.order_id,b.date,b.invoice_number,b.advance_receipt_number,b.place_to_supply,b.place_to_delivery,b.sgst,b.cgst,b.igst,b.sgst_amount,b.cgst_amount,b.igst_amount,p.first_name AS first_name_provider,p.last_name AS last_name_provider,p.parent_id,b.provider_id,p.region_location,b.type,b.address,u.first_name,u.last_name,u.email,b.service_ids,b.total_amount,b.discount_amount,b.final_amount,b.payment_type,b.total_gst FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.user_id JOIN tbl_user AS p ON p.id = b.provider_id WHERE b.id = ${params.id} LIMIT 1`, (err, result) => {
            if (!err && result[0] != undefined) {
                this.get_cart_service(result[0].service_ids).then((resService) => {
                    this.get_additional_cost(result[0].id).then((resAdditionalCost) => {
                        read.query(`SELECT gst,commission,flat FROM tbl_user WHERE id = ${((result[0].parent_id == 0) ? result[0].provider_id : result[0].parent_id)} LIMIT 1`, (sErr, sResult) => {
                            read.query(`SELECT name FROM tbl_user_document WHERE user_id = ${((result[0].parent_id == 0) ? result[0].provider_id : result[0].parent_id)} AND type = 'pan_number' LIMIT 1`, (spErr, spResult) => {
                                read.query(`SELECT tin_number FROM tbl_state_code WHERE state_name = '${result[0].place_to_delivery}' LIMIT 1`, (stateErr, stateResult) => {
                                    result[0].services = resService.result
                                    result[0].additional_cost = resAdditionalCost
                                    result[0].address = (result[0].address) ? JSON.parse(result[0].address) : {}
                                    var services = ``;
                                    var num = 1;
                                    result[0].services.map(element => {
                                        services +=
                                            `<tr>` +
                                            `<td style="border: 1px solid #ccc"><b>${num}</b></td>` +
                                            `<td style="border: 1px solid #ccc">${element.service_name}</td>` +
                                            `<td style="border: 1px solid #ccc">${element.sac_code}</td>` +
                                            `<td style="border: 1px solid #ccc">inr ${element.price}</td>` +
                                            `<td style="border: 1px solid #ccc">1</td>` +
                                            `<td style="border: 1px solid #ccc">inr ${element.price}</td>` +
                                            `</tr>`;
                                        num++;
                                    });
                                    result[0].additional_cost.map(element => {
                                        if (element.status == "accept") {
                                            element.costs.map(element1 => {
                                                result[0].total_amount += element1.value;
                                                result[0].final_amount += element1.value;
                                                result[0].total_gst += element1.total_gst;
                                                services +=
                                                    `<tr>` +
                                                    `<td style="border: 1px solid #ccc"><b>${num}</b></td>` +
                                                    `<td style="border: 1px solid #ccc">${element1.name}</td>` +
                                                    `<td style="border: 1px solid #ccc"></td>` +
                                                    `<td style="border: 1px solid #ccc">inr ${element1.value}</td>` +
                                                    `<td style="border: 1px solid #ccc">1</td>` +
                                                    `<td style="border: 1px solid #ccc">inr ${element1.value}</td>` +
                                                    `</tr>`;
                                                num++;
                                            });
                                        }
                                    });
                                    let discount = ``;
                                    if (result[0].discount_amount != 0) {
                                        discount = `<tr>` +
                                            `<td style="border: 1px solid #ccc"></td>` +
                                            `<td style="border: 1px solid #ccc"><b>discount amount</b></td>` +
                                            `<td style="border: 1px solid #ccc"></td>` +
                                            `<td style="border: 1px solid #ccc"></td>` +
                                            `<td style="border: 1px solid #ccc"></td>` +
                                            `<td style="border: 1px solid #ccc">inr ${result[0].discount_amount}</td>` +
                                            `</tr>`;
                                    }
                                    var credit_note_invoice = {
                                        invoice_number: result[0].invoice_number,
                                        invoice_date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        supplier_name: `${result[0].first_name_provider} ${result[0].last_name_provider}`,
                                        billing_name: `${result[0].first_name} ${result[0].last_name}`,
                                        supplier_place: result[0].region_location,
                                        billing_place: (result[0].type == "home_visit") ? result[0].address.location : ``,
                                        date: moment_timezone().tz("asia/kolkata").format("DD/MM/YYYY"),
                                        pan_number: spResult[0].name,
                                        gst_number: sResult[0].gst,
                                        booking_id: result[0].id,
                                        order_id: result[0].order_id,
                                        booking_date: result[0].date,
                                        advance_receipt_number: result[0].advance_receipt_number,
                                        state_code: (!stateErr && stateResult[0] != undefined) ? stateResult[0].tin_number : ``,
                                        place_supply: result[0].place_to_supply,
                                        services: services,
                                        net_amount: result[0].total_amount,
                                        discount: discount,
                                        cgst: result[0].cgst,
                                        cgst_amount: result[0].cgst_amount,
                                        sgst: result[0].sgst,
                                        sgst_amount: result[0].sgst_amount,
                                        igst: result[0].igst,
                                        igst_amount: result[0].igst_amount,
                                        total_amount: (parseFloat(result[0].final_amount)).toFixed(2),
                                        total_amount_in_word: toWords.convert((parseFloat(result[0].final_amount)).toFixed(2)),
                                        invoice_link: ``,
                                        rcm: (sResult[0].gst == '') ? 'yes' : 'no'
                                    }
                                    template.credit_note_to_customer(credit_note_invoice, (html) => {
                                        htmlpdf.create(html, { format: 'A4' }).toStream((errInvoice, resInvoice) => {
                                            s3.upload({
                                                Bucket: GLOBALS.S3_BUCKET_NAME,
                                                Key: `invoice/credit-note-${result[0].invoice_number}.pdf`,
                                                ACL: "public-read",
                                                Body: resInvoice
                                            }, (errS3, resS3) => {
                                                credit_note_invoice.invoice_link = `<a href="${resS3.Location}">Click Here To Download Invoice</a>`;
                                                template.credit_note_to_customer(credit_note_invoice, (html) => {
                                                    common.send_email(GLOBALS.APP_NAME + " <" + GLOBALS.EMAIL_ID + ">", `Credit Note Invoice For ${result[0].order_id} from EASSY INNOVATIVE SERVICES PRIVATE LIMITED`, result[0].email, html, (resEmail) => {});
                                                });
                                            });
                                        });
                                    });
                                })
                            })
                        })
                    })
                })
            }
        })
    },
    get_cart_service: function(service_ids) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT cs.id, cs.sub_category_id, c.name AS sub_category_name, cs.service_name, cs.price, c.sac_code FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id WHERE cs.id IN (${service_ids})`, (err, result) => {
                if (!err) {
                    read.query(`SELECT s.id, s.name FROM tbl_category_service AS cs JOIN tbl_category AS c ON c.id = cs.sub_category_id JOIN tbl_category AS s ON s.id = c.parent_id WHERE cs.id IN (${service_ids}) LIMIT 1`, (mErr, mResult) => {
                        resolve({ result: result, main: mResult[0] })
                    })
                } else {
                    resolve(false)
                }
            })
        })
    },
    async get_additional_cost(booking_id) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT additional_id,status,payment_mode,payment_status FROM tbl_booking_additional_cost WHERE booking_id = '${booking_id}' AND status != 'reject' GROUP BY additional_id`, (err, result) => {
                if (!err && result[0] != undefined) {
                    asyncLoop(result, (item, next) => {
                        read.query(`SELECT id,name,value FROM tbl_booking_additional_cost WHERE status != 'reject' AND booking_id = '${booking_id}' AND additional_id = '${item.additional_id}'`, (cErr, cResult) => {
                            this.get_additional_cost_images(booking_id, item.additional_id).then((resAdditionalCostImages) => {
                                item.costs = cResult
                                item.images = resAdditionalCostImages
                                next()
                            })
                        })
                    }, () => {
                        resolve(result)
                    })
                } else {
                    resolve([])
                }
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Booking Request Reminder                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async booking_request_reminder() {
        read.query(`SELECT b.id, b.order_id, b.provider_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE (FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 5 MINUTE) AND (NOW() - INTERVAL 4 MINUTE) OR FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 9 MINUTE) AND (NOW() - INTERVAL 8 MINUTE) OR FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 13 MINUTE) AND (NOW() - INTERVAL 12 MINUTE) OR FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 17 MINUTE) AND (NOW() - INTERVAL 16 MINUTE) OR FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 21 MINUTE) AND (NOW() - INTERVAL 20 MINUTE) OR FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 25 MINUTE) AND (NOW() - INTERVAL 24 MINUTE) OR FROM_UNIXTIME(b.insert_datetime) BETWEEN (NOW() - INTERVAL 29 MINUTE) AND (NOW() - INTERVAL 28 MINUTE)) AND b.status = 'pending'`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    // send to provider
                    var push_data_provider = {
                        title: lang[item.current_language]['text_booking_request_reminder_title'].replace('{sp_name}', item.sp_name),
                        body: lang[item.current_language]['text_booking_request_reminder_body'].replace('{order_id}', item.order_id),
                        custom: {
                            tag: "booking_request_reminder",
                            order_id: item.order_id,
                            booking_id: item.id
                        }
                    }
                    var push_notification_provider = {
                        sender_id: item.provider_id,
                        receiver_id: item.provider_id,
                        action_id: item.id,
                        message: JSON.stringify({ title: 'text_booking_request_reminder_title', body: 'text_booking_request_reminder_body' }),
                        tag: 'booking_request_reminder',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.provider_id, push_data_provider)
                        // common.add_data('tbl_notification',push_notification_provider,(res)=>{})
                    next()
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            Remove Past Cart Added                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async remove_past_cart_added() {
        read.query(`SELECT GROUP_CONCAT(id) AS ids FROM tbl_cart WHERE date < CURRENT_DATE()`, (err, result) => {
            if (!err && result[0] != undefined && result[0].ids != null) {
                write.query(`DELETE FROM tbl_cart WHERE id IN (${result[0].ids})`)
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Provider Offer Live                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async provider_offer_live() {
        read.query(`SELECT o.id, o.user_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_offer AS o JOIN tbl_user AS u ON u.id = o.user_id WHERE o.start_date = CURRENT_DATE() AND o.added_by = 'provider'`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    var push_data = {
                        title: lang[item.current_language]['text_offer_live_title'].replace('{sp_name}', item.sp_name),
                        body: lang[item.current_language]['text_offer_live_body'],
                        custom: {
                            tag: "offer_live",
                            offer_id: item.id
                        }
                    }
                    var push_notification = {
                        sender_id: item.user_id,
                        receiver_id: item.user_id,
                        action_id: item.id,
                        message: JSON.stringify({ title: 'text_offer_live_title', body: 'text_offer_live_body' }),
                        tag: 'offer_live',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.user_id, push_data)
                    common.add_data('tbl_notification', push_notification, (res) => {})
                    next();
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Today Total Service                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async today_total_service() {
        read.query(`SELECT b.provider_id, COUNT(b.id) AS total, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_booking AS b JOIN tbl_user AS u ON u.id = b.provider_id WHERE b.date = CURRENT_DATE() GROUP BY b.provider_id`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    var push_data = {
                        title: lang[item.current_language]['text_today_total_service_title'].replace('{sp_name}', item.sp_name),
                        body: lang[item.current_language]['text_today_total_service_body'].replace('{total}', item.total),
                        custom: {
                            tag: "today_total_service"
                        }
                    }
                    var push_notification = {
                        sender_id: 0,
                        receiver_id: item.provider_id,
                        action_id: 0,
                        message: JSON.stringify({ title: 'text_today_total_service_title', body: 'text_today_total_service_body', total: item.total }),
                        tag: 'today_total_service',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.provider_id, push_data)
                    common.add_data('tbl_notification', push_notification, (res) => {})
                    next();
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Reminder                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async register_incomplete_reminder() {
        read.query(`SELECT u.id, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_user AS u LEFT JOIN tbl_user_document AS ud ON ud.user_id = u.id WHERE u.sub_category = '' AND u.role = 'provider' GROUP BY u.id`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    var push_data = {
                        title: lang[item.current_language]['text_register_reminder_title'].replace('{sp_name}', item.sp_name),
                        body: lang[item.current_language]['text_register_reminder_body'],
                        custom: {
                            tag: "register_reminder",
                        }
                    }
                    var push_notification = {
                        sender_id: 0,
                        receiver_id: item.id,
                        action_id: item.id,
                        message: JSON.stringify({ title: 'text_register_reminder_title', body: 'text_register_reminder_body' }),
                        tag: 'register_reminder',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.id, push_data);
                    common.add_data('tbl_notification', push_notification, (res) => {});
                    next();
                });
            }
        });
    },
    async availability_not_set_reminder() {
        read.query(`SELECT GROUP_CONCAT(DISTINCT user_id) AS user_ids FROM tbl_availability LIMIT 1`, (aErr, aResult) => {
            if (!aErr && aResult[0] != undefined) {
                read.query(`SELECT id,CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE role = 'provider' AND id NOT IN (${aResult[0].user_ids})`, (err, result) => {
                    if (!err && result[0] != undefined) {
                        asyncLoop(result, (item, next) => {
                            var push_data = {
                                title: lang[item.current_language]['text_availability_not_set_reminder_title'].replace('{sp_name}', item.sp_name),
                                body: lang[item.current_language]['text_availability_not_set_reminder_body'],
                                custom: {
                                    tag: "availability_not_set_reminder",
                                }
                            }
                            var push_notification = {
                                sender_id: 0,
                                receiver_id: item.id,
                                action_id: item.id,
                                message: JSON.stringify({ title: 'text_availability_not_set_reminder_title', body: 'text_availability_not_set_reminder_body' }),
                                tag: 'availability_not_set_reminder',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(item.id, push_data);
                            common.add_data('tbl_notification', push_notification, (res) => {});
                            next();
                        });
                    }
                });
            }
        });
    },
    async rate_card_not_set_reminder() {
        read.query(`SELECT GROUP_CONCAT(DISTINCT user_id) AS user_ids FROM tbl_category_service`, (aErr, aResult) => {
            if (!aErr && aResult[0] != undefined) {
                read.query(`SELECT id,CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE role = 'provider' AND id NOT IN (${aResult[0].user_ids})`, (err, result) => {
                    if (!err && result[0] != undefined) {
                        asyncLoop(result, (item, next) => {
                            var push_data = {
                                title: lang[item.current_language]['text_rate_card_not_set_reminder_title'].replace('{sp_name}', item.sp_name),
                                body: lang[item.current_language]['text_rate_card_not_set_reminder_body'],
                                custom: {
                                    tag: "rate_card_not_set_reminder",
                                }
                            }
                            var push_notification = {
                                sender_id: 0,
                                receiver_id: item.id,
                                action_id: item.id,
                                message: JSON.stringify({ title: 'text_rate_card_not_set_reminder_title', body: 'text_rate_card_not_set_reminder_body' }),
                                tag: 'rate_card_not_set_reminder',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(item.id, push_data);
                            common.add_data('tbl_notification', push_notification, (res) => {});
                            next();
                        });
                    }
                });
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        Provider Offer End Reminder                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async provider_offer_end_remainder() {
        read.query(`SELECT o.id, o.user_id, u.current_language, CONCAT(u.first_name,' ',u.last_name) AS sp_name FROM tbl_offer AS o JOIN tbl_user AS u ON u.id = o.user_id WHERE o.end_date = DATE_ADD(CURRENT_DATE(),INTERVAL 1 DAY) AND o.added_by = 'provider'`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    var push_data = {
                        title: lang[item.current_language]['text_offer_end_reminder_title'].replace('{sp_name}', item.sp_name),
                        body: lang[item.current_language]['text_offer_end_reminder_body'],
                        custom: {
                            tag: "offer_end_reminder",
                            offer_id: item.id
                        }
                    }
                    var push_notification = {
                        sender_id: item.user_id,
                        receiver_id: item.user_id,
                        action_id: item.id,
                        message: JSON.stringify({ title: 'text_offer_end_reminder_title', body: 'text_offer_end_reminder_body' }),
                        tag: 'offer_end_reminder',
                        insert_datetime: moment().format("X")
                    }
                    common.prepare_notification(item.user_id, push_data)
                    common.add_data('tbl_notification', push_notification, (res) => {})
                    next();
                })
            }
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Work Region Not Set Reminder                           /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async region_reminder() {
        read.query(`SELECT id, current_language, CONCAT(first_name,' ',last_name) AS sp_name FROM tbl_user WHERE region_raduis = 0 AND role = 'provider' AND parent_id = 0`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    this.check_user_register_complete(item.id).then((resComplete) => {
                        if (resComplete == "done") {
                            var push_data = {
                                title: lang[item.current_language]['text_region_reminder_title'].replace('{sp_name}', item.sp_name),
                                body: lang[item.current_language]['text_region_reminder_body'],
                                custom: {
                                    tag: "region_reminder"
                                }
                            }
                            var push_notification = {
                                sender_id: item.id,
                                receiver_id: item.id,
                                action_id: item.id,
                                message: JSON.stringify({ title: 'text_region_reminder_title', body: 'text_region_reminder_body' }),
                                tag: 'region_reminder',
                                insert_datetime: moment().format("X")
                            }
                            common.prepare_notification(item.id, push_data)
                            common.add_data('tbl_notification', push_notification, (res) => {})
                            next();
                        } else {
                            next();
                        }
                    });
                })
            }
        })
    },
    async check_user_register_complete(id) {
        return new Promise((resolve, reject) => {
            let is_complete = 'done'
            read.query(`SELECT id FROM tbl_user_bank_detail WHERE user_id = '${id}'`, (bErr, bResult) => {
                if (bResult[0] == undefined) {
                    is_complete = 'bank'
                }
                read.query(`SELECT id FROM tbl_user_document WHERE user_id = '${id}'`, (dErr, dResult) => {
                    if (dResult[0] == undefined) {
                        is_complete = 'document'
                    }
                    read.query(`SELECT sub_category FROM tbl_user WHERE id = '${id}'`, (oErr, oResult) => {
                        if (oResult[0].sub_category == '') {
                            is_complete = 'other'
                        }
                        resolve(is_complete)
                    })
                })
            })
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                         Rate Card Not Set Reminder                             /////
    //////////////////////////////////////////////////////////////////////////////////////////
    // async rate_card_not_set_reminder()
    // {
    //     read.query(``,(err,result)=>{
    //         if(!err && result[0] != undefined){
    //             asyncLoop(result,(item,next)=>{
    //                 var push_data = {
    //                     title: lang[item.current_language]['text_region_reminder_title'].replace('{sp_name}',item.sp_name),
    //                     body: lang[item.current_language]['text_region_reminder_body'],
    //                     custom: {
    //                         tag: "region_reminder"
    //                     }
    //                 }
    //                 var push_notification = {
    //                     sender_id: item.id,
    //                     receiver_id: item.id,
    //                     action_id: item.id,
    //                     message: JSON.stringify({title:'text_region_reminder_title',body:'text_region_reminder_body'}),
    //                     tag: 'region_reminder',
    //                     insert_datetime: moment().format("X")
    //                 }
    //                 common.prepare_notification(item.id,push_data)
    //                 common.add_data('tbl_notification',push_notification,(res)=>{})
    //                 next();
    //             })
    //         }
    //     })
    // },

    async get_user() {
        read.query(`SELECT id,CONCAT('ES-',first_name,' ',last_name,'-',id) AS name,mobile_number,email,quickbook_customer_id FROM tbl_user WHERE quickbook_customer_id != '0' ORDER BY quickbook_customer_id`, (err, result) => {
            if (!err && result[0] != undefined) {
                asyncLoop(result, (item, next) => {
                    console.log(item.quickbook_customer_id, item.name)
                    quickbook.edit_customer({ name: item.name, mobile_number: item.mobile_number, quickbook_customer_id: item.quickbook_customer_id, email: item.email });
                    next();
                })
            }
        });
    }
}

module.exports = cron;