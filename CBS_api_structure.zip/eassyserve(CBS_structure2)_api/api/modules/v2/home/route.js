const express = require('express');
const lang = require('../../../config/language');
const home_model = require('./home_model');
const common = require('../../../config/common');
const moment = require('moment');

const router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Home Status                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/home_status", function(req, res) {
    common.decryption(req.body, function(params) {
        // var rules = { "page_token" : "required" }
        rules = {};
        if (common.checkValidation(params, rules, res, req.language)) {
            if (params.guest_id) {
                params.login_guest_id = params.guest_id
            } else {
                params.login_user_id = req.login_user_id
            }
            home_model.home_status(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_sql_err'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Category List                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/category_list", function(req, res) {
    common.decryption(req.body, function(params) {
        // var rules = { "page_token" : "required" }
        // if(common.checkValidation(params, rules, res, req.language))
        // {
        home_model.category_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
            // }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Category List                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/home_category_list", function(req, res) {
    common.decryption(req.body, function(params) {
        // var rules = { "page_token" : "required" }
        // if(common.checkValidation(params, rules, res, req.language))
        // {
        home_model.home_category_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
            // }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Notification List                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/notification_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            page_token: "required",
            type: "required|in:order_related,promotions"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            params.language = req.language
            home_model.notification_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['notification_list'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['notification_list_not_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Clear Notification                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/clear_notification", function(req, res) {
    home_model.clear_notification(req.login_user_id).then((resData) => {
        common.sendResponse(res, "1", lang[req.language]['clear_notification'], null)
    }).catch((err) => {
        common.sendResponse(res, "0", lang[req.language]['something_wrong'], null)
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Add Address                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_address", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            location: 'required',
            latitude: 'required',
            longitude: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.add_address(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_add_address_success'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_add_address_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Edit Address                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/edit_address", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            id: 'required',
            location: 'required',
            latitude: 'required',
            longitude: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.edit_address(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_address_update'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_edit_address_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Get Address List                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/address_list", function(req, res) {
    home_model.address_list(req.login_user_id).then((resData) => {
        common.sendResponse(res, "1", lang[req.language]['text_user_address_list_found'], resData)
    }).catch((err) => {
        common.sendResponse(res, "2", lang[req.language]['text_user_address_list_not_found'], null)
    })
})


//////////////////////////////////////////////////////////////////////////////////////////
/////                            Set Default Address                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/set_default_address", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.set_default_address(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_address_deleted'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_address_delete_fails'], null)
            })
        }
    })
})


//////////////////////////////////////////////////////////////////////////////////////////
/////                            Get Default Address                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_default_address", function(req, res) {
    common.decryption(req.body, function(params) {
        // var rules = { id: 'required' }
        // if(common.checkValidation(params, rules, res, req.language))
        // {
        params.login_user_id = req.login_user_id
        home_model.get_default_address(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_default_address_su'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_user_default_address_un'], null)
            })
            // }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Delete Address                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/delete_address", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.delete_address(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_address_deleted'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_address_delete_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Add Card                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_card", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            name_on_card: 'required',
            card_number: 'required',
            expiry_date: 'required',
            expiry_month: 'required',
            cvv: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.add_card(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_add_card_success'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_add_card_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Delete Card                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/delete_card", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.delete_card(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_user_card_deleted'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_user_card_delete_fails'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Get Card List                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/card_list", function(req, res) {
    home_model.card_list(req.login_user_id).then((resData) => {
        common.sendResponse(res, "1", lang[req.language]['text_user_card_list_found'], resData)
    }).catch((err) => {
        common.sendResponse(res, "2", lang[req.language]['text_user_card_list_not_found'], null)
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Service Provider List                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/service_provider_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            sub_category_id: 'required',
            latitude: 'required',
            longitude: 'required',
            page_token: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.service_provider_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_provider_not_available'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                        Service Provider Available                              /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/service_provider_available", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            provider_id: 'required',
            start_date: 'required',
            end_date: 'required',
            sub_category_id: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id;
            common.get_provider_ids(params.provider_id, params.sub_category_id).then((resIds) => {
                params.ids = resIds.ids;
                home_model.get_available_month_slot(params).then((resData) => {
                    common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
                }).catch((err) => {
                    common.sendResponse(res, "2", lang[req.language]['text_service_provider_not_available'], null)
                })
            }).catch((err) => {
                params.ids = req.login_user_id;
                home_model.get_available_month_slot(params).then((resData) => {
                    common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
                }).catch((err) => {
                    common.sendResponse(res, "2", lang[req.language]['text_service_provider_not_available'], null)
                })
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Filter List                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/filter_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "category_id": "required" }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.filter_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_empty_list'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Service Provider Details                               /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/service_provider_details", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required', sub_category_id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.service_provider_details(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_provider_profile_not_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Add To Cart                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/add_to_cart", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            provider_id: 'required',
            date: 'required',
            time: 'required',
            type: 'required|in:home_visit,store_visit',
            service_ids: 'required',
            place_to_supply: 'required',
            place_to_delivery: 'required',
            // description: 'required',
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            let insertData = {};
            if (params.guest_id) {
                insertData = {
                    guest_id: params.guest_id,
                    provider_id: params.provider_id,
                    date: params.date,
                    time: params.time,
                    type: params.type,
                    service_ids: params.service_ids,
                    ...(params.place_to_supply) && { place_to_supply: params.place_to_supply },
                    ...(params.place_to_delivery) && { place_to_delivery: params.place_to_delivery },
                    ...(params.is_local) && { is_local: params.is_local },
                    ...(params.address) && { address: JSON.stringify(params.address) },
                    ...(params.description) && { description: params.description },
                    insert_datetime: moment().format("X"),
                    update_datetime: moment().format("X")
                }
            } else {
                insertData = {
                    user_id: req.login_user_id,
                    provider_id: params.provider_id,
                    date: params.date,
                    time: params.time,
                    type: params.type,
                    service_ids: params.service_ids,
                    ...(params.place_to_supply) && { place_to_supply: params.place_to_supply },
                    ...(params.place_to_delivery) && { place_to_delivery: params.place_to_delivery },
                    ...(params.is_local) && { is_local: params.is_local },
                    ...(params.address) && { address: JSON.stringify(params.address) },
                    ...(params.description) && { description: params.description },
                    insert_datetime: moment().format("X"),
                    update_datetime: moment().format("X")
                }
            }
            home_model.add_to_cart(insertData).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_add_to_cart_su'], { id: resData.insertId })
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_add_to_cart_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Get Cart Service                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_cart_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {}
        if (common.checkValidation(params, rules, res, req.language)) {
            if (params.guest_id) {
                params.login_guest_id = params.guest_id
            } else {
                params.login_user_id = req.login_user_id
            }
            home_model.add_to_cart_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_get_cart_su'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_get_cart_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Delete Cart Service                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/delete_cart_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            if (params.guest_id) {
                params.login_guest_id = params.guest_id
            } else {
                params.login_user_id = req.login_user_id
            }
            home_model.delete_cart_service(params).then((resData) => {
                if (resData.code == "1") {
                    common.sendResponse(res, "1", lang[req.language]['text_delete_cart_su'], resData.result)
                } else {
                    common.sendResponse(res, "2", lang[req.language]['text_delete_cart_su'], null)
                }
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_delete_cart_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Available Offer                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/available_offer", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            provider_id: 'required',
            category_id: 'required',
            sub_category_id: 'required',
            page_token: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.get_available_offer(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_offer_no_available'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Available Offer                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/verify_promocode", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            services: 'required',
            promocode: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.verify_promocode(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_offer_no_available'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////   2674                       Check Provider Available                              /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/check_provider_available", function(req, res) {
    common.decryption(req.body, function(params) {
        console.log("check params ", params);
        var rules = { services: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.check_provider_available(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_provider_not_available'].replace('{provider_names}', err), null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Book Service                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
// router.post("/book_service", function(req, res) {
//     common.decryption(req.body, function(params) {
//         var rules = {
//             payment_type: 'required|in:card,cash',
//             transaction_id: 'required',
//             amount: 'required',
//             payment_status: 'required|in:paid,unpaid',
//             services: 'required'
//         }
//         if (params.payment_type == "card") {
//             rules.card_id = "required"
//         }
//         if (common.checkValidation(params, rules, res, req.language)) {
//             params.login_user_id = req.login_user_id
//             if (params.payment_type == "card") {
//                 common.razorpay_capture(params.transaction_id, params.amount).then((response) => {}).catch((error) => {});
//             }
//             home_model.book_service(params).then((resData) => {
//                 common.sendResponse(res, "1", lang[req.language]['text_book_su'], resData)
//             }).catch((err) => {
//                 common.sendResponse(res, "0", lang[req.language]['text_book_un'], null)
//             })
//         }
//     })
// })

router.post("/book_service", function(req, res) {
        common.decryption(req.body, function(params) {
            var rules = {
                payment_type: 'required|in:card,cash',
                transaction_id: 'required',
                amount: 'required',
                payment_status: 'required|in:paid,unpaid',
                services: 'required'
            }
            if (params.payment_type == "card") {
                rules.card_id = "required"
            }
            if (common.checkValidation(params, rules, res, req.language)) {
                console.log('Booking params ', params);
                params.login_user_id = req.login_user_id
                if (params.payment_type == "card") {
                    common.razorpay_capture(params.transaction_id, params.amount).then((response) => {}).catch((error) => {});
                }
                console.log('Booking params ', params);
                home_model.book_service(params).then((resData) => {
                    console.log('resData ', resData);
                    common.sendResponse(res, "1", lang[req.language]['text_book_su'], resData)
                }).catch((err) => {
                    common.sendResponse(res, "0", lang[req.language]['text_book_un'], null)
                })
            }
        })
    })
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                My Service                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
router.post("/my_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            status: 'required|in:today,pending,upcoming,completed,cancelled',
            page_token: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.my_service(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           My Service Details                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/my_service_details", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.my_service_details(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Re-Sechedule Service                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/reschedule_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            id: 'required',
            provider_id: 'required',
            date: 'required',
            time: 'required',
            sub_category_name: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.reschedule_service(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], null)
            }).catch((err) => {
                if (err == false) {
                    common.sendResponse(res, "0", lang[req.language]['text_book_service_rechedule_su'], null)
                } else {
                    common.sendResponse(res, "0", lang[req.language]['text_provider_not_available'].replace('{provider_names}', err), null)
                }
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Cancel Service                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/cancel_service", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            id: 'required',
            reason: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.cancel_service(params).then((resData) => {
                if (resData.code == "0") {
                    if (resData.status == "cancelled") {
                        common.sendResponse(res, "0", lang[req.language]['text_book_service_already'], null)
                    } else {
                        common.sendResponse(res, "0", lang[req.language]['text_book_service_not_cancel_un'].replace('{status}', resData.status), null)
                    }
                } else {
                    common.sendResponse(res, "1", lang[req.language]['text_book_service_cancel_su'], null)
                }
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_book_service_cancel_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                          Service Provider Fav Unfav                            /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/provider_favorite_unfavorite", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { provider_id: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.provider_fav_unfav(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_fav_unfav_su'].replace('{field}', resData), { type: resData })
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_fav_unfav_un'].replace('{field}', err), null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                          Favorite Provider List                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/provider_favorite_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { page_token: 'required' }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.provider_fav_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_fav_unfav_su'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_fav_unfav_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Service Provider Charges                               /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/provider_services_charges", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            id: 'required',
            sub_category_id: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.get_provider_service(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Booking Experience                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/booking_experience", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            booking_id: 'required',
            experience: 'required',
            arrived_on_time: 'required',
            finished_on_time: 'required',
            polite: 'required',
            overall_satisfaction: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.add_booking_experience(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_booking_experience_su'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_booking_experience_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Booking Report Issue                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/booking_report_issue", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            booking_id: 'required',
            reason: 'required',
            description: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.add_booking_report_issue(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_booking_report_issue_su'], null)
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['text_booking_report_issue_un'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Get Review List                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_review_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            provider_id: 'required',
            page_token: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.get_review_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_no_review_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                          Additional Cost Action                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/additional_cost_action", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            additional_id: 'required',
            booking_id: 'required',
            action: 'required|in:accept,reject'
        }
        if (params.action == "accept") {
            rules.payment_mode = 'required|in:cash,card';
            rules.payment_status = 'required|in:paid,unpaid';
            if (params.payment_mode == "card") {
                rules.transaction_id = 'required';
            }
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.additional_cost_action(params).then((resData) => {
                if (resData.code == 1) {
                    common.sendResponse(res, "1", lang[req.language]['text_additional_cost_action_su'].replace('{action}', params.action), null)
                } else {
                    let message = (resData.code == 0) ? lang[req.language]['text_additional_cost_action_un'].replace('{action}', params.action) : lang[req.language]['text_additional_cost_already'].replace('{action}', resData.status)
                    common.sendResponse(res, resData.code, message, resData)
                }
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['something_wrong'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                       Provider Sub Category List                               /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/provider_sub_category_list", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            provider_id: 'required',
            page_token: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.provider_sub_category_list(params).then((resData) => {
                common.sendResponse(res, "1", lang[req.language]['text_details_are'], resData)
            }).catch((err) => {
                common.sendResponse(res, "2", lang[req.language]['text_service_no_found'], null)
            })
        }
    })
})

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Provider Service On Off                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/check_provider_service_on_off", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            provider_id: 'required',
            service_ids: 'required'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.provider_service_on_off(params).then((resData) => {
                if (resData.code == 1) {
                    common.sendResponse(res, "1", lang[req.language]['text_additional_cost_action_su'].replace('{action}', params.action), null)
                } else {
                    var message = (resData.status == 2 && resData.service_name == undefined) ? lang[req.language]['text_provider_inactive'] : lang[req.language]['text_provider_service_not_provide'].replace('{service_name}', resData.service_name)
                    common.sendResponse(res, resData.code, message, resData)
                }
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['something_wrong'], null)
            })
        }
    })
})


//////////////////////////////////////////////////////////////////////////////////////////
/////                                Home Search API                                     /////
//////////////////////////////////////////////////////////////////////////////////////////

router.post("/home_search", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            search_val: 'required',
            flag: 'required|in:services,service_provider',
            latitude: 'required',
            longitude: 'required',
            page_token: 'required',
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.login_user_id = req.login_user_id
            home_model.search_service_provider_details(params).then((resData) => {
                if (resData != 0) {
                    common.sendResponse(res, "1", lang[req.language]['text_home_search_services_res'].replace('{action}', params.action), resData)
                } else {
                    common.sendResponse(res, "0", lang[req.language]['text_home_search_services_not_res'].replace('{action}', params.action))
                }
            }).catch((err) => {
                common.sendResponse(res, "0", lang[req.language]['something_wrong'], null)
            })
        }
    })
})




module.exports = router;
module.exports = router;