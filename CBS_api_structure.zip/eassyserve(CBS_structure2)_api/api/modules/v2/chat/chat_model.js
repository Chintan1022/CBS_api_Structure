const { read, write } = require('../../../config/database');
const { S3_URL, USER_IMAGE, CHAT_PER_PAGE, CHAT_IMAGE } = require('../../../config/constants');
const moment = require('moment');
const asyncLoop = require('node-async-loop');
const { prepare_notification } = require('../../../config/common');

const model = {

    async recent_chat_list(params) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT room.id AS chat_id,u.id AS user_id,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image FROM (tbl_chat_room AS room,tbl_user AS u) JOIN tbl_chat_reply AS r ON r.chat_id = room.id WHERE 
            (CASE 
                WHEN room.user_id1 = ${params.login_user_id} THEN room.user_id2 = u.id 
                WHEN room.user_id2 = ${params.login_user_id} THEN room.user_id1 = u.id
            END) AND (room.user_id1 = ${params.login_user_id} OR room.user_id2 = ${params.login_user_id}) GROUP BY room.id ORDER BY room.update_datetime DESC LIMIT ${parseInt(params.page_token) * parseInt(CHAT_PER_PAGE)},${CHAT_PER_PAGE}`, (err, result) => {
                if (!err && result[0] != undefined) {
                    asyncLoop(result, (item, next) => {
                        this.get_chat_count(item.chat_id, item.user_id).then((resUnreadCount) => {
                            item.unread_count = resUnreadCount;
                            this.get_last_message(item.chat_id).then((resLastMessage) => {
                                item.message = resLastMessage.message;
                                item.type = resLastMessage.type;
                                item.insert_datetime = resLastMessage.insert_datetime;
                                next();
                            }).catch((error) => {
                                item.message = ``;
                                item.type = `text`;
                                item.insert_datetime = ``;
                                next();
                            })
                        })
                    }, () => {
                        resolve({ result: result, page_token: parseInt(params.page_token) + 1 });
                    })
                } else {
                    reject();
                }
            })
        })
    },
    async get_last_message(chat_id) {
        return new Promise((resolve, reject) => {
            read.query({
                sql: `SELECT message,type,insert_datetime FROM tbl_chat_reply WHERE chat_id = ${chat_id} ORDER BY id DESC LIMIT 1`,
                typeCast: (field, next) => {
                    if (field.type == 'BLOB') {
                        return field.string();
                    }
                    return next();
                }
            }, (err, result) => {
                if (!err && result[0] != undefined) {
                    if (result[0].type == "photo") {
                        result[0].message = '📷 Image';
                    } else if (result[0].type == "video") {
                        result[0].message = '📷 Video';
                    } else {
                        result[0].message = result[0].message.toString('utf8');
                    }
                    resolve(result[0]);
                } else {
                    reject();
                }
            })
        })
    },
    async get_chat_count(chat_id, user_id) {
        return new Promise((resolve, reject) => {
            read.query(`SELECT COUNT(id) AS unread_count FROM tbl_chat_reply WHERE chat_id = ${chat_id} AND user_id = ${user_id} is_read = '0' LIMIT 1`, (err, result) => {
                if (!err && result[0] != undefined) {
                    resolve(result[0].unread_count);
                } else {
                    resolve(0);
                }
            })
        })
    },

    async check_room_already_exists(params) {
        return new Promise((resolve, reject) => {
            console.log("user id", params.user_id);
            console.log("provider_id", params.login_user_id);

            read.query(`SELECT room.id AS chat_id,u.role,u.id AS user_id,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,room.update_datetime FROM (tbl_chat_room AS room,tbl_user AS u) WHERE 
            (CASE
                WHEN room.user_id1 = ${params.login_user_id} THEN room.user_id2 = u.id
                WHEN room.user_id2 = ${params.login_user_id} THEN room.user_id1 = u.id
            END) AND 
            ((room.user_id1 = ${params.user_id} AND room.user_id2 = ${params.login_user_id}) OR 
            (room.user_id1 = ${params.login_user_id} AND room.user_id2 = ${params.user_id})) LIMIT 1`, (err, result) => {
                if (!err && result[0] != undefined) {
                    if (result[0].role == "provider") {
                        $temp = params.login_user_id;
                        params.login_user_id = params.user_id;
                        params.user_id = $temp;
                    }
                    read.query(`SELECT id FROM tbl_booking WHERE user_id = ${params.user_id} AND provider_id = ${params.login_user_id} AND status IN ('accepted','running') LIMIT 1`, (tErr, tResult) => {
                        console.log("tresulr bokking id", tResult);
                        result[0].is_timer = (!tErr && tResult[0] != undefined) ? false : true;
                        resolve(result[0]);
                    })
                } else {
                    let room = {
                        user_id1: params.login_user_id,
                        user_id2: params.user_id,
                        insert_datetime: moment().format('X'),
                        update_datetime: moment().format('X')
                    }
                    write.query(`INSERT INTO tbl_chat_room SET ?`, room, (iErr, iResult) => {
                        if (!iErr) {
                            console.log("user id", params.user_id);
                            console.log("provider_id", params.login_user_id);
                            read.query(`SELECT room.id AS chat_id,u.role,u.id AS user_id,u.first_name,u.last_name,room.update_datetime FROM tbl_chat_room AS room JOIN tbl_user AS u ON u.id = room.user_id2 WHERE room.id = ${iResult.insertId} LIMIT 1`, (sErr, sResult) => {
                                if (sResult[0].role == "provider") {
                                    $temp = params.login_user_id;
                                    params.login_user_id = params.user_id;
                                    params.user_id = $temp;
                                }
                                read.query(`SELECT id FROM tbl_booking WHERE user_id = ${params.user_id} AND provider_id = ${params.login_user_id} AND status IN ('accepted','running') LIMIT 1`, (tErr, tResult) => {
                                    console.log(tResult);
                                    sResult[0].is_timer = (!tErr && tResult[0] != undefined) ? false : true;
                                    resolve(sResult[0]);
                                })
                            })
                        } else {
                            reject();
                        }
                    })
                }
            })
        })
    },

    async personal_chat_list(params, room) {
        return new Promise((resolve, reject) => {
            let where = ``;
            if (params.page_token != '0') {
                where = `AND reply.id < ${params.page_token}`;
            }
            read.query({
                sql: `SELECT reply.id AS chat_reply_id,reply.chat_id,u.id AS user_id,u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image,reply.message,reply.type,reply.insert_datetime,reply.is_read FROM tbl_chat_reply AS reply JOIN tbl_user AS u ON reply.user_id = u.id WHERE reply.chat_id = ${room.chat_id} ${where} ORDER BY reply.id DESC LIMIT ${CHAT_PER_PAGE}`,
                typeCast: (field, next) => {
                    if (field.type == 'BLOB') {
                        return field.string();
                    }
                    return next();
                }
            }, (err, result) => {
                if (!err) {
                    if (result[0] != undefined) {
                        asyncLoop(result, (item, next) => {
                            if (["video", "photo"].indexOf(item.type) !== -1) {
                                item.message = `${S3_URL+CHAT_IMAGE+item.message}`;
                            } else {
                                item.message = item.message.toString('utf8');
                            }
                            next();
                        }, () => {
                            room.page_token = result[result.length - 1].chat_reply_id;
                            resolve({ code: '1', data: Object.assign({}, { detail: room }, { list: result }) });
                        })
                    } else {
                        room.page_token = 0;
                        resolve({ code: '2', data: Object.assign({}, { detail: room }, { list: [] }) });
                    }
                } else {
                    reject();
                }
            })
        })
    },

    async send_message(params) {
        return new Promise((resolve, reject) => {
            let message = {
                user_id: params.user_id,
                chat_id: params.chat_id,
                message: params.message,
                type: params.type,
                insert_datetime: moment().format('X')
            }
            write.query(`INSERT INTO tbl_chat_reply SET ?`, message, (err, result) => {
                if (!err) {
                    write.query(`UPDATE tbl_chat_room SET update_datetime = '${moment().format('X')}' WHERE id = ${params.chat_id}`);
                    read.query(`SELECT user_id1,user_id2 FROM tbl_chat_room WHERE id = ${params.chat_id} LIMIT 1`, (cErr, cResult) => {
                        let send_push_id = 0;
                        if (cResult[0].user_id1 == params.user_id) {
                            send_push_id = cResult[0].user_id2;
                        } else {
                            send_push_id = cResult[0].user_id1;
                        }
                        read.query(`SELECT u.first_name,u.last_name,CONCAT('${S3_URL+USER_IMAGE}',u.profile_image) AS profile_image FROM tbl_chat_reply AS reply JOIN tbl_user AS u ON u.id = reply.user_id WHERE reply.id = ${result.insertId}`, (lErr, lResult) => {
                            let body = message.message
                            console.log("message type", message.type);
                            if (message.type == "photo") {
                                body = `📸 Image`;
                            } else if (message.type == "video") {
                                body = `🎥 video`;
                            }
                            let push_data = {
                                title: `${lResult[0].first_name} ${lResult[0].last_name}`,
                                body: `${body}`,
                                custom: {
                                    tag: `new_message`,
                                    body: body,
                                    user_id: params.user_id,
                                    profile_image: lResult[0].profile_image,
                                    chat_id: params.chat_id
                                }
                            }

                            prepare_notification(send_push_id, push_data);
                            lResult[0].chat_reply_id = result.insertId;
                            lResult[0].chat_id = params.chat_id;
                            lResult[0].user_id = params.user_id;
                            lResult[0].message = message.message;
                            lResult[0].type = message.type;
                            lResult[0].insert_datetime = message.insert_datetime;
                            lResult[0].send_push_id = send_push_id;
                            lResult[0].is_read = 0;
                            if (["video", "photo"].indexOf(lResult[0].type) !== -1) {
                                lResult[0].message = `${S3_URL+CHAT_IMAGE+lResult[0].message}`;
                            }
                            resolve(lResult[0]);
                        })
                    })
                } else {
                    reject();
                }
            })
        })
    },

    chat_message_read(chat_id, user_id) {
        write.query(`UPDATE tbl_chat_reply SET is_read = '1' WHERE chat_id = ${chat_id} AND user_id != ${user_id}`);
    }
}

module.exports = model;