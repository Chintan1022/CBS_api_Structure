const { read, write } = require('../../../config/database');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const lang = require('../../../config/language');
const common = require('../../../config/common');
const asyncLoop = require('node-async-loop');

var auth = {
    //////////////////////////////////////////////////////////////////////////////////////////
    /////                            API USER LIST                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    api_user_list: function (callback) {
        read.query("SELECT ud.token, ud.device_token,ud.voip_token, ud.device_type, u.first_name, u.last_name, u.country_code, u.mobile_number FROM tbl_user as u JOIN tbl_user_device as ud ON ud.user_id = u.id ORDER BY u.id DESC", function (err, result) {
            if (!err && (result[0] != undefined)) {
                callback(result)
            } else {
                callback(null)
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                        GET APP UPDATE INFORMATION                              /////
    //////////////////////////////////////////////////////////////////////////////////////////
    async get_app_update_infomation() {
        return new Promise((resolve, reject) => {
            read.query(`SELECT attribute_name, attribute_value FROM tbl_setting_details WHERE attribute_name IN ('provider_app_version','provider_app_message','provider_app_update_force')`, (err, result) => {
                let app_version = [];
                asyncLoop(result, (item, next) => {
                    app_version[item.attribute_name.toString()] = item.attribute_value
                    next();
                }, () => {
                    console.log(app_version);
                    resolve(app_version);
                })
            });
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Signup                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    signup: function (params, referal_code, guest_id, callback) {
        write.query(`INSERT INTO tbl_user SET ?`, params, (err, result) => {
            if (!err && result != undefined) {
                if (referal_code) {
                    read.query(`SELECT id FROM tbl_user WHERE referal_code = '${referal_code}' LIMIT 1`, (uErr, uResult) => {
                        if (!uErr && uResult[0] != undefined) {
                            con.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'referral_discount' LIMIT 1`, (dErr, dResult) => {
                                con.query(`SELECT attribute_value FROM tbl_setting_details WHERE attribute_name = 'referral_days' LIMIT 1`, (daErr, daResult) => {
                                    let insertData = [
                                        ['refer_code', uResult[0].id, common.stringGen(8), moment().format("YYYY-MM-DD"), moment().format("YYYY-MM-DD").add(daResult[0].attribute_value, 'days'), dResult[0].attribute_value, 'this promocode earn for friend refer', moment().format("X")],
                                        ['refer_code', result.insertId, common.stringGen(8), moment().format("YYYY-MM-DD"), moment().format("YYYY-MM-DD").add(daResult[0].attribute_value, 'days'), dResult[0].attribute_value, 'use first service', moment().format("X")]
                                    ];
                                    write.query(`INSERT INTO tbl_offer(added_by,user_id,title,start_date,end_date,discount,description,insert_datetime) VALUES ?`, [insertData], (cErr, cResult) => {
                                        if (guest_id) {
                                            auth.getGuestToNormal(guest_id, result.insertId, function () {
                                                callback(result);
                                            })
                                        } else {
                                            callback(result);
                                        }
                                    });
                                });
                            });
                        } else {
                            if (guest_id) {
                                auth.getGuestToNormal(guest_id, result.insertId, function () {
                                    callback(result);
                                })
                            } else {
                                callback(result);
                            }
                        }
                    });
                } else {
                    if (guest_id) {
                        auth.getGuestToNormal(guest_id, result.insertId, function () {
                            callback(result);
                        })
                    } else {
                        callback(result);
                    }
                }
            }
            else {
                callback(null);
            }
        });
    },

    getGuestToNormal: function (guestId, userId, callback) {
        var sql = `SELECT * FROM tbl_guest_cart WHERE guest_id = '${guestId}' AND is_active = '1'`;
        read.query({
            sql: sql
            , typeCast: (field, next) => {
                if (field.type == "BLOB") {
                    return field.string();
                }
                return next();
            }
        }, function (err, Gresult) {
            if (!err && Gresult[0] != undefined) {
                asyncLoop(Gresult, (item, next) => {
                    let insertData = {
                        user_id: userId,
                        provider_id: item.provider_id,
                        date: item.date,
                        time: item.time,
                        type: item.type,
                        place_to_supply: item.place_to_supply,
                        place_to_delivery: item.place_to_delivery,
                        is_local: item.is_local,
                        service_ids: item.service_ids,
                        address: item.address,
                        description: item.description,
                        insert_datetime: moment().format("X"),
                        update_datetime: moment().format("X")
                    };
                    write.query(`INSERT INTO tbl_cart SET ?`, insertData, function (err, CGresult) {
                        if (!err) {
                            write.query(`DELETE FROM tbl_guest_cart WHERE guest_id = '${guestId}'`, function (err, result) {
                                console.log(this.query);
                            })
                            next();
                        } else {
                            next();
                        }
                    })
                }, () => {
                    callback();
                })
            } else {
                callback();
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                             Update Verify                                      /////
    //////////////////////////////////////////////////////////////////////////////////////////
    checkVerify: function (params, callback) {
        read.query(`SELECT id FROM tbl_verification WHERE mobile_number = '${params.mobile_number}'`, function (err, result) {
            var data = {
                country_code: params.country_code,
                mobile_number: params.mobile_number,
                otp: params.otp,
                is_active: '1',
                insert_datetime: moment().format("X")
            }
            if (!err & result[0] != undefined) {
                write.query(`UPDATE tbl_verification SET ? WHERE id = '${result[0].id}'`, data, function (uErr, uResult) {
                    if (!uErr) {
                        params.insert_datetime = data.insert_datetime
                        auth.update_forgot_password_details(params);
                        callback(true);
                    } else {
                        callback(false);
                    }
                });
            } else {
                write.query(`INSERT INTO tbl_verification SET ?`, data, function (iErr, iResult) {
                    if (!iErr) {
                        params.insert_datetime = data.insert_datetime
                        auth.update_forgot_password_details(params);
                        callback(true);
                    } else {
                        callback(false);
                    }
                });
            }
        });
    },
    update_forgot_password_details: function (params) {
        if (params.type == "forgot") {
            let updateData = {
                forgot_with: 'mobile_number',
                forgot_otp: params.otp,
                forgot_datetime: params.insert_datetime
            }
            common.update_data('tbl_user', params.user_id, updateData)
        }
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Verify OTP                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    verify_otp: function (params, callback) {
        var where = ` AND mobile_number = '${params.mobile_number}' AND country_code = '${params.country_code}'`;
        read.query(`SELECT * FROM tbl_verification WHERE otp = '${params.otp}' AND is_active = '1' ${where}`, function (err, result) {
            if (!err && result[0] != undefined) {
                write.query(`UPDATE tbl_verification SET is_active = '2' WHERE id = '${result[0].id}'`, function (err, update) {
                    // auth.user_details(params, function(resCode, resMsg, resUser){
                    // delete resUser.password;
                    // delete resUser.login_type;
                    callback("1", lang[params.language]["text_verify_otp_success"], null);
                    // });
                });
            } else {
                callback("0", lang[params.language]["text_invalid_otp"], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                  Signin                                        /////
    //////////////////////////////////////////////////////////////////////////////////////////
    signin: function (params, callback) {
        var star = `u.id, CONCAT('${GLOBALS.S3_URL + GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, u.country_code, u.mobile_number, u.email, u.gender, u.password, u.referal_code, u.is_active`;
        const cryptoLib = require('cryptlib');
        const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
        // AND u.password = '${cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV)}'
        var sql = `SELECT ${star} FROM tbl_user AS u WHERE (u.mobile_number = '${params.mobile_number}' AND u.country_code = '${params.country_code}') AND u.role = 'customer' AND u.is_active != '0'`;
        read.query({
            sql: sql
            , typeCast: (field, next) => {
                if (field.type == "BLOB") {
                    return field.string();
                }
                return next();
            }
        }, function (err, result) {
            if (!err) {
                if (result[0] != undefined) {
                    if (result[0].password == cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV)) {
                        if (result[0].is_active == "2") {
                            callback("3", lang[params.language]["text_user_login_inactive"], null);
                        } else {
                            if (params.guest_id) {
                                auth.getGuestToNormal(params.guest_id, result[0].id, function () {
                                    callback("1", lang[params.language]["signin_success"], result[0]);
                                })
                            } else {
                                callback("1", lang[params.language]["signin_success"], result[0]);
                            }

                        }
                    } else {
                        callback("0", lang[params.language]["text_user_login_fail"], result[0]);
                    }
                } else {
                    callback("16", lang[params.language]["text_user_login_fail"], result[0]);
                }
            }
            else {
                callback("0", lang[params.language]["text_sql_err"], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                               Edit Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    edit_check_unique: function (id, params, callback) {
        auth.edit_unique_fields('mobile_number', id, params.mobile_number, function (mobile_number) {
            if (mobile_number) {
                auth.edit_unique_fields('email', id, params.email, function (email) {
                    if (email) {
                        callback(true);
                    } else {
                        callback(false, params.email);
                    }
                });
            } else {
                callback(false, params.mobile_number);
            }
        });
    },
    edit_unique_fields: function (field, id, params, callback) {
        if (params != '') {
            read.query(`SELECT id FROM tbl_user WHERE ${field} = "${params}" AND role = 'customer' AND is_active != "0"`, function (err, result) {
                if (result.length == 1 && result[0].id == id) {
                    callback(true);
                } else if (result.length == 0) {
                    callback(true);
                } else {
                    callback(false);
                }
            });
        } else {
            callback(true);
        }
    },
    edit_profile: function (user_id, params, language, callback) {
        write.query(`UPDATE tbl_user SET ? WHERE id = '${user_id}'`, params, function (err, result) {
            if (!err) {
                auth.user_details({ "user_id": user_id, "language": language, "user_type": "customer" }, function (resCode, resMsg, resData) {
                    delete resData.password;
                    // delete resData.login_type;
                    callback('1', lang[language]['text_user_edit_profile_success'], resData);
                });
            } else {
                callback('0', lang[language]['text_user_edit_profile_fail'], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                Get Profile                                     /////
    //////////////////////////////////////////////////////////////////////////////////////////
    user_details: function (params, callback) {
        if (params.user_id != undefined && params.user_id != "") {
            var where = `AND u.id = '${params.user_id}'`;
        } else {
            if (params.email != undefined && params.email != "") {
                var where = `AND email = '${params.email}'`;
            } else {
                var where = `AND (u.mobile_number = '${params.mobile_number}' AND u.country_code = '${params.country_code}')`;
            }
        }
        let sql = `SELECT u.id, CONCAT('${GLOBALS.S3_URL + GLOBALS.USER_IMAGE}',u.profile_image) AS profile_image, u.first_name, u.last_name, u.country_code, u.mobile_number, u.email, u.gender, u.password, u.referal_code FROM tbl_user AS u WHERE u.is_active = '1' AND u.role = '${params.user_type}' ${where}`;
        read.query({
            sql: sql,
            typeCast: (field, next) => {
                if (field.type == "BLOB") {
                    return field.string();
                }
                return next();
            }
        }, function (err, result) {
            if (!err && result[0] != undefined) {
                callback("1", lang[params.language]['get_profile_data'], result[0]);
            } else {
                callback("2", lang[params.language]['get_no_profile_data'], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                          Get Profile With Token                                /////
    //////////////////////////////////////////////////////////////////////////////////////////
    user_details_with_token: function (params, callback) {
        const cryptoLib = require('cryptlib');
        const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
        read.query(`SELECT user_id FROM tbl_user_device WHERE token = '${cryptoLib.decrypt(params.token, shaKey, GLOBALS.ENC_IV)}'`, function (err, result, fields) {
            if (!err && result[0] != undefined) {
                callback("1", lang[params.language]['get_profile_data'], result[0]);
            } else {
                callback("2", lang[params.language]['get_no_profile_data'], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Reset Password                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    get_detail: function (params, callback) {
        read.query(`SELECT id,mobile_number FROM tbl_user WHERE id = ${params.id} LIMIT 1`, (uErr, uResult) => {
            callback(uResult[0]);
        })
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                              Reset Password                                    /////
    //////////////////////////////////////////////////////////////////////////////////////////
    reset_password: function (params, callback) {
        const cryptoLib = require('cryptlib');
        const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
        let password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV);
        var where = `mobile_number = '${params.mobile_number}' AND country_code = '${params.country_code}' AND role = '${params.user_type}'`;
        write.query(`UPDATE tbl_user SET password = '${password}' WHERE ${where}`, function (err, result) {
            if (!err) {
                read.query(`SELECT id FROM tbl_user WHERE ${where}`, (uErr, uResult) => {
                    auth.logout(uResult[0].id, () => { })
                    callback('1', lang[params.language]['text_user_change_password_success'], null);
                })
            } else {
                callback('0', lang[params.language]['something_wrong'], null);
            }
        });
    },

    //////////////////////////////////////////////////////////////////////////////////////////
    /////                                   Logout                                       /////
    //////////////////////////////////////////////////////////////////////////////////////////
    logout: function (id, callback) {
        write.query(`UPDATE tbl_user_device SET token = '', device_token = '' WHERE user_id = '${id}'`, function (err) {
            callback('1');
        });
    }
}
module.exports = auth;