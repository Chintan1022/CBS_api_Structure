const express = require('express');
const app = express();
const common = require('../config/common');

// =========== v1 ===========
// customer
var authentication_v1 = require('./v1/authentication/route');
var home_v1 = require('./v1/home/route');
// provider
var provider_authentication_v1 = require('./v1/provider_authentication/route');
var provider_home_v1 = require('./v1/provider_home/route');

// =========== v2 ===========
// customer
var authentication_v2 = require('./v2/authentication/route');
var home_v2 = require('./v2/home/route');
// provider
var provider_authentication_v2 = require('./v2/provider_authentication/route');
var provider_home_v2 = require('./v2/provider_home/route');
// earning
var earning_v2 = require('./v2/earning/route');
// chat
var chat_v2 = require('./v2/chat/route');
// agora
var agora_v2 = require('./v2/agora/route');


// =========== v3 ===========
// customer
var authentication_v3 = require('./v3/authentication/route');
var home_v3 = require('./v3/home/route');
// provider
var provider_authentication_v3 = require('./v3/provider_authentication/route');
var provider_home_v3 = require('./v3/provider_home/route');
// earning
var earning_v3 = require('./v3/earning/route');
// chat
var chat_v3 = require('./v3/chat/route');
// agora
var agora_v3 = require('./v3/agora/route');


// =========== v5 ===========
// customer
var authentication_v5 = require('./v5/authentication/route');
var home_v5 = require('./v5/home/route');
// provider
var provider_authentication_v5 = require('./v5/provider_authentication/route');
var provider_home_v5 = require('./v5/provider_home/route');
// earning
var earning_v5 = require('./v5/earning/route');
// chat
var chat_v5 = require('./v5/chat/route');
// agora
var agora_v5 = require('./v5/agora/route');



app.use('/v1/authentication', authentication_v1);
app.use('/v1/home', home_v1);

app.use('/v1/pauthentication', provider_authentication_v1);
app.use('/v1/phome', provider_home_v1);

app.use('/v2/authentication', authentication_v2);
app.use('/v2/home', home_v2);

app.use('/v2/pauthentication', provider_authentication_v2);
app.use('/v2/phome', provider_home_v2);

app.use('/v2/earning', earning_v2);
app.use('/v2/chat', chat_v2);
app.use('/v2/agora', agora_v2);


//v3 
app.use('/v3/authentication', authentication_v3);
app.use('/v3/home', home_v3);

app.use('/v3/pauthentication', provider_authentication_v3);
app.use('/v3/phome', provider_home_v3);

app.use('/v3/earning', earning_v3);
app.use('/v3/chat', chat_v3);
app.use('/v3/agora', agora_v3);

//v5 
app.use('/v5/authentication', authentication_v5);
app.use('/v5/home', home_v5);

app.use('/v5/pauthentication', provider_authentication_v5);
app.use('/v5/phome', provider_home_v5);

app.use('/v5/earning', earning_v5);
app.use('/v5/chat', chat_v5);
app.use('/v5/agora', agora_v5);


app.get('/quickbook_auth_callback', function(req, res) {
    console.log("============auth call==============");
    console.log(req.url)
    console.log("============auth call=============");
    res.status(200);
    res.end();
});

app.post('/send_notification', function(req, res) {
    common.prepare_admin_notification(req.body, function(resCode) {
        let data = JSON.parse(req.body)
        common.update_data('tbl_admin_notification', data.insert_id, { status: 'sent' })
    });
    res.status(200);
    res.json({ code: "1", message: "success" });
});

app.post('/refund_from_admin', function(req, res) {
    let data = JSON.parse(req.body);
    common.refund_from_admin(data.id, data.amount).then((response) => {
        res.status(200);
        res.json({ code: "1", message: "successfully refund" });
    }).catch((error) => {
        res.status(200);
        res.json({ code: "0", message: "something went wrong" });
    });
});

app.use(function(req, res, next) {
    res.status(404);
    res.send('This Url Is Not Valid');
});

module.exports = app