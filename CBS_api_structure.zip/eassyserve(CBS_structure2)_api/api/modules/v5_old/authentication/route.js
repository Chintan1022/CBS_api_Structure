const express = require('express');
var authentication_model = require('./authentication_model');
var common = require('../../../config/common');
const GLOBALS = require('../../../config/constants');
const moment = require('moment');
const lang = require("../../../config/language");
const quickbook = require("../../../config/quickbook");
const { contact_us } = require('../../../config/template');

var router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Check Version                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/check_version', (req, res) => {
    // quickbook.generate_token().then((resUrl)=>{
    //     res.send(resUrl)
    // }).catch((error)=>{
    //     res.send("FAILED")
    // })
    // res.body = JSON.parse(req.body)
    // quickbook.create_token(res.body.url).then((resUrl)=>{
    //     common.sendResponse(res,"1",lang[req.language]["something_wrong"],resUrl);
    // }).catch((error)=>{
    //     common.sendResponse(res,"0",lang[req.language]["something_wrong"]);
    // })
    // quickbook.create_invoice().then((resInvoiceId)=>{
    //     res.send(`SUCCESS ${resInvoiceId}`)
    // }).catch((error)=>{
    //     res.send("FAIL")
    // })
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                         Quick Book TaxCode List                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/taxcode_list', (req, res) => {
    quickbook.taxcode().then((response) => {
        common.sendResponse(res, "1", lang[req.language]['text_details_are'], response)
    }).catch((error) => {
        common.sendResponse(res, "2", lang[req.language]['no_data'], null);
    })
});


//////////////////////////////////////////////////////////////////////////////////////////
/////                         Quick Book get GST rate                                /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/get_gst_rate', (req, res) => {
    console.log(req);
    common.decryption(req.body, function(params) {
        quickbook.get_taxcode_gst(params.category_id).then((response) => {
            common.sendResponse(res, "1", lang[req.language]['text_details_are'], response)
        }).catch((error) => {
            common.sendResponse(res, "2", lang[req.language]['no_data'], null);
        })
    });
});



//////////////////////////////////////////////////////////////////////////////////////////
/////                                 Check Unique                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/check_unique', function(req, res) {
    common.decryption(req.body, function(params) {
        console.log("==========Check_unique==========", params)
        var rules = {
            "mobile_number": "required",
            "user_type": "required|in:customer,provider",
            "is_signup": "required"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            if (params.is_signup == "true" || params.is_signup == true) {
                common.check_unique(params, function(response, val, field) {
                    if (response) {
                        if (field == 'mobile_number') {
                            common.sendResponse(res, "17", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                        }
                    } else {
                        common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
                    }
                });
            } else {
                if (req.headers['token']) {
                    authentication_model.user_details_with_token({ 'token': req.headers['token'], language: req.language }, function(resCode, resMsg, resData) {
                        if (resCode == "1") {
                            authentication_model.edit_check_unique(resData.user_id, params, function(response, val) {
                                if (response) {
                                    common.sendResponse(res, "1", lang[req.language]['unique_success'], params);
                                } else {
                                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                                }
                            });
                        } else {
                            common.sendResponse(res, resCode, resMsg, resData);
                        }
                    });
                } else {
                    common.sendResponse(res, "-1", lang[req.language]['text_rest_tokeninvalid'], null, '401');
                }
            }
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Send OTP                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/send_otp", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            country_code: 'required',
            mobile_number: 'required',
            user_type: "required|in:customer,provider",
            // type: 'required:in:signup,forgot'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
                // authentication_model.user_details(params, (resCode, resMsg, resData) => {
                // if (resCode == "1") {
                // common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', params.mobile_number), null);
                // } else {
                //send otp
            params.otp = Math.floor(1000 + Math.random() * 9000);
            common.send_sms(params.mobile_number, params.otp, `send_otp`, function(resSMS) {
                if (resSMS.code) {
                    authentication_model.checkVerify(params, function(response) {
                        if (response) {
                            common.sendResponse(res, "1", lang[req.language]['signup_otp_send'].replace('{field}', 'mobile number'), { session_id: resSMS.session_id });
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['something_wrong'], null);
                        }
                    });
                } else {
                    common.sendResponse(res, "0", lang[req.language]['otp_not_send'], null);
                }
            });
            // }
            // })
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Verify OTP                                      /////
//////////////////////////////////////////////////////////////////////////////////////////

router.post("/verify_otp", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "otp": "required",
            "mobile_number": "required",
            "country_code": "required",
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.user_type = 'customer';
            params.language = req.language
            authentication_model.verify_otp(params, function(resCode, resMsg, resData) {
                if (resCode == "1") {
                    common.check_unique(params, function(response, val) {
                        let result = '';
                        if (response) {
                            // Login Code 1
                            result = 'true';
                            common.sendResponse(res, "1", lang[req.language]['unique_unsuccess'].replace('{val}', val), result);
                        } else {
                            // Signup Code 2
                            result = 'false';
                            common.sendResponse(res, "1", lang[req.language]['text_signup_unsuccess'], result);
                        }
                    })
                } else {
                    common.sendResponse(res, resCode, resMsg, resData);
                }
            });
        }
    })
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signup                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/signup', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "first_name": "required",
            "last_name": "required",
            "email": "required|email",
            "country_code": "required",
            "mobile_number": "required",
            "gender": "required|in:male,female",
            "password": "",
            "device_token": "required",
            "device_type": "required",
            "device_model": "required",
            "uuid": "required",
            "ip": "required",
            "voip_token": "",
            "login_type": "required|in:N,G,F"
        }

        if (params.social_id) {
            rules.social_id = 'required';
        }

        if (common.checkValidation(params, rules, res, req.language)) {
            params.user_type = 'customer';
            common.check_unique(params, function(response, val) {
                if (response) {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                } else {
                    var data = {
                        "first_name": params.first_name,
                        "last_name": params.last_name,
                        "email": params.email,
                        "country_code": params.country_code,
                        "mobile_number": params.mobile_number,
                        "gender": params.gender,
                        "referal_code": common.stringGen(10),
                        "social_id": (params.social_id != '') ? params.social_id : '',
                        "login_type": (params.login_type != '') ? params.login_type : 'N',
                        ...(params.referal_code) && { friend_refer_code: params.referal_code },
                        "insert_datetime": moment().format("X")
                    }
                    const cryptoLib = require('cryptlib');
                    const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
                    if (params.password) {
                        data.password = cryptoLib.encrypt(params.password, shaKey, GLOBALS.ENC_IV);
                    }
                    authentication_model.signup(data, params.referal_code, params.guest_id, function(result) {
                        if (result != null) {
                            common.checkDeviceInfo(result.insertId, params, function(response) {
                                if (response) {
                                    authentication_model.user_details({ "user_id": result.insertId, 'language': req.language, "user_type": "customer" }, function(resCode, resMsg, resData) {
                                        delete resData.password;
                                        // delete resData.login_type;
                                        resData['token'] = response.token;
                                        quickbook.create_customer({ name: `ES-${params.first_name} ${params.last_name}-${result.insertId}`, mobile_number: params.mobile_number, user_id: result.insertId, email: params.email });
                                        common.sendResponse(res, "1", lang[req.language]['text_user_signup_success'], resData);
                                    });
                                } else {
                                    common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                                }
                            });
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['signup_unsuccess'], null);
                        }
                    });
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                  Signin                                        /////
//////////////////////////////////////////////////////////////////////////////////////////

router.post('/signin', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "country_code": "required",
            "mobile_number": "required",
            "password": "",
            "device_token": "required",
            "device_type": "required",
            "device_model": "required",
            "uuid": "required",
            "ip": "required",
            "voip_token": "",
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            authentication_model.signin(params, function(resCode, resMsg, resData) {
                if (resData != null) {
                    common.checkDeviceInfo(resData.id, params, function(response) {
                        if (response != null) {
                            delete resData.password;
                            resData['token'] = response.token;
                            common.sendResponse(res, resCode, resMsg, resData);
                        } else {
                            common.sendResponse(res, "0", lang[req.language]['device_info_not_update'], null);
                        }
                    });
                } else {
                    common.sendResponse(res, resCode, resMsg, resData);
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Edit Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/edit_profile', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "first_name": "required",
            "last_name": "required",
            "email": "required",
            "country_code": "required",
            "mobile_number": "required",
            "gender": "required|in:male,female"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            authentication_model.edit_check_unique(req.login_user_id, params, function(response, val) {
                if (response) {
                    var data = {
                        "first_name": params.first_name,
                        "last_name": params.last_name,
                        "email": params.email,
                        "country_code": params.country_code,
                        "mobile_number": params.mobile_number,
                        "gender": params.gender,
                        ...(params.bio) && { bio: params.bio },
                        "update_datetime": moment().format("X")
                    }
                    if (params.profile_image) {
                        common.get_old_image_name_and_delete(`tbl_user`, `profile_image`, `id = ${req.login_user_id}`, GLOBALS.USER_IMAGE, () => {});
                        data.profile_image = params.profile_image;
                    }
                    authentication_model.edit_profile(req.login_user_id, data, req.language, function(resCode, resMsg, resData) {
                        common.sendResponse(res, resCode, resMsg, resData);
                    });
                } else {
                    common.sendResponse(res, "0", lang[req.language]['unique_unsuccess'].replace('{val}', val), null);
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Get Profile                                     /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/get_profile", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "user_id": "required" }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            params.user_type = 'customer'
            authentication_model.user_details(params, function(resCode, resMsg, resData) {
                if (resCode == "1") {
                    delete resData.password;
                    // delete resData.login_type;
                }
                common.sendResponse(res, resCode, resMsg, resData);
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Change Language                                   /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/change_language", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "language": "required|in:en,hi,enhi" }
        if (common.checkValidation(params, rules, res, req.language)) {
            let updateData = {
                current_language: params.language
            }
            common.update_data('tbl_user', req.login_user_id, updateData);
            common.sendResponse(res, "1", lang[req.language], null);
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                Contact Us                                      /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/contact_us", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = { "email": "required", "subject": "required", "description": "required" }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.id = req.login_user_id;
            authentication_model.get_detail(params, (resData) => {
                params.mobile_number = resData.mobile_number
                params.insert_datetime = moment().format("X");
                common.add_data('tbl_contact_us', params, function() {
                    contact_us(params, (html) => {
                        common.send_email(params.email + " <" + GLOBALS.EMAIL_ID + ">", params.subject, `contactus@eassyserve.in`, html, (resEmail) => {});
                        common.sendResponse(res, "1", lang[req.language]["text_user_contactus_success"], null);
                    })
                });
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                              Reset Password                                    /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/reset_password", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            country_code: 'required',
            mobile_number: 'required',
            password: 'required',
            user_type: 'required|in:customer,provider'
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            authentication_model.reset_password(params, function(resCode, resMsg, resData) {
                common.sendResponse(res, resCode, resMsg, resData);
            })
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                               Change Password                                  /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post('/change_password', function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "old_password": "required",
            "new_password": "required",
            "confirm_password": "required",
            "user_type": "required|in:customer,provider"
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            const cryptoLib = require('cryptlib');
            const shaKey = cryptoLib.getHashSha256(GLOBALS.ENC_KEY, 32);
            authentication_model.user_details({ 'user_id': req.login_user_id, 'language': req.language, 'user_type': params.user_type }, function(resCode, resMsg, resData) {
                if (cryptoLib.encrypt(params.old_password, shaKey, GLOBALS.ENC_IV) == resData.password) {
                    if (params.new_password != params.old_password) {
                        if (params.new_password == params.confirm_password) {
                            common.update_data("tbl_user", req.login_user_id, { "password": cryptoLib.encrypt(params.new_password, shaKey, GLOBALS.ENC_IV) });
                            common.sendResponse(res, "1", lang[req.language]["text_user_change_password_success"], null);
                        } else {
                            common.sendResponse(res, "0", lang[req.language]["text_new_confirm_password_not_match"], null);
                        }
                    } else {
                        common.sendResponse(res, "0", lang[req.language]["text_old_new_password_same"], null);
                    }
                } else {
                    common.sendResponse(res, "0", lang[req.language]["text_user_change_password_fail"], null);
                }
            });
        }
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                                   Logout                                       /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/logout", function(req, res) {
    authentication_model.logout(req.login_user_id, function(resCode) {
        common.sendResponse(res, resCode, lang[req.language]['text_user_logout'], null);
    });
});


router.post("/check_token", function(req, res) {
    authentication_model.check_token(req.login_user_id, function(resCode) {
        console.log(resCode);
        return false;
        common.sendResponse(res, resCode, lang[req.language]['text_user_logout'], null);
    });
});

//////////////////////////////////////////////////////////////////////////////////////////
/////      Check mobile & country code exists                                        /////
//////////////////////////////////////////////////////////////////////////////////////////
router.post("/check_mobile_num_exist", function(req, res) {
    common.decryption(req.body, function(params) {
        var rules = {
            "country_code": "required",
            "mobile_number": "required",
        }
        if (common.checkValidation(params, rules, res, req.language)) {
            params.language = req.language
            authentication_model.check_mobile_num_exist(params, function(resCode, resMsg, resData) {
                if (resCode == '1') {
                    common.sendResponse(res, "0", 'Country code & mobile number are already exists.', 'false');
                } else {
                    common.sendResponse(res, "1", lang[req.language]['unique_success'], 'true');
                }
            });
        }
    });
});



module.exports = router;