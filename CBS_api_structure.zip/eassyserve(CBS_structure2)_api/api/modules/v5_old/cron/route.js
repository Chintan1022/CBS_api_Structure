const express = require('express');
const cron_model = require('../cron/cron_model');
const cron = require('cron');
const quickbook = require('../../../config/quickbook');
const moment_timezone = require('moment-timezone');

const router = express.Router(); // get an instance of the express Router

//////////////////////////////////////////////////////////////////////////////////////////
/////                             Cron Set In 1 Minutes                              /////
//////////////////////////////////////////////////////////////////////////////////////////
var one_minute = new cron.CronJob({
    cronTime: '* * * * *',
    onTick: function() {
        console.log('1 MINUTE CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        cron_model.check_booking_accepted_or_not();
        cron_model.booking_request_reminder();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                            Cron Set In 45 Minutes                              /////
//////////////////////////////////////////////////////////////////////////////////////////
var forty_five_minute = new cron.CronJob({
    cronTime: '*/45 * * * *',
    onTick: function() {
        console.log('45 MINUTE CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        quickbook.refresh_token();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Cron Set In 01 Hours                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
var one_hour = new cron.CronJob({
    cronTime: '0 0 */1 * * *',
    onTick: function() {
        console.log('1 HOURS CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        cron_model.region_reminder();
        // cron_model.rate_card_not_set_reminder();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                        Cron Set In Every Day 8 AM                              /////
//////////////////////////////////////////////////////////////////////////////////////////
var every_day_8_AM = new cron.CronJob({
    cronTime: '0 8 * * *',
    onTick: function() {
        console.log('EVERY DAY 8 AM CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        cron_model.register_incomplete_reminder();
        cron_model.availability_not_set_reminder();
        cron_model.rate_card_not_set_reminder();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                        Cron Set In Every Day 12 PM                             /////
//////////////////////////////////////////////////////////////////////////////////////////
var every_day_12_PM = new cron.CronJob({
    cronTime: '0 12 * * *',
    onTick: function() {
        console.log('EVERY DAY 12 PM CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        cron_model.provider_offer_end_remainder();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

//////////////////////////////////////////////////////////////////////////////////////////
/////                           Cron Set In 24 Hours                                 /////
//////////////////////////////////////////////////////////////////////////////////////////
var one_day = new cron.CronJob({
    cronTime: '0 */23 * * *',
    onTick: function() {
        console.log('24 HOURS CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        cron_model.remove_past_cart_added();
        cron_model.provider_offer_live();
        cron_model.today_total_service();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});


//////////////////////////////////////////////////////////////////////////////////////////
/////                        Cron Set In Every Day 2 AM                              /////
//////////////////////////////////////////////////////////////////////////////////////////
var every_day_2_AM = new cron.CronJob({
    cronTime: '0 2 * * *',
    onTick: function() {
        console.log('EVERY DAY 2 AM CRON CALL : '+moment_timezone().tz("asia/kolkata").format("YYYY-MM-DD hh:mm A"));
        cron_model.remove_ci_sess_data();
    },
    start: true,
    timezone: 'Asia/Kolkata'
});

module.exports = router;