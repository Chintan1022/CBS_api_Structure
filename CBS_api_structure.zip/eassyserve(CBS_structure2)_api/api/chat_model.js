var con = require('../../../config/database');
var GLOBALS = require('../../../config/constants');
var common = require('../../../config/common');
var asyncLoop = require('node-async-loop');
var moment = require('moment');

// Language file load
const { t } = require('localizify');

// get an instance of the express Router
var Chat = {

    /*============================================================================================================
            Get Recent Chat Room Listing
    ==============================================================================================================*/

    get_recent_chat_list: function(req, callback) {

        // (req.store_id != undefined && req.store_id != "") ? `AND c.store_id = '${req.store_id}'` : 
        let where = ``;
        let search = (req.search != undefined && req.search != "") ? `LOWER(u.fullname) LIKE LOWER('%${req.search}%') AND` : ``;
        con.query({
            sql: `SELECT c.id chat_id,c.store_id,u.id user_id,u.fullname,CONCAT('${GLOBALS.USER_IMAGE}',profile_image) profile_image,r.message last_chat,r.type,r.cart_type,r.insert_datetime,r.is_active
            FROM (tbl_user u, tbl_chat_room c,tbl_chat_reply r) 
            WHERE ${search} 
            (CASE 
                WHEN c.user_id1 = '${req.login_user_id}' THEN c.user_id2 = u.id 
                WHEN c.user_id2 = '${req.login_user_id}' THEN c.user_id1 = u.id 
            END) AND c.id = r.chat_id 
            ${where}
            AND r.id IN (SELECT MAX(id) FROM tbl_chat_reply r1 WHERE r1.chat_id = c.id AND (c.user_id1 ='${req.login_user_id}' OR c.user_id2 = '${req.login_user_id}') GROUP BY r1.chat_id) 
            AND (c.user_id1 ='${req.login_user_id}' OR c.user_id2 = '${req.login_user_id}') AND c.is_active = '1' AND r.is_active = '1'
            ORDER BY c.update_datetime DESC LIMIT ${parseInt(req.page_token) * parseInt(GLOBALS.CHAT_PER_PAGE)},${parseInt(GLOBALS.CHAT_PER_PAGE)}`,
            typeCast: (field, next) => {
                if (field.type == 'BLOB') {
                    return field.string();
                }
                return next();
            }
        }, function(err, result) {
            if (!err && result[0] != undefined) {
                asyncLoop(result, function(item, next) {
                    Chat.get_store_details(item.store_id).then((resStore) => {
                        Chat.get_unread_count({ "chat_id": item.chat_id, "login_user_id": req.login_user_id }, function(response) {
                            item.store_name = resStore.name;
                            item.store_profile_image = resStore.profile_image;
                            item.unread_count = response.unread_count;
                            let is_active = item.is_active
                            delete item.is_active
                            if (is_active == "0") {
                                item.last_chat = "🚫 This message was deleted";
                                next();
                            } else {
                                if (item.type == "photo") {
                                    item.last_chat = "📷 Image";
                                    next();
                                } else if (item.type == "product") {
                                    try {
                                        item.last_chat = JSON.parse(item.last_chat)
                                    } catch (e) {
                                        item.last_chat = item.last_chat
                                    }
                                    if (item.cart_type == 'T') {
                                        con.query(`SELECT id FROM tbl_treez_cart WHERE id = '${item.last_chat.cart_id}'`, (cErr, cResult) => {
                                            if (!cErr && cResult[0] != undefined) {
                                                item.last_chat = "🏬 Product";
                                                next();
                                            } else {
                                                item.last_chat = "🚫 This message was deleted";
                                                next();
                                            }
                                        });
                                    } else {
                                        con.query(`SELECT id FROM tbl_cart_product WHERE id = '${item.last_chat.cart_id}'`, (cErr, cResult) => {
                                            if (!cErr && cResult[0] != undefined) {
                                                item.last_chat = "🏬 Product";
                                                next();
                                            } else {
                                                item.last_chat = "🚫 This message was deleted";
                                                next();
                                            }
                                        });
                                    }

                                } else {
                                    item.last_chat = item.last_chat.toString('utf8');
                                    next();
                                }
                            }
                        });
                    })
                }, function() {
                    let data = {
                        page_token: parseInt(req.page_token) + 1,
                        result: result
                    }
                    callback("1", t("text_details_are"), data);
                }); //end function
            } else {
                callback("2", t("no_recent_chat"), null);
            }
        });
    },

    get_store_details: function(id) {
        return new Promise((resolve, reject) => {
            con.query(`SELECT name, CONCAT('${GLOBALS.SHOP_IMAGE}',profile_image) AS profile_image,cart_type FROM tbl_dispensary WHERE id = '${id}'`, (err, result) => {
                resolve(result[0])
            })
        })
    },

    /*=============================================================================================================
            Get Chat Room Count
    ===============================================================================================================*/

    get_unread_count: function(req, callback) {
        con.query(`SELECT COUNT(id) AS unread_count FROM tbl_chat_reply WHERE chat_id = '${req.chat_id}' AND user_id != '${req.login_user_id}' AND is_read = '0'`, function(err, result, fields) { //AND is_active = '1'
            if (result[0] != undefined) {
                callback(result[0]);
            } else {
                callback(0);
            }
        });
    },

    check_shop_hours: function(req, callback) {
        con.query(`SELECT id,IF((DATE_FORMAT(CONVERT_TZ(CURRENT_TIME(), 'UTC', 'US/Pacific'),'%H:%i') >= DATE_FORMAT(CONVERT_TZ(open_time, 'UTC', 'US/Pacific'),'%H:%i')) AND (DATE_FORMAT(CONVERT_TZ(close_time, 'UTC', 'US/Pacific'),'%H:%i') >= DATE_FORMAT(CONVERT_TZ(CURRENT_TIME(), 'UTC', 'US/Pacific'),'%H:%i')),'1','0') AS is_open_close FROM tbl_dispensary_hour WHERE dispensary_id = ${req.store_id} AND day = DAYNAME(CONVERT_TZ(NOW(), 'UTC', 'US/Pacific'))`, function(err, result) {
            console.log(this.sql)
            if (!err && result[0] != undefined) {
                if (result[0].is_open_close == "1" || result[0].is_open_close == 1) {
                    callback("1", t("text_details_are"), null);
                } else {
                    callback("3", t("text_shop_non_delivery_hours"), null);
                }
            } else {
                callback("3", t("text_shop_non_delivery_hours"), null);
            }
        })
    },

    /*============================================================================================================
            Create Or Check Chat Room
    ==============================================================================================================*/

    create_or_check_chat_room: function(params, callback) {
        let where = (params.user_id) ? `((user_id2 = '${params.login_user_id}' AND user_id1 = '${params.user_id}') OR (user_id1 = '${params.login_user_id}' AND user_id2 = '${params.user_id}'))` : `(user_id2 = '${params.login_user_id}' OR user_id1 = '${params.login_user_id}')`
        con.query(`SELECT c.*, u.id user_id, u.fullname, CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image, d.name AS store_name, CONCAT('${GLOBALS.SHOP_IMAGE}',d.profile_image) store_image, d.mobile_number AS store_mobile_number,d.cart_type, u.mobile_number, u.login, '0' AS is_create FROM (tbl_chat_room c, tbl_user u) JOIN tbl_dispensary d ON d.id = c.store_id WHERE (CASE WHEN c.user_id1 = '${params.login_user_id}' THEN c.user_id2 = u.id WHEN c.user_id2 = '${params.login_user_id}' THEN c.user_id1 = u.id END) AND c.store_id = '${params.store_id}' AND ${where}`, function(err, result) {

            if (!err) {
                con.query(`SELECT fullname FROM tbl_user WHERE id = '${params.login_user_id}'`, (uErr, uResult) => {
                    con.query({
                        sql: `SELECT greeting1, greeting2, greeting3 FROM tbl_dispensary WHERE id = '${params.store_id}'`,
                        typeCast: (field, next) => {
                            if (field.type == "BLOB") {
                                return field.string()
                            }
                            return next()
                        }
                    }, (sErr, sResult) => {
                        if (result[0] != undefined) {
                            if (params.user_id) {
                                callback("1", t("text_details_are"), result[0]);
                            } else {
                                con.query(`SELECT d.id FROM tbl_dispensary AS d JOIN tbl_user AS u ON u.id = ${result[0].user_id} WHERE d.id = '${params.store_id}' AND FIND_IN_SET('${result[0].user_id}',d.agent_ids) > 0 AND u.login = 'Online'`, function(aErr, aResult) {
                                    if (!aErr && aResult[0] != undefined) {
                                        callback("1", t("text_details_are"), result[0]);
                                    } else {
                                        Chat.store_assign(params, (agentCode, agentMsg, agentData) => {
                                            if (agentCode == "1") {
                                                let data = {
                                                    user_id2: agentData.id,
                                                    update_datetime: moment().format("X")
                                                }
                                                con.query(`UPDATE tbl_chat_room SET ? WHERE id = '${result[0].id}'`, data, (err, createRoom) => {
                                                    if (!err) {
                                                        let chat_history = {
                                                            chat_id: result[0].id,
                                                            user_id: agentData.id,
                                                            insert_datetime: moment().format("X")
                                                        }
                                                        common.add_data(`tbl_chat_history`, chat_history, (historyRes) => {})
                                                        let welcome_template = [
                                                            [result[0].id, agentData.id, `Hello ${uResult[0].fullname}, ${sResult[0].greeting1}`, "text", moment().format("X")],
                                                            [result[0].id, agentData.id, `${sResult[0].greeting2}`, "text", moment().format("X")],
                                                            [result[0].id, agentData.id, `My name is ${agentData.fullname}, ${sResult[0].greeting3}`, "text", moment().format("X")]
                                                        ]
                                                        con.query(`INSERT INTO tbl_chat_reply(chat_id,user_id,message,type,insert_datetime) VALUES ?`, [welcome_template], (wErr, wResult) => {
                                                            //get last insert chat details
                                                            con.query(`SELECT r.*,u.id AS user_id,u.fullname, CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image, d.name AS store_name,d.cart_type ,CONCAT('${GLOBALS.SHOP_IMAGE}',d.profile_image) store_image, d.mobile_number AS store_mobile_number, u.mobile_number, u.login, '1' AS is_create FROM tbl_chat_room r JOIN tbl_user u ON u.id = r.user_id2 JOIN tbl_dispensary d ON d.id = r.store_id WHERE r.id = ${result[0].id}`, (err, resultChatRoom) => {
                                                                callback("1", t('text_details_are'), resultChatRoom[0]);
                                                            });
                                                        });
                                                    } else {
                                                        callback("0", t("text_chat_list_fail"), null);
                                                    }
                                                });
                                            } else {
                                                callback(agentCode, `Sorry ${uResult[0].fullname}, ${agentMsg}`, agentData)
                                            }
                                        });
                                    }
                                })
                            }
                        } else {
                            where = (params.user_id) ? `((user_id2 = '${params.login_user_id}' AND user_id1 = '${params.user_id}') OR (user_id1 = '${params.login_user_id}' AND user_id2 = '${params.user_id}'))` : `user_id2 = '${params.login_user_id}' AND user_id1 = '${params.login_user_id}'`
                            con.query(`SELECT c.*, u.id user_id, u.fullname, CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image, d.name AS store_name, CONCAT('${GLOBALS.SHOP_IMAGE}',d.profile_image) store_image, d.mobile_number AS store_mobile_number,d.cart_type ,u.mobile_number, u.login, '0' AS is_create FROM (tbl_chat_room c, tbl_user u) JOIN tbl_dispensary d ON d.id = c.store_id WHERE c.store_id = '${params.store_id}' AND ${where}`, (cErr, cResult) => {
                                if (!cErr && cResult[0] != undefined) {
                                    Chat.store_assign(params, (agentCode, agentMsg, agentData) => {
                                        if (agentCode == "1") {
                                            let data = {
                                                user_id2: agentData.id,
                                                update_datetime: moment().format("X")
                                            }
                                            con.query(`UPDATE tbl_chat_room SET ? WHERE id = '${cResult[0].id}'`, data, (err, createRoom) => {
                                                if (!err) {
                                                    let welcome_template = [
                                                        [cResult[0].id, agentData.id, `Hello ${uResult[0].fullname}, ${sResult[0].greeting1}`, "text", moment().format("X")],
                                                        [cResult[0].id, agentData.id, `${sResult[0].greeting2}`, "text", moment().format("X")],
                                                        [cResult[0].id, agentData.id, `My name is ${agentData.fullname}, ${sResult[0].greeting3}`, "text", moment().format("X")]
                                                    ]
                                                    con.query(`INSERT INTO tbl_chat_reply(chat_id,user_id,message,type,insert_datetime) VALUES ?`, [welcome_template], (wErr, wResult) => {
                                                        //get last insert chat details
                                                        con.query(`SELECT r.*,u.id AS user_id,u.fullname, CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image, d.name AS store_name,d.cart_type ,CONCAT('${GLOBALS.SHOP_IMAGE}',d.profile_image) store_image, d.mobile_number AS store_mobile_number, u.mobile_number, u.login, '1' AS is_create FROM tbl_chat_room r JOIN tbl_user u ON u.id = r.user_id2 JOIN tbl_dispensary d ON d.id = r.store_id WHERE r.id = ${cResult[0].id}`, (err, resultChatRoom) => {
                                                            callback("1", t('text_details_are'), resultChatRoom[0]);
                                                        });
                                                    });
                                                } else {
                                                    callback("0", t("text_chat_list_fail"), null);
                                                }
                                            });
                                        } else {
                                            callback(agentCode, `Sorry ${uResult[0].fullname}, ${agentMsg}`, agentData)
                                        }
                                    });
                                } else {
                                    Chat.store_assign(params, (agentCode, agentMsg, agentData) => {
                                        if (agentCode == "1") {
                                            let data = {
                                                store_id: params.store_id,
                                                user_id1: params.login_user_id,
                                                user_id2: agentData.id,
                                                insert_datetime: moment().format("X"),
                                                update_datetime: moment().format("X")
                                            }
                                            con.query(`INSERT INTO tbl_chat_room SET ?`, data, (err, createRoom) => {
                                                if (!err) {
                                                    let chat_history = {
                                                        chat_id: createRoom.insertId,
                                                        user_id: agentData.id,
                                                        insert_datetime: moment().format("X")
                                                    }
                                                    common.add_data(`tbl_chat_history`, chat_history, (historyRes) => {})
                                                    let welcome_template = [
                                                        [createRoom.insertId, agentData.id, `Hello ${uResult[0].fullname}, ${sResult[0].greeting1}`, "text", moment().format("X")],
                                                        [createRoom.insertId, agentData.id, `${sResult[0].greeting2}`, "text", moment().format("X")],
                                                        [createRoom.insertId, agentData.id, `My name is ${agentData.fullname}, ${sResult[0].greeting3}`, "text", moment().format("X")]
                                                    ]
                                                    con.query(`INSERT INTO tbl_chat_reply(chat_id,user_id,message,type,insert_datetime) VALUES ?`, [welcome_template], (wErr, wResult) => {
                                                        //get last insert chat details
                                                        con.query(`SELECT r.*,u.id AS user_id,u.fullname, CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image, d.name AS store_name,d.cart_type ,CONCAT('${GLOBALS.SHOP_IMAGE}',d.profile_image) store_image, d.mobile_number AS store_mobile_number, u.mobile_number, u.login, '1' AS is_create FROM tbl_chat_room r JOIN tbl_user u ON u.id = r.user_id2 JOIN tbl_dispensary d ON d.id = r.store_id WHERE r.id = ${createRoom.insertId}`, (err, resultChatRoom) => {
                                                            callback("1", t('text_details_are'), resultChatRoom[0]);
                                                        })
                                                    })
                                                } else {
                                                    callback("0", t("text_chat_list_fail"), null);
                                                }
                                            });
                                        } else {
                                            callback(agentCode, `Sorry ${uResult[0].fullname}, ${agentMsg}`, agentData)
                                        }
                                    });
                                }
                            })
                        }
                    })
                })
            } else {
                callback("0", t("text_chat_list_fail"), null);
            }
        });
    },

    store_assign: function(req, callback) {
        con.query({
            sql: `SELECT agent_ids, agent_not_available FROM tbl_dispensary WHERE id = '${req.store_id}'`,
            typeCast: (field, next) => {
                if (field.type == "BLOB") {
                    return field.string()
                }
                return next()
            }
        }, (aErr, aResult) => {
            if (aResult[0].agent_ids == '') {
                callback('3', aResult[0].agent_not_available, null)
            } else {
                con.query(`SELECT id, fullname, login FROM tbl_user WHERE role = 'agent' AND login = 'Online' AND id IN (${aResult[0].agent_ids}) ORDER BY RAND() LIMIT 1`, (agentErr, agentResult) => {
                    if (!agentErr && agentResult[0] != undefined) {
                        con.query(`SELECT COUNT(id) AS total FROM tbl_chat_room WHERE user_id1 = ${agentResult[0].id} OR user_id2 = ${agentResult[0].id}`, (tErr, tResult) => {
                            if (tResult[0].total < 5) {
                                callback('1', t('text_details_are'), agentResult[0])
                            } else {
                                callback('3', aResult[0].agent_not_available, null)
                            }
                        })
                    } else {
                        callback('3', aResult[0].agent_not_available, null)
                    }
                })
            }
        });
    },

    /*=======================================================================================================
            Update chat message as view
    =========================================================================================================*/

    update_chat_message_read: function(req) {
        con.query(`UPDATE tbl_chat_reply SET is_read = '1' WHERE chat_id = '${req.chat_id}' AND user_id != '${req.login_user_id}'`, function(err, result) {});
    },

    delete_message: function(id) {
        let q = con.query(`DELETE FROM tbl_chat_reply WHERE id = '${id}'`)
        console.log(q.sql)
    },

    delete_message_not_chat: function(params, callback) {
        con.query(`SELECT id AS chat_reply_id,chat_id,user_id,message FROM tbl_chat_reply WHERE type = 'product' AND chat_id = ${params.chat_id} AND user_id = ${params.user_id} ORDER BY id DESC`, (err, result) => {
            if (!err && result[0] != undefined) {
                let chat_reply_id = 0;
                asyncLoop(result, (item, next) => {
                    item.message = JSON.parse(item.message);
                    if (item.message.cart_id == params.cart_id) {
                        Chat.delete_message(item.chat_reply_id);
                        chat_reply_id = item.chat_reply_id;
                        next();
                    } else {
                        next();
                    }
                }, () => {
                    con.query(`SELECT user_id1,user_id2 FROM tbl_chat_room WHERE id = ${params.chat_id} LIMIT 1`, (uErr, uResult) => {
                        callback({ chat_reply_id: chat_reply_id, user_id: (!uErr && uResult[0] != undefined) ? ((uResult[0].user_id1 == params.user_id) ? uResult[0].user_id2 : uResult[0].user_id1) : 0 });
                    })
                })
            } else {
                callback(null);
            }
        })
    },

    /*========================================================================================================
            Get chat list
    ==========================================================================================================*/

    get_chat_list: function(req, chat_room, callback) {

        con.query({
            sql: `SELECT cr.id chat_reply_id,cr.chat_id,u.id user_id,u.fullname,CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image,cr.message,cr.type,cr.insert_datetime,cr.is_read,cr.cart_type,cr.is_active FROM tbl_chat_reply cr JOIN tbl_user u ON cr.user_id = u.id WHERE cr.chat_id = ${req.chat_id} AND cr.is_active = '1' ORDER BY cr.id DESC LIMIT ${parseInt(req.page_token) * parseInt(GLOBALS.CHAT_PER_PAGE)},${parseInt(GLOBALS.CHAT_PER_PAGE)}`,
            typeCast: (field, next) => {
                if (field.type == 'BLOB') {
                    return field.string();
                }
                return next();
            }
        }, function(err, result) {
            console.log("get chat list", result);
            if (!err) {
                if (result[0] != undefined) {
                    let finalResult = []
                    asyncLoop(result, (item, next) => {
                        let is_active = item.is_active
                        delete item.is_active
                        if (is_active == "0") {
                            item.message = "🚫 This message was deleted";
                            next();
                        } else {
                            if (item.type == "photo") {
                                item.message = GLOBALS.CHAT_IMAGE_MESSAGE + item.message;
                                finalResult.push(item)
                                next();
                            } else if (item.type == "product") {
                                try {
                                    item.message = JSON.parse(item.message)
                                } catch (e) {
                                    item.message = item.message
                                }
                                if (item.cart_type == 'T') {
                                    con.query(`SELECT c.id cart_id, c.shop_id, c.product_id, c.quantity, c.name, c.brand_name, c.category AS category_name, c.primary_image as  image,c.price FROM tbl_treez_cart c  WHERE c.id = '${item.message.cart_id}'`, (pErr, pResult) => {
                                        if (!pErr && pResult[0] != undefined) {
                                            item.message = { result: pResult[0], is_show: 1 }
                                            item.product = { result: pResult[0], is_show: 1 }
                                            finalResult.push(item)
                                        } else {
                                            item.message = { result: "🚫 This message was deleted", is_show: 0 };
                                            item.product = { result: "🚫 This message was deleted", is_show: 0 }
                                        }
                                        next();
                                    });

                                } else {
                                    con.query(`SELECT c.id cart_id, c.shop_id, c.product_id, c.attribute_id, c.quantity, p.name, p.brand_name, ca.name AS category_name, CONCAT('${GLOBALS.CATEGORY_IMAGE}',ca.image) AS category_image, CONCAT('${GLOBALS.PRODUCT_IMAGE}',p.image) image, (c.quantity * a.value) price FROM tbl_cart_product c JOIN tbl_product p ON p.id = c.product_id JOIN tbl_category AS ca ON ca.id = p.category_id JOIN tbl_product_attribute a ON a.id = c.attribute_id WHERE c.id = '${item.message.cart_id}'`, (pErr, pResult) => {
                                        if (!pErr && pResult[0] != undefined) {
                                            item.message = { result: pResult[0], is_show: 1 }
                                            item.product = { result: pResult[0], is_show: 1 }
                                            finalResult.push(item)
                                        } else {
                                            item.message = { result: "🚫 This message was deleted", is_show: 0 };
                                            item.product = { result: "🚫 This message was deleted", is_show: 0 }
                                        }
                                        next();
                                    });

                                }

                                // con.query(`SELECT c.id cart_id, c.primary_image as image,c.shop_id, c.product_id,c.brand_name,c.name, c.price,c.quantity,c.category from tbl_treez_cart WHERE c.id = '${item.message.cart_id}' and  c.user_id = '${item.user_id}'`, (pErr, tResult) => {
                                //     if (tResult[0] != undefined) {
                                //         if (!pErr && tResult[0] != undefined) {
                                //             item.message = { result: tResult[0], is_show: 1 }
                                //             item.product = { result: tResult[0], is_show: 1 }
                                //             finalResult.push(item)
                                //         } else {
                                //             item.message = { result: "🚫 This message was deleted", is_show: 0 };
                                //             item.product = { result: "🚫 This message was deleted", is_show: 0 }
                                //         }
                                //         next();
                                //     } else {
                                //         con.query(`SELECT c.id cart_id, c.shop_id, c.product_id, c.attribute_id, c.quantity, p.name, p.brand_name, ca.name AS category_name, CONCAT('${GLOBALS.CATEGORY_IMAGE}',ca.image) AS category_image, CONCAT('${GLOBALS.PRODUCT_IMAGE}',p.image) image, (c.quantity * a.value) price FROM tbl_cart_product c JOIN tbl_product p ON p.id = c.product_id JOIN tbl_category AS ca ON ca.id = p.category_id JOIN tbl_product_attribute a ON a.id = c.attribute_id WHERE c.id = '${item.message.cart_id}'`, (pErr, pResult) => {
                                //             if (!pErr && pResult[0] != undefined) {
                                //                 item.message = { result: pResult[0], is_show: 1 }
                                //                 item.product = { result: pResult[0], is_show: 1 }
                                //                 finalResult.push(item)
                                //             } else {
                                //                 item.message = { result: "🚫 This message was deleted", is_show: 0 };
                                //                 item.product = { result: "🚫 This message was deleted", is_show: 0 }
                                //             }
                                //             next();
                                //         });

                                //     }
                                // });

                            } else {
                                item.message = item.message.toString('utf8');
                                finalResult.push(item)
                                next();
                            }
                        }
                    }, () => {
                        chat_room.page_token = parseInt(req.page_token) + 1
                        var data = Object.assign({}, { result: finalResult }, { chat_details: chat_room })
                        callback("1", t("text_details_are"), data)
                    });
                } else {
                    chat_room.page_token = 0
                    var data = Object.assign({}, { result: [] }, { chat_details: chat_room })
                    callback("2", t("text_details_are"), data)
                }
            } else {
                callback("0", t("something_wrong"), null);
            }
        });
    },

    /*========================================================================================================
            Chat Details
    ==========================================================================================================*/

    chat_details: function(req, callback) {

        con.query(`SELECT r.*, d.name AS shop_name, CONCAT('${GLOBALS.SHOP_IMAGE}',d.profile_image) AS shop_profile,d.cart_type FROM tbl_chat_room AS r JOIN tbl_dispensary AS d ON d.id = r.store_id WHERE r.id = '${req}' AND r.is_active = '1'`, function(err, result) {
            if (!err) {
                if (result[0] != undefined) {
                    callback(result[0]);
                } else {
                    callback(null);
                }
            } else {
                callback(null);
            }
        });
    },

    /*===========================================================================================================
        Send Chat
    =============================================================================================================*/

    send_chat: function(req, callback) {

        Chat.chat_details(req.chat_id, function(response) {

            var params = {
                user_id: req.login_user_id,
                chat_id: req.chat_id,
                message: req.message,
                type: req.type,
                cart_type: (req.cart_type == 'T') ? "T" : "W",
                insert_datetime: moment().format("X")
            };

            con.query(`INSERT INTO tbl_chat_reply SET ?`, params, function(err, result, fields) {
                if (!err) {
                    con.query(`UPDATE tbl_chat_room SET update_datetime = '${moment().format('X')}' WHERE id = '${req.chat_id}'`);

                    Chat.get_chat_message(result.insertId, function(response1) {
                        console.log("send chat", response1);
                        if (response.user_id1 != req.login_user_id) {
                            var push_user = response.user_id1;
                        }
                        if (response.user_id2 != req.login_user_id) {
                            var push_user = response.user_id2;
                        }

                        let title = response1.fullname;
                        let body = response1.body;

                        //Prepare push notification to send
                        var push_data = {
                            title: title,
                            body: body,
                            custom: {
                                tag: "new_message",
                                body: body,
                                user_id: req.login_user_id,
                                name: response.shop_name,
                                profile_image: response.shop_profile,
                                store_id: response.store_id,
                                chat_id: req.chat_id,
                                chat_reply_id: result.insertId
                            }
                        }

                        common.prepare_notification(push_user, push_data);
                        response1.push_user = push_user;
                        callback("1", t("text_details_are"), response1);
                    })
                } else {
                    callback("0", t("text_something_wrong"), null);
                }
            });

        }); // else chat_details
    },

    dialogflow: function(req, callback) {
        const dialogflow = require('dialogflow');
        const uuid = require('uuid');
        /**
         * Send a query to the dialogflow agent, and return the query result.
         * @param {string} projectId The project to be used
         */
        const projectId = GLOBALS.DIALOGFLOW_PROJECT_ID;
        // A unique identifier for the given session
        const sessionId = uuid.v4();

        // Create a new session
        const sessionClient = new dialogflow.SessionsClient();
        const sessionPath = sessionClient.sessionPath(projectId, sessionId);

        // The text query request.
        const request = {
            session: sessionPath,
            queryInput: {
                text: {
                    // The query to send to the dialogflow agent
                    text: req.message,
                    // The language used by the client (en-US)
                    languageCode: 'en-US',
                },
            },
        };

        // Send request and log result
        const responses = sessionClient.detectIntent(request);
        console.log('Detected intent');
        console.log(response)
            // const result = responses[0].queryResult;
            // console.log(`Query: ${result.queryText}`);
            // console.log(`Response: ${result.fulfillmentText}`);
            // if (result.intent) {
            //     console.log(`Intent: ${result.intent.displayName}`);
            // } else {
            //     console.log(`No intent matched.`);
            // }
        callback('1', 'Sucess', null);
    },

    /*==================================================================================================================
            Get Chat Message
    ====================================================================================================================*/

    get_chat_message: function(req, callback) {

        con.query({
            sql: `SELECT r.id chat_reply_id,r.chat_id,u.id user_id,u.fullname,CONCAT('${GLOBALS.USER_IMAGE}',u.profile_image) profile_image,r.message,r.type,r.insert_datetime,r.is_read,r.cart_type FROM tbl_chat_reply r JOIN tbl_user u ON r.user_id = u.id WHERE r.id = ${req}`,
            typeCast: (field, next) => {
                if (field.type == 'BLOB') {
                    return field.string();
                }
                return next();
            }
        }, function(err, result) {

            if (!err && result[0] != undefined) {
                if (result[0].type == "photo") {
                    result[0].message = GLOBALS.CHAT_IMAGE_MESSAGE + result[0].message;
                    result[0].body = "📷 Photo";
                    callback(result[0]);
                } else if (result[0].type == "product") {
                    try {
                        result[0].message = JSON.parse(result[0].message)
                    } catch (e) {
                        result[0].message = result[0].message
                    }
                    result[0].body = "🏬 Product";
                    if (result[0].cart_type == 'T') {
                        con.query(`SELECT c.id cart_id, c.shop_id, c.product_id, c.quantity, c.name, c.brand_name, c.category AS category_name, c.primary_image as  image,c.price FROM tbl_treez_cart c  WHERE c.id = '${result[0].message.cart_id}'`, (pErr, pResult) => {
                            if (!pErr && pResult[0] != undefined) {
                                result[0].message = { result: pResult[0], is_show: 1 }
                                result[0].product = { result: pResult[0], is_show: 1 }
                                callback(result[0]);
                            } else {
                                result[0].message = { result: "🚫 This message was deleted", is_show: 0 };
                                result[0].product = { result: "🚫 This message was deleted", is_show: 0 }
                                result[0].body = "🚫 This message was deleted";
                                callback(result[0]);
                            }
                        });
                    } else {
                        con.query(`SELECT c.id cart_id, c.shop_id, c.product_id, c.attribute_id, c.quantity, p.name, p.brand_name, ca.name AS category_name, CONCAT('${GLOBALS.CATEGORY_IMAGE}',ca.image) AS category_image, CONCAT('${GLOBALS.PRODUCT_IMAGE}',p.image) image, (c.quantity * a.value) price FROM tbl_cart_product c JOIN tbl_product p ON p.id = c.product_id JOIN tbl_category AS ca ON ca.id = p.category_id JOIN tbl_product_attribute a ON a.id = c.attribute_id WHERE c.id = '${result[0].message.cart_id}'`, (pErr, pResult) => {
                            if (!pErr && pResult[0] != undefined) {
                                result[0].message = { result: pResult[0], is_show: 1 }
                                result[0].product = { result: pResult[0], is_show: 1 }
                                callback(result[0]);
                            } else {
                                result[0].message = { result: "🚫 This message was deleted", is_show: 0 };
                                result[0].product = { result: "🚫 This message was deleted", is_show: 0 }
                                result[0].body = "🚫 This message was deleted";
                                callback(result[0]);
                            }
                        });

                    }


                    // var test2 = con.query(`SELECT c.id cart_id, c.primary_image as image,c.shop_id, c.product_id,c.brand_name,c.name, c.price,c.quantity,c.category from tbl_treez_cart WHERE c.id =  '${result[0].message.cart_id}'`, (pErr, tResult) => {
                    //     console.log("tresult", test2)
                    //     if (tResult[0] != undefined) {
                    //         if (!pErr && tResult[0] != undefined) {
                    //             result[0].message = { result: tResult[0], is_show: 1 }
                    //             result[0].product = { result: tResult[0], is_show: 1 }
                    //             callback(result[0]);
                    //         } else {
                    //             result[0].message = { result: "🚫 This message was deleted", is_show: 0 };
                    //             result[0].product = { result: "🚫 This message was deleted", is_show: 0 }
                    //             result[0].body = "🚫 This message was deleted";
                    //             callback(result[0]);
                    //         }
                    //     } else {
                    //         con.query(`SELECT c.id cart_id, c.shop_id, c.product_id, c.attribute_id, c.quantity, p.name, p.brand_name, ca.name AS category_name, CONCAT('${GLOBALS.CATEGORY_IMAGE}',ca.image) AS category_image, CONCAT('${GLOBALS.PRODUCT_IMAGE}',p.image) image, (c.quantity * a.value) price FROM tbl_cart_product c JOIN tbl_product p ON p.id = c.product_id JOIN tbl_category AS ca ON ca.id = p.category_id JOIN tbl_product_attribute a ON a.id = c.attribute_id WHERE c.id = '${item.message.cart_id}'`, (pErr, pResult) => {
                    //             if (!pErr && pResult[0] != undefined) {
                    //                 result[0].message = { result: pResult[0], is_show: 1 }
                    //                 result[0].product = { result: pResult[0], is_show: 1 }
                    //                 callback(result[0]);
                    //             } else {
                    //                 result[0].message = { result: "🚫 This message was deleted", is_show: 0 };
                    //                 result[0].product = { result: "🚫 This message was deleted", is_show: 0 }
                    //                 result[0].body = "🚫 This message was deleted";
                    //                 callback(result[0]);
                    //             }
                    //         });

                    //     }
                    // });
                } else if (result[0].type == "location") {
                    result[0].message = "📍 Location";
                    result[0].body = "📍 Location";
                    callback(result[0]);
                } else {
                    result[0].message = result[0].message.toString('utf8');
                    result[0].body = (result[0].message.length >= 100) ? result[0].message.substring(0, 100) + "..." : result[0].message;
                    callback(result[0]);
                }
            } else {
                callback([]);
            }
        });
    },

    update_online_offline_status: (req, callback) => {
        con.query(`UPDATE tbl_user SET login = '${req.login}' WHERE id = ${req.user_id}`, (err, result) => {
            callback('1', t('user_login', { status: req.login }), req);
        });
    },
}

module.exports = Chat;